<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGlofLotterieTicketsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('glof_lotterie_tickets', function (Blueprint $table) {
            $table->id();
            $table->integer('lottery_id');
            $table->integer('user_id');
            $table->text('ticket_number');
            $table->decimal('ticket_price',18,8);
            $table->tinyInteger('status')->default('0');
            $table->tinyInteger('send_mail')->default('0');
            $table->tinyInteger('transfer_winning_amount')->default('0');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('glof_lotterie_tickets');
    }
}
