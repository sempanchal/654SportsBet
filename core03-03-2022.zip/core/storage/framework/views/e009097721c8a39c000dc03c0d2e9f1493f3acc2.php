
<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <form action="<?php echo e(route('admin.lottery.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <!-- <div class="col-md-3"> 
                            <div class="sport_logo">
                                <img id="sport_img_logo" src="<?php echo e(asset('assets/images/sport_logo/default.png')); ?>" class="img-thumbnail">
                            </div>                              
                        </div> -->
                        <div class="col-md-12">
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Jackpot Name'); ?></label>
                                <input type="text" class="form-control" value="<?php echo e(old('jackpot_name')); ?>" placeholder="<?php echo app('translator')->get('Jackpot Name'); ?>" name="jackpot_name"/>
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Sport'); ?></label>
                                <div>
                                    <select name="name" class="form--control select2" id="sport_id" requierd>
                                        <option value="" data-id="0" >--SELECT--</option>
                                        <option value="NFL" data-id="2" data-url="<?php echo e(asset('assets/images/sport_logo/2.png')); ?>" <?php if(old('sport_id') == ""): ?>selected="selected"<?php endif; ?>>NFL</option>
                                        <option value="NBA" data-id="4" data-url="<?php echo e(asset('assets/images/sport_logo/4.png')); ?>" <?php if(old('sport_id') == 4): ?>selected="selected"<?php endif; ?>>NBA</option>
                                        <option value="NHL" data-id="6" data-url="<?php echo e(asset('assets/images/sport_logo/6.png')); ?>"  <?php if(old('sport_id') == 6): ?>selected="selected"<?php endif; ?>>NHL</option>
                                        <option value="MLB" data-id="3" data-url="<?php echo e(asset('assets/images/sport_logo/3.png')); ?>"  <?php if(old('sport_id') == 3): ?>selected="selected"<?php endif; ?>>MLB</option>
                                        <option value="MLS" data-id="10" data-url="<?php echo e(asset('assets/images/sport_logo/10.jpg')); ?>"  <?php if(old('sport_id') == 10): ?>selected="selected"<?php endif; ?>>MLS</option>
                                        <option value="EPL" data-id="11" data-url="<?php echo e(asset('assets/images/sport_logo/11.jpg')); ?>"  <?php if(old('sport_id') == 11): ?>selected="selected"<?php endif; ?>>EPL</option>
                                       
                                    </select>
                                    <input type="hidden" name="sport_id" value="<?php echo e(old('sport_id')); ?>" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Date'); ?></label>
                                <input name="date" data-multiple-dates="true" type="text" data-language="en" class="datepicker-here form-control" value="<?php echo e(old('date')); ?>" data-position="bottom right" data-date-format="yyyy-mm-dd" placeholder="Date" autocomplete="off" readonly>
                            </div>
                            <div class="form-group">
                                <button type="button" id="btn-modal-team" class="btn btn-block btn-primary">Choose Team</button>
                            </div>
                            <!-- <div class="form-group">
                                <label><?php echo app('translator')->get('Total Winners'); ?></label>
                                <input type="text" class="form-control" value="<?php echo e(old('total_winners')); ?>" placeholder="<?php echo app('translator')->get('To be predicted by the user'); ?>" name="total_winners"/>
                            </div> -->
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Ticket Price'); ?></label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="<?php echo app('translator')->get('Ticket Price'); ?>" name="ticket_price" value="<?php echo e(old('ticket_price')); ?>">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2"><?php echo e($general->cur_sym); ?></span>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Revenue Percentage'); ?></label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="<?php echo app('translator')->get('Ticket Price'); ?>" name="revenue_percentage" value="<?php echo e(old('revenue_percentage',50)); ?>">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">%</span>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Starting Jackpot'); ?></label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="<?php echo app('translator')->get('minimum price money'); ?>" name="price" value="<?php echo e(old('price')); ?>">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2"><?php echo e($general->cur_sym); ?></span>
                                  </div>
                                </div>
                            </div>
                            <!-- 20-12-2021 -->
                            <div class="form-group">
                                <label><?php echo app('translator')->get('1st place percentage'); ?></label>
                                <input type="number" class="form-control" placeholder="<?php echo app('translator')->get('Winner 1st place percentage'); ?>" max="100" name="first_place" value="70">
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('2st place percentage'); ?></label>
                                <input type="number" class="form-control" placeholder="<?php echo app('translator')->get('Winner 2st place percentage'); ?>" max="100" name="second_place" value="20">
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('3st place percentage'); ?></label>
                                <input type="number" class="form-control" placeholder="<?php echo app('translator')->get('Winner 3st place percentage'); ?>" max="100" name="third_place" value="10">
                            </div>
                            <!-- <input type="hidden" name="choose_team"> -->
                            <!--  -->
                            <!-- <div class="form-group">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Jackpot type'); ?> </label>
                                <input type="checkbox" value="1" <?php if(old('jackpot_type')): ?>checked="checked"<?php endif; ?> data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Static'); ?>" data-off="<?php echo app('translator')->get('Dynamic'); ?>" name="jackpot_type">
                            </div> 
                            <div class="form-group">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Order Prediction'); ?> </label>
                                <input type="checkbox" value="1" <?php if(old('order_prediction')): ?>checked="checked"<?php endif; ?> data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="<?php echo app('translator')->get('Disable'); ?>" name="order_prediction">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Money Type'); ?> </label>
                                <input type="checkbox" value="1" <?php if(old('money_type')): ?>checked="checked"<?php endif; ?> data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Real Money'); ?>" data-off="<?php echo app('translator')->get('Fantasy'); ?>" name="money_type">
                            </div>
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Maximum participants'); ?></label>
                                <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('game closed'); ?>" name="maximum_participants" value="<?php echo e(old('maximum_participants')); ?>"/>
                            </div>
                            <div class="form-group">
                                <label class="form-control-label font-weight-bold"><?php echo app('translator')->get('Quick select'); ?> </label>
                                <input type="checkbox" value="1" <?php if(old('quick_select')): ?>checked="checked"<?php endif; ?> data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Enable'); ?>" data-off="<?php echo app('translator')->get('Disable'); ?>" name="quick_select">
                            </div>-->
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Maximum number of entries per user'); ?></label>
                                <input type="number" class="form-control" placeholder="<?php echo app('translator')->get('0 for infinite'); ?>" name="no_of_entries" value="<?php echo e(old('no_of_entries')); ?>"/>
                            </div>
                            <div class="form-group">
                                <!-- nicEdit -->
                                <label><?php echo app('translator')->get('Game Instruction'); ?></label>
                                <textarea rows="8" class="ckeditor form-control" placeholder="<?php echo app('translator')->get('Game Instruction'); ?>" name="detail"><?php echo e(old('detail')); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-row justify-content-center">
                        <div class="form-group col-md-12">
                            <button type="submit" class="btn btn-block btn--primary mr-2"><?php echo app('translator')->get('Post'); ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.lottery.footerdata', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.lottery.index')); ?>" class="icon-btn" ><i class="fa fa-fw fa-reply"></i><?php echo app('translator')->get('Back'); ?></a> 
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/admin/lottery/create.blade.php ENDPATH**/ ?>