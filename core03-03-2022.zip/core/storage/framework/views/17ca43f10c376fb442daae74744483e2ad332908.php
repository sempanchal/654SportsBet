<!-- <div class="row">
    <div class="col-2 text-center">
        <img src="<?php echo e(get_sport_logo($lottery->sport_id)); ?>" alt="image" height="70" width="70">
    </div>
    <div class="col-6">
        <h4><?php echo e($cur_sym.showAmount($lottery->price,0)); ?> &nbsp; <?php echo e($lottery->jackpot_name); ?></h4>
        <span> <i class="las la-ticket-alt"></i> <?php echo e($total_tickets_bought); ?></span>&nbsp; | &nbsp;<span><a href="javascript:void(0)" data-id="<?php echo e(route('rules_popup',$lottery_id)); ?>" class="cust_rules_popup text-success" style="text-decoration: underline;"><?php echo app('translator')->get('Pay Table and Rules'); ?></a></span>
    </div>
    <div class="col-12"><hr/></div>
</div> -->
<div class="lottery_wrap">
        <div class="card game-table">
            <div class="arrow-right">
                <span><?php echo e($lottery_status); ?></span>
              </div>
          <div class="card-body text-white">
            <div class="d-flex align-items-center">
                    <div class="game-logo-img">
                        <img src="<?php echo e(get_sport_logo($lottery->sport_id)); ?>" alt="image" width="70">
                    </div>
                    <div class="d-flex flex-column game-title-wrapper">
                        <h3><?php echo e($lottery->jackpot_name); ?></h3>
                        <div class="d-flex justify-content-between">
                            <p>Pool Ends: <?php echo e($edate); ?></p>
                            <a href="javascript:void(0)" data-id="<?php echo e(route('rules_popup',$lottery_id)); ?>" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                        </div>
                    </div>
                </div>
                
                <!-- <div class="cut-links">
                    <a href="javascript:void(0)" data-id="<?php echo e(route('rules_popup',$lottery_id)); ?>" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                </div> -->

                <!-- <div class="col-md-2 text-center">
                    <img src="<?php echo e(get_sport_logo($lottery->sport_id)); ?>" alt="image" width="70">
                </div> -->
                <div class="row">
                <div class="col-md-12 mt-3">
                    <!-- <h3 class="card-title"><?php echo e($lottery->jackpot_name); ?></h3>
                    <div class="cut-body my-4">
                        <span class="white-colour"><b>Pool Ends:</b> <?php echo e($edate); ?></span>
                        <div class="cut-links">
                            <a href="javascript:void(0)" data-id="<?php echo e(route('rules_popup',$lottery_id)); ?>" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                        </div>
                    </div> -->
                    <div class="cut-footer ticket-info">
                        <ul class="">
                            <li class="text-center">
                                <h5><?php echo e($cur_sym.showAmount($lottery->price,0)); ?></h5>
                                <span> Prize pool</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5>$10</h5>
                                <span>Entry</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5><?php echo e($total_tickets_bought); ?></h5>
                                <span>Total Entries</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
          </div>
        </div>
</div>
<div class="col-12"><hr/></div>
<form action="<?php echo e($action); ?>" method="post" id="form-choose-team">
    <div class="table-responsive">
        <table class="table custom-table-new">
            <tr>
                <td><h3 class="text-center pb-3">Away</h3></td>
                <td><h3 class="text-center pb-3">Home</h3></td>
            </tr> 
        <?php
            $i = 1;
        ?>   
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gkey => $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <tr>
                    <th colspan="2" class="text-center font-12">
                        <?php echo e($game['name']); ?> - <?php echo e(\Carbon\Carbon::parse($game['date'])->format('F jS, Y h:i A')); ?>

                        <input type="hidden" name="games[<?php echo e($gkey); ?>][game_id]" value="<?php echo e($game['game_id']); ?>" />
                        <input type="hidden" name="games[<?php echo e($gkey); ?>][date]" value="<?php echo e($game['date']); ?>" />
                        <input type="hidden" name="games[<?php echo e($gkey); ?>][price]" value="<?php echo e($game['price']); ?>" />
                    </th>
                </tr>
                
                <?php $__currentLoopData = $game['teams']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkey => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="text-center">
                    <input type="checkbox" data-val="<?php echo e($i.'-'.$team['team_id']); ?>" name="games[<?php echo e($gkey); ?>][team][<?php echo e($i); ?>][team_id]" value="<?php echo e($team['team_id']); ?>"/>
                    <span class="d-flex game_ticket">
                        <div class="game_ticket_img">
                        <img src="<?php echo e(log_logos($team['team_id'])); ?>" alt="logo" height="50" width="100"> 
                    </div>
                    <div style="text-align: left;width: 50%;">
                        <h4><?php echo e($team['abbreviation']); ?> </h4>
                        <p><?php echo e($team['mascot']); ?></p>
                        </div>
                    </span>
                    <input type="hidden" name="games[<?php echo e($gkey); ?>][team][<?php echo e($i); ?>][mascot]" value="<?php echo e($team['mascot']); ?>"/>
                    <input type="hidden" name="games[<?php echo e($gkey); ?>][team][<?php echo e($i); ?>][abbreviation]" value="<?php echo e($team['abbreviation']); ?>"/>
                </td>
                <?php
                    $i++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <input type="hidden" name="ticket_price" value="<?php echo e($ticket_price); ?>">
    <input type="hidden" name="lottery_id" value="<?php echo e($lottery_id); ?>">
</form>
<?php /**PATH /var/www/html/core/resources/views/templates/basic/lottery_team.blade.php ENDPATH**/ ?>