
<?php $__env->startSection('panel'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
	<a href="<?php echo e(route('admin.teams.create')); ?>" class="icon-btn"><i class="fa fa-plus"></i> <?php echo app('translator')->get('Add Teams'); ?></a> 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/admin/teams/index.blade.php ENDPATH**/ ?>