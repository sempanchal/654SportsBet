<?php $__env->startSection('content'); ?>
<section class="pt-100 pb-100">
    <div class="container">
        <div class="row gy-4 align-items-center">
            <div class="col-md-12">
                <?php echo $data->data_values->description ?>
            </div>
        </div><!-- row end -->
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/templates/basic/links.blade.php ENDPATH**/ ?>