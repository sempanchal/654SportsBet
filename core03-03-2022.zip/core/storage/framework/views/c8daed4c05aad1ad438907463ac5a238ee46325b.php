
<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <form action="<?php echo e(route('admin.teams.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label><?php echo app('translator')->get('Game Name'); ?></label>
                                <div>
                                    <select name="name" class="form--control select2" requierd>
                                        <?php if($sports): ?>    
                                        <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                        <option value="<?php echo e($sport['sport_name']); ?>" data-id="<?php echo e($sport['sport_id']); ?>" <?php if(old('sport_id') == $sport['sport_id']): ?>selected="selected"<?php endif; ?>><?php echo e($sport['sport_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <input type="hidden" id="sport_id" name="sport_id" value="<?php echo e(old('sport_id')); ?>" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                        	<label></label>
                        	<div class="form-group">
                                <button type="button" id="get-sport-team" data-action="<?php echo e(route('admin.teams.get_team')); ?>" class="btn btn-block btn-primary">Get Teams</button>
                            </div>
                        </div>    
                    </div>
                    <div class="row">
                    	<div class="col-md-12" id="ajax_teams">

                    	</div>	
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-row justify-content-center">
                        <div class="form-group col-md-12">
                            <button type="submit" class="btn btn-block btn--primary mr-2"><?php echo app('translator')->get('Post'); ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.lottery.footerdata', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.teams.index')); ?>" class="icon-btn" ><i class="fa fa-fw fa-reply"></i><?php echo app('translator')->get('Back'); ?></a> 
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/admin/teams/create.blade.php ENDPATH**/ ?>