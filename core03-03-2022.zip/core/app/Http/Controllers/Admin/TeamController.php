<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Lib\RapidAPI;
use App\Models\Sport;
use App\Models\SportTeams;
use Image;

class TeamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pageTitle = "Sports";
        return view('admin.teams.index',compact('pageTitle'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pageTitle = "Sport Teams";
        $data = array(
            'return_data' => 'sports',
            'url' => 'sports',
        );
        $sports = RapidAPI::send($data);
        return view('admin.teams.create',compact('pageTitle','sports'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        foreach($request->team as $team1){
            $request->validate([
                "team['logo']" => 'required',
            ]);
        }
        echo $sport_id = $request->sport_id;
        foreach($request->team as $team){
            if(isset($team['logo'])){
                echo $path = 'assets/images/teams_logos/'.$sport_id;
                if (!file_exists($path)) {
                    mkdir($path, 0777, true);
                }
                $image = $team['logo'];
                $filename    = $image->getClientOriginalName();
                $image_resize = Image::make($image->getRealPath());              
                $image_resize->resize(70, 70);
                $image_resize->save($path.'/'.$filename);
                echo $team['logo']->getClientOriginalExtension();
                echo "<br/>";
                echo $team['logo']->getSize();
                die;
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    /*09-02-2022*/
    public function getSportTeams(Request $request){
        $json = array();
        $sport_id = $request->id;
        $sportTeams = RapidAPI::get_sport_team($sport_id);

        $json['html'] = view('admin.teams.sport-teams',compact('sportTeams'))->render();
        $json['success'] = true;

        return response()->json($json);
    }
}
