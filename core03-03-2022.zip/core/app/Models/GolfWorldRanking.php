<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GolfWorldRanking extends Model
{
    use HasFactory;

    protected $fillable = [
        'avg_points',
        'movement',
        'num_events',
        'player_id',
        'player_name',
        'points_gained',
        'points_lost',
        'position',
        'total_points',
    ];
}
