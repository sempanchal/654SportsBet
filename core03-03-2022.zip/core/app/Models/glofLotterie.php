<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class glofLotterie extends Model
{
    use HasFactory;

    protected $fillable = [
        'jackpot_name',
        'sport',
        'tournament_id',
        'ticket_price',
        'jackpot_price',
        'first_place',
        'second_place',
        'third_place',
        'no_of_entries',
        'detail',
        'last_update_score',
        'status',
    ];
}
