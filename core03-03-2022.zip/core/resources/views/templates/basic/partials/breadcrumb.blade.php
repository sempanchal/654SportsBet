<section class="inner-hero bg_img overlay--one" style="background-image: url({{ asset('assets/images/frontend/breadcrumb/'.getContent('breadcrumb.content',true)->data_values->background_image) }});">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 text-center">
                @if(strtolower($pageTitle) == 'dashboard')
                <h2 class="page-title text-white">{{ $general->sitename }} {{ __($pageTitle) }}</h2>
                @else
                <h2 class="page-title text-white">{{ __($pageTitle) }}</h2>
                @endif
                <!-- <ul class="page-breadcrumb justify-content-center">
                    <li><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
                    <li>{{ __('Games') }}</li>
                </ul> -->
            </div>
        </div>
    </div>
</section>
<!-- inner hero end -->