<!doctype html>
<html lang="en" itemscope itemtype="http://schema.org/WebPage">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <title> {{ $general->sitename(__($pageTitle)) }}</title>
@include('partials.seo')



<!-- bootstrap 5  -->
    <link rel="stylesheet" href="{{asset($activeTemplateTrue.'css/lib/bootstrap.min.css')}}">
    <!-- fontawesome 5  -->
    <link rel="stylesheet" href="{{asset($activeTemplateTrue.'css/all.min.css')}}">
    <!-- lineawesome font -->
    <link rel="stylesheet" href="{{asset($activeTemplateTrue.'css/line-awesome.min.css')}}">
    <!-- slick slider css -->
    <link rel="stylesheet" href="{{asset($activeTemplateTrue.'css/lib/slick.css')}}">
    <!-- main css -->
    <link rel="stylesheet" href="{{asset($activeTemplateTrue.'css/main.css')}}">

    <link rel="stylesheet" href="{{asset($activeTemplateTrue.'css/bootstrap-fileinput.css')}}">
    <link rel="stylesheet" href="{{asset($activeTemplateTrue.'css/custom.css')}}">
    <link rel="stylesheet" href="{{asset('assets/admin/css/vendor/bootstrap-toggle.min.css')}}">
    <!-- <link rel=¨stylesheet¨ type=¨text/css¨ href=¨https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css¨> -->

    <link rel="stylesheet"
          href="{{asset($activeTemplateTrue.'css/color.php?color='.$general->base_color.'&secondColor='.$general->secondary_color)}}">

    @stack('style-lib')

    @stack('style')
    <style>
        .bottom-nav {
            margin-top: 100px;
            display: flex;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 0.8rem 0;
            background-color: #252a32;
            z-index: 99;
            will-change: transform;
            transform: translateZ(0);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 3px rgba(0, 0, 0, 0.24);
        
        }
        .bottom-nav img{
            height: 30px;
            width: 30px;
        }
        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            flex-grow: 1;
            justify-content: center;
            text-align: center;
            font-size: 0.8rem;
            color: #f1f5f8;
        }
        .bottom-nav-link {
            display: flex;
            flex-direction: column;
            align-items:center;
        }
        .bottom-nav .active {
            color: #F89316;
        }
        .top-nav{
            top: -10px;
            /*margin: 10px 0;*/
            position: relative;
            display: block;
            width: 3.5rem;
            height: 2.25rem;
            cursor: pointer;
            background: transparent;
            /*border-top: 2px solid;*/
            /*border-bottom: 2px solid;*/
            color: #fff;
            font-size: 0;
            -webkit-transition: all 0.25s ease-in-out;
            -o-transition: all 0.25s ease-in-out;
            transition: all 0.25s ease-in-out;
            cursor: pointer;
        }
        @media only screen and (min-width: 600px) {
            .bottom-nav{
                display:none;
            }
            .top-nav{
                display:none;
            }
        }
    </style>
</head>
<body>

<div class="preloader">
    <div class="preloader-container">
        <span class="animated-preloader"></span>
    </div>
</div>

<!-- scroll-to-top start -->
<!-- <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-rocket" aria-hidden="true"></i>
    </span>
</div> -->
<!-- scroll-to-top end -->


<!-- header-section start  -->
<header class="header">
    <div class="header__bottom">
        <div class="container-fluid px-lg-5">
            <nav class="navbar navbar-expand-xl p-0 align-items-center">
                <a class="site-logo site-title" href="{{ route('home') }}"><img
                        src="{{getImage(imagePath()['logoIcon']['path'] .'/'.$general->logo)}}" alt="logo"></a>
                <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                    <span class="menu-toggle"></span>
                </button> -->
                @if(trim(\Request::route()->getName()) == 'user.profile.setting')
                @auth
                    <div class="top-nav">
                      <div class="top-nav-item">
                        <a href="{{ route('user.logout') }}">
                        <div class="top-nav-link">
                            <img src="{{ getImage('assets/images/icons/logout.png') }}" alt="logout" />
                        </div>
                        </a>
                      </div>
                    </div>
                @endauth
                @endif
                <div class="collapse navbar-collapse mt-lg-0 mt-3" id="navbarSupportedContent">
                    <ul class="navbar-nav main-menu me-auto">
                        @auth
                            <li><a href="{{ route('lottery') }}">@lang('Games')</a></li>

                            <li class="menu_has_children">
                                <a href="javascript:void(0)">@lang('Finance')</a>
                                <ul class="sub-menu">
                                    <li><a href="{{ route('user.deposit') }}">@lang('Deposit')</a></li>
                                    <li><a href="{{ route('user.withdraw') }}">@lang('Withdraw')</a></li>
                                    <li><a href="{{ route('user.transactions') }}">@lang('Transactions')</a></li>
                                </ul>
                            </li>
                            <li><a href="{{ route('ticket') }}">@lang('Support')</a></li>

                            <!-- @if($general->dc+$general->bc+$general->wc > 0)
                                <li class="menu_has_children">
                                    <a href="javascript:void(0)">@lang('Referral.')</a>
                                    <ul class="sub-menu">
                                        <li><a href="
                                            @if($general->dc)
                                            {{ route('user.commissions.deposit') }}
                                            @elseif($general->bc)
                                            {{ route('user.commissions.buy') }}
                                            @else
                                            {{ route('user.commissions.win') }}
                                            @endif
                                                ">@lang('Commission')</a></li>
                                        <li><a href="{{ route('user.referred') }}">@lang('Referred Users')</a></li>
                                    </ul>
                                </li>
                            @endif -->

                            <li class="menu_has_children">
                                <a href="javascript:void(0)">@lang('Account')</a>
                                <ul class="sub-menu">
                                    <li><a href="{{ route('user.profile.setting') }}">@lang('Profile')</a></li>
                                    <li><a href="{{ route('user.change.password') }}">@lang('Change Password')</a>
                                    </li>
                                    <li><a href="{{ route('user.my-bets') }}">@lang('My Bets')</a></li>
                                    <li><a href="{{ route('user.twofactor') }}">@lang('Security')</a></li>
                                </ul>
                            </li>
                        @endauth
                    </ul>
                    <div class="nav-right">
                        @auth
                            <a href="{{ route('user.home') }}"
                               class="btn btn-sm btn--base me-sm-3 me-2 btn--capsule px-3">@lang('Dashboard')</a>
                            <a href="{{ route('user.logout') }}" class="text-white fs--14px me-sm-3 me-2">@lang('Logout')</a>
                        @else
                            <a href="{{ route('user.login') }}"
                               class="btn btn-sm btn--base me-sm-3 me-2 btn--capsule px-3">@lang('Login')</a>
                            <a href="{{ route('user.register') }}"
                               class="text-white fs--14px me-sm-3 me-2">@lang('Register')</a>
                        @endauth
                        <select class="language-select langSel">
                            <option value="">@lang('Select One')</option>
                            @foreach($language as $item)
                                <option value="{{$item->code}}"
                                        @if(session('lang') == $item->code) selected @endif>{{ __($item->name) }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </nav>
        </div>
    </div><!-- header__bottom end -->
</header>
<!-- header-section end  -->


<div class="main-wrapper">

    @include($activeTemplate.'partials.breadcrumb')

    @yield('content')

</div><!-- main-wrapper end -->

@php
    $footer_content = getContent('footer.content', true);
    $footer_elements = getContent('footer.element');
    $extra_pages = getContent('extra.element');
@endphp
<!-- footer start -->
<footer class="footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-2 col-md-3 text-md-start text-center">
                <a href="{{ route('home') }}" class="footer-logo"><img
                        src="{{getImage(imagePath()['logoIcon']['path'] .'/logo.png')}}" alt="image"></a>
            </div>
            <div class="col-lg-10 col-md-9 mt-md-0 mt-3">
                <ul class="inline-menu d-flex flex-wrap justify-content-md-end justify-content-center align-items-center">
                    <li><a href="{{ route('home') }}">@lang('Home')</a></li>
                    <li><a href="{{ route('lottery') }}">@lang('Games')</a></li>

                    @foreach($pages as $k => $data)
                        <li><a href="{{route('pages',[$data->slug])}}">{{__($data->name)}}</a></li>
                    @endforeach

                    @forelse($extra_pages as $item)
                        <li>
                            <a href="{{ route('links',[$item->id,slug($item->data_values->title)]) }}">{{ __(@$item->data_values->title) }}</a>
                        </li>
                    @empty
                    @endforelse
                </ul>
            </div>
        </div><!-- row end -->
        <hr class="mt-3">
        <div class="row align-items-center">
            <div class="col-md-4 text-md-start text-center">
                <p>{{ __(@$footer_content->data_values->copyright) }}</p>
            </div>
            <div class="col-md-6 text-center">
                <p>Covered by: Pat. 8,876,593 and Pat. 9,153,099.</p>
            </div>
            <div class="col-md-2 mt-md-0 mt-3">
                <ul class="inline-social-links d-flex align-items-center justify-content-md-end justify-content-center">
                    @forelse($footer_elements as $item)
                        <li><a href="{{ @$item->data_values->social_link }}"
                               target="_blank">@php echo @$item->data_values->social_icon @endphp</a></li>
                    @empty
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- footer end -->
<nav class="bottom-nav">
      <div class="bottom-nav-item">
        <a href="{{ route('home') }}">
        <div class="bottom-nav-link">
        <img src="{{ getImage('assets/images/icons/home-page.png') }}" alt="games" />
          <span>Home</span>
        </div>
        </a>
      </div>
      <div class="bottom-nav-item">
        <a href="{{ route('lottery') }}">
        <div class="bottom-nav-link">
          <img src="{{ getImage('assets/images/icons/american-football.png') }}" alt="games" />
          <span>Games</span>
        </div>
        </a>
      </div>
      
      <div class="bottom-nav-item">
        <a href="@auth {{ route('user.my-bets') }} @else {{ route('user.login') }} @endauth">
            <div class="bottom-nav-link">
            <img src="{{ getImage('assets/images/icons/my-bets.png') }}" alt="games" />
              <span>My Bets</span>
            </div>
        </a>
      </div>

      <div class="bottom-nav-item">
        <a href="@auth {{ route('user.home') }} @else {{ route('user.login') }} @endauth">
            <div class="bottom-nav-link">
              <img src="{{ getImage('assets/images/icons/wallet.png') }}" alt="games" />
              <span>Wallet</span>
            </div>
        </a>
      </div>

      <div class="bottom-nav-item">
        <a href="@auth {{ route('user.profile.setting') }} @else {{ route('user.login') }} @endauth">
            <div class="bottom-nav-link">
            <img src="{{ getImage('assets/images/icons/account.png') }}" alt="games" />
              <span>Account</span>
            </div>
        </a>
      </div>
    </nav>
<!-- jQuery library -->
<script src="{{asset($activeTemplateTrue.'js/lib/jquery-3.6.0.min.js')}}"></script>
<!-- bootstrap js -->
<script src="{{asset($activeTemplateTrue.'js/lib/bootstrap.bundle.min.js')}}"></script>
<!-- slick slider js -->
<script src="{{asset($activeTemplateTrue.'js/lib/slick.min.js')}}"></script>
<!-- scroll animation -->
<script src="{{asset($activeTemplateTrue.'js/lib/wow.min.js')}}"></script>
<!-- apex chart js -->
<script src="{{asset($activeTemplateTrue.'js/lib/jquery.countdown.js')}}"></script>
<!-- main js -->
<script src="{{asset($activeTemplateTrue.'js/app.js')}}"></script>

<script src="{{asset($activeTemplateTrue.'js/bootstrap-fileinput.js')}}"></script>

<script src="{{ asset($activeTemplateTrue.'js/jquery.validate.js') }}"></script>

<script src="{{asset('assets/admin/js/vendor/bootstrap-toggle.min.js')}}"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.10.1/dist/sweetalert2.all.min.js"></script> -->

@stack('script-lib')

@include('partials.notify')

@include('partials.plugins')


@stack('script')


<script>

    (function ($) {
        "use strict";
        $(".langSel").on("change", function () {
            window.location.href = "{{route('home')}}/change/" + $(this).val();
        });

    })(jQuery);

</script>


<script>
    (function ($) {
        "use strict";

        $("form").validate();
        $('form').on('submit', function () {
            if ($(this).valid()) {
                $(':submit', this).attr('disabled', 'disabled');
            }
        });

    })(jQuery);

</script>

<!-- Custom by amit -->
<div class="modal" tabindex="-1" role="dialog" id="modal-choose-team">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Choose 6 Teams</h5>
                <button type="button" onclick="$('#modal-choose-team').hide()" class="btn btn-sm btn-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="max-height: 70vh;overflow: auto;"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn--base" id="quick_picks">Quick Pick </button>
                <button type="button" class="btn btn--base" id="clear_picks">Clear Pick </button>
                <button type="submit" form="form-choose-team" class="btn btn--base" id="buy_ticket">Submit</button>
            </div>
        </div>
    </div>
</div>
<div class="modal" tabindex="-1" role="dialog" id="modal-game-schedule">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Schedules</h5>
                <button type="button" onclick="$('#modal-game-schedule').hide()" class="btn btn-sm btn-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="max-height: 70vh;overflow: auto;"></div>
        </div>
    </div>
</div>
<!-- Custom by sunny -->
<div class="modal" tabindex="-1" role="dialog" id="user_teams_popup">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Teams Picked</h5>
                <button type="button" onclick="$('#user_teams_popup').hide()" class="btn btn-sm btn-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="max-height: 70vh;overflow: auto;"></div>
        </div>
    </div>
</div>
<div class="modal" tabindex="-1" role="dialog" id="modal-game-rules">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Summary</h5>
                <button type="button" onclick="$('#modal-game-rules').hide()" class="btn btn-sm btn-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="max-height: 70vh;overflow: auto;">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn--base" onclick="$('#modal-game-rules').hide()">Close</button>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    /*18-12-2021*/
    $('.user_team_popup').on('click', function(){
        $btn = $(this);
        $action = $btn.attr('data-id');
        $lottery_id = $btn.attr('data-lottery_id');
        $ticket_id = $btn.attr('data-ticket_id');

        $.ajax({
            url: $action,
            type: 'get',
            dataType: 'json',
            data: ({lottery_id:$lottery_id,ticket_id:$ticket_id}),
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                console.log(json);
                if(json.success){
                    $('#user_teams_popup .modal-body').html(json.html);
                    $("#user_teams_popup").show();
                }else{
                    // iziToast['error']({
                    //     message: json.error,
                    //     position: "topRight"
                    // });
                    Swal.fire({
                        toast: false,
                        title: json.error,
                        animation: false,
                        position: 'center',
                        showConfirmButton: true,
                        timer: 5000,
                        timerProgressBar: true,
                        background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                        didOpen: (toast) => {
                          toast.addEventListener('mouseenter', Swal.stopTimer)
                          toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    });
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            }
        });
    });
    /*end*/

    /*16-01-2022*/
$(document).on("click",".cust_rules_popup",function(event) {
    $('#modal-choose-team').hide();
    $btn = $(this);
    $action = $btn.attr('data-id');
    //alert($action);
    $.ajax({
        url: $action + '?type=team',
        type: 'get',
        dataType: 'json',
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            console.log(json);
            if(json.success){
                $('#modal-game-rules .modal-body').html(json.html);
                $("#modal-game-rules").show();
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
    });
});
$(document).ready(function(){

    $(".btn-modal-rules-popup,.cust_rules_popup").click(function(event){
        event.stopPropagation();
        //alert("rules click");
        $btn = $(this);
        $action = $btn.attr('data-id');
        //alert($action);
        $.ajax({
            url: $action + '?type=team',
            type: 'get',
            dataType: 'json',
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                console.log(json);
                if(json.success){
                    $('#modal-game-rules .modal-body').html(json.html);
                    $("#modal-game-rules").show();
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            },
        });
    });
    //$('.card.btn-modal-team-popup').on('click', function(){
    $(".card.btn-modal-team-popup").click(function(event){
        //alert("cart click");
        $btn = $(this);
        $action = $btn.attr('data-id');
        $.ajax({
            url: $action + '?type=team',
            type: 'get',
            dataType: 'json',
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                if(json.success){
                    $('#modal-choose-team .modal-body').html(json.html);
                    //$('#modal-choose-team #buy_ticket').html(json.ticket_price);
                    $('#modal-choose-team').show();
                }else{
                    /*iziToast['error']({
                        message: json.error,
                        position: "topRight"
                    });*/
                    window.location.href = json.url;
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            },
            error: function(xhr, exception){
                $btn.prop('disabled', false);

                if(xhr.responseJSON){
                    $.each(xhr.responseJSON.errors, function(k,v){
                        /*iziToast['error']({
                            message: v[0],
                            position: "topRight"
                        });*/
                        Swal.fire({
                            toast: false,
                            title: v[0],
                            animation: false,
                            position: 'center',
                            showConfirmButton: true,
                            timer: 5000,
                            timerProgressBar: true,
                            background:'#000000e3',
                            confirmButtonColor:'#ffb400',
                            customClass: {
                              title: 'cust_popup_title',
                            },
                            didOpen: (toast) => {
                              toast.addEventListener('mouseenter', Swal.stopTimer)
                              toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        });
                    });
                }
            }
        });
    }); 
     //golf teams popup
    $(".card.btn-modal-golf-popup").click(function(event){
        //alert("cart click");
        $btn = $(this);
        $action = $btn.attr('data-id');
        $.ajax({
            url: $action,
            type: 'get',
            dataType: 'json',
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                //alert("cart click1");
                console.log(json);
                if(json.success){
                    $('#modal-choose-team .modal-body').html(json.html);
                    //$('#modal-choose-team #buy_ticket').html(json.ticket_price);
                    $('#modal-choose-team').show();
                }else{
                    /*iziToast['error']({
                        message: json.error,
                        position: "topRight"
                    });*/
                    window.location.href = json.url;
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            },
            error: function(xhr, exception){
                $btn.prop('disabled', false);

                if(xhr.responseJSON){
                    $.each(xhr.responseJSON.errors, function(k,v){
                        /*iziToast['error']({
                            message: v[0],
                            position: "topRight"
                        });*/
                        Swal.fire({
                            toast: false,
                            title: v[0],
                            animation: false,
                            position: 'center',
                            showConfirmButton: true,
                            background:'#000000e3',
                            confirmButtonColor:'#ffb400',
                            customClass: {
                              title: 'cust_popup_title',
                            },
                            timer: 5000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                              toast.addEventListener('mouseenter', Swal.stopTimer)
                              toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        });
                    });
                }
            }
        });
    });
});
// 16-01-2022
$('.btn-modal-schedule-popup').on('click', function(){
    $btn = $(this);
    $action = $btn.attr('data-id');
    $.ajax({
        url: $action + '?type=schedule',
        type: 'get',
        dataType: 'json',
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            if(json.success){
                $('#modal-game-schedule .modal-body').html(json.html);
                $('#modal-game-schedule').show();
            }else{
                // iziToast['error']({
                //     message: json.error,
                //     position: "topRight"
                // });
                Swal.fire({
                    toast: false,
                    title: json.error,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    timer: 5000,
                    timerProgressBar: true,
                    background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
        error: function(xhr, exception){
            $btn.prop('disabled', false);

            if(xhr.responseJSON){
                $.each(xhr.responseJSON.errors, function(k,v){
                    // iziToast['error']({
                    //     message: v[0],
                    //     position: "topRight"
                    // });
                    Swal.fire({
                        toast: false,
                        title: v[0],
                        animation: false,
                        position: 'center',
                        showConfirmButton: true,
                        timer: 5000,
                        timerProgressBar: true,
                        background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                        didOpen: (toast) => {
                          toast.addEventListener('mouseenter', Swal.stopTimer)
                          toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    });
                });
            }
        }
    });
});
$(document).delegate('#form-choose-team', 'submit', function(e){
    e.preventDefault();

    $form = $(this);
    $btn = $('[form="form-choose-team"]');
    $.ajax({
        url: $form.attr('action'),
        type: $form.attr('method'),
        dataType: 'json',
        data: $form.serialize(),
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            if(json.success){
                $('#modal-choose-team').hide();

                // iziToast['success']({
                //     message: json.message,
                //     position: "topRight"
                // });
                Swal.fire({
                    toast: false,
                    title: json.message,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    timer: 5000,
                    timerProgressBar: true,
                    background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            }else{
                // iziToast['error']({
                //     message: json.error,
                //     position: "topRight"
                // });
                Swal.fire({
                    toast: false,
                    title: json.error,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    timer: 5000,
                    timerProgressBar: true,
                    background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
        error: function(xhr, exception){
            $btn.prop('disabled', false);

            if(xhr.responseJSON){
                $.each(xhr.responseJSON.errors, function(k,v){
                    // iziToast['error']({
                    //     message: v[0],
                    //     position: "topRight"
                    // });
                    Swal.fire({
                        toast: false,
                        title: v[0],
                        animation: false,
                        position: 'center',
                        showConfirmButton: true,
                        timer: 5000,
                        timerProgressBar: true,
                        background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                        didOpen: (toast) => {
                          toast.addEventListener('mouseenter', Swal.stopTimer)
                          toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    });
                });
            }
        }
    });
});
$(document).delegate('[name="checkall"]', 'change', function(){
    var checked = $(this).prop('checked');
    $('[name="team_id[]"]').prop('checked', checked);
});
</script>
<!-- End Custom by amit -->

</body>
</html>
