    <h3 class="mb-2" >{{ $rules_array['jackpot_name'] }}</h3>
    <div class="text-white my-2">
        {!! $rules_array['detail'] !!}
    </div>
    <!-- <div class="my-2">
      <mark>Should teams score the same total. <strong>Away teams will take priority</strong></mark>
    </div> -->
    <table class="table-summary" border="0" width="100%">      
        <tr>
            <th>Entry Fee <span>:</span></th>
            <td>{{ $rules_array['ticket_price'] }}</td>
        </tr>
        <tr>
            <th>Entries <span>:</span></th>
            <td>Unlimited</td>
        </tr>
        <tr>
            <th>Max Entries Per User <span>:</span></th>
            @if($rules_array['no_of_entries'] > 0)
            <td> {{ $rules_array['no_of_entries'] }}</td>
            @else
            <td>Unlimited</td>
            @endif
        </tr>
        <tr>
            <th>Sport <span>:</span></th>
            <td>{{ $rules_array['name'] }}</td>
        </tr>
        <tr>
            <th>Start Date <span>:</span></th>
            <td>{{ $rules_array['sdate'] }}</td>
        </tr>
        <tr>
            <th>End date <span>:</span></th>
            <td>{{ $rules_array['edate'] }}</td>
        </tr>
        <tr>
            <th>Prizes Paid <span>:</span></th>
            <td id="first_place"><br/><br/>
                6 out of 6 ({{ $rules_array['first_place'] }})<br/>
                5 out of 6 ({{ $rules_array['second_place'] }})<br/>
                4 out of 6 ({{ $rules_array['third_place'] }})<br/>
            </td>
        </tr>
        <tr>
            <th>Total Prizes <span>:</span></th>
            <td>{{ $rules_array['price'] }}</td>
        </tr>
    </table>
    
                