@extends('admin.layouts.app')
@section('panel')

<div class="row">
	<div class="col-md-12">

		@if($lottery_status == 'completed')
			<h3 class="mb-3 text-center">Statistics</h3>
			<hr>
			<div class="row">
				<div class="col-md-4 mb-2">
					<div class="card event-timing-col">
						<div class="card-body">
							<h5>Start Date: <span class="badge badge-primary">{{ $lotterie_sdate }}</span></h5>
						</div>
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card event-timing-col">
						<div class="card-body">
							<h5>End Date: <span class="badge badge-danger">{{ $lotterie_edate }}</span></h5>
						</div>
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card event-timing-col">
						<div class="card-body">
							<p>Total Jackpot Size: <span class="badge badge-success">${{ showAmount($lotterie_price,0) }}</span></p>
						</div>
					</div>
				</div>
			</div>
			<hr>
			
			<h4 class="mb-3">List of Winning Teams</h4>
			<div class="winner_teams mb-3">
				@forelse($only_winning_team_arr as $kw => $vw)
					<div class="winner_teams_col">
						<img src="{{ log_logos($vw['team_id']) }}" alt="logo" height="50" width="50"> <span>{{ $vw['abbreviation'] }}</span>
						({{ $vw['score'] }})
					</div>
				@empty
				@endforelse
			</div>
			<hr>

			@if($winner_statistics)
			<h4 class="mb-2">No. of Winners</h4>
			<div class="row">
				<div class="col-md-4 mb-2">
					<div class="card prize-winning-col">
						<div class="card-header bg-success">
							<h4>1st Prize Winners</h4>
						</div>
						@if(isset($winner_statistics[1]))
						<div class="card-body">
							<ul>
							@forelse($winner_statistics[1] as $ks => $vs)
								<li>
									<h5>{{ $vs['username'] }}</h5>
									<p>Winning Amount: <strong>${{ $vs['winning_price'] }}</strong></p>
									<p>Ticket Number: <strong>{{ $vs['ticket_number'] }}</strong></p>
								<hr/>
								</li>
							@empty
							 	<li><span>No data found.</span></li>
							@endforelse
							</ul>
						</div>
						@endif
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card prize-winning-col">
						<div class="card-header bg-warning">
							<h4>2nd Prize Winners</h4>
						</div>
						<div class="card-body">
							@if(isset($winner_statistics[2]))
							<div class="card-body">
								<ul>
								@forelse($winner_statistics[2] as $ks => $vs)
									<li>
										<h5>{{ $vs['username'] }}</h5>
										<p>Winning Amount: <strong>${{ $vs['winning_price'] }}</strong></p>
										<p>Ticket Number: <strong>{{ $vs['ticket_number'] }}</strong></p>
										<hr/>
									</li>
								@empty
									<li><span>No data found.</span></li>
								@endforelse
								</ul>
							</div>
							@endif
						</div>
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card prize-winning-col">
						<div class="card-header bg-danger">
							<h4>3rd Prize Winners</h4>
						</div>
						<div class="card-body">
							@if(isset($winner_statistics[3]))
							<div class="card-body">
								<ul>
								@forelse($winner_statistics[3] as $ks => $vs)
									<li>
										<h5>{{ $vs['username'] }}</h5>
										<p>Winning Amount: <strong>${{ $vs['winning_price'] }}</strong></p>
										<p>Ticket Number: <strong>{{ $vs['ticket_number'] }}</strong></p>
									<hr/>
									</li>
								@empty
								 <li><span>No data found.</span></li>
								@endforelse
								</ul>
							</div>
							@endif
						</div>
					</div>
				</div>
			</div>
			<hr>
			@endif
		@endif


		<h4 class="mb-2">{{ $lotterie->name .' - '. $lotterie->jackpot_name }}</h4>

		<div class="d-flex justify-content-between">
			<div>
				<h4><span class="badge @if($lottery_status == 'completed') badge-success @else badge-danger  @endif lottery_status"><b>Jackpot Result Status:</b> {{ $lottery_status }}</span></h4>
			</div>
			<div>
				<button id="score_update" class="btn btn-primary" data-action="{{ route('admin.lottery.update_score') }}" data-lotterie_id="{{ $lotterie_id }}" data-csrf="{{ csrf_token() }}">Update Score <i class="fas fa-info-circle" data-toggle="tooltip" data-placement="top" title="{{ 'last updated: '.\Carbon\Carbon::parse($last_update_score)->format('F jS, Y h:i A') }}"></i></button>
				<button id="send_to_winner" class="btn btn-primary"  @if($lottery_status == 'pending' || $sent_prize == 1) disabled @endif data-id="{{ route('admin.lottery.send_win_amount') }}" data-win_data="{{ $send_mail_data }}" data-csrf="{{ csrf_token() }}" data-lotterie_id="{{ $lotterie_id }}">Send Mail To Winner</button>
				<button class="btn btn-danger" id="current_status" data-id="{{ route('admin.lottery.lottery_current_status') }}" data-lotterie_id="{{ $lotterie_id }}" data-sportId="{{ $lotterie_sportId }}" data-lotterie_date="{{ $lotterie_date }}">Show current status</button>
			</div>
			
		</div>
	</div>
</div>

<!-- <div class="row">
	<div class="col-4">
		<button id="send_to_winner" class="btn btn-primary"  @if($lottery_status == 'pending' || $sent_prize == 1) disabled @endif data-id="{{ route('admin.lottery.send_win_amount') }}" data-win_data="{{ $send_mail_data }}" data-csrf="{{ csrf_token() }}" data-lotterie_id="{{ $lotterie_id }}">Send Mail To Winner</button>
		<button class="btn btn-primary" id="current_status" data-id="{{ route('admin.lottery.lottery_current_status') }}" data-lotterie_id="{{ $lotterie_id }}" data-sportId="{{ $lotterie_sportId }}" data-lotterie_date="{{ $lotterie_date }}">Show current status</button>
	</div>	
	<div class="col-4 text-center">
		<h3>{{ $lotterie->name .' - '. $lotterie->jackpot_name }}</h3>
	</div>
	<div class="col-4 text-right">
		<h4><span class="badge @if($lottery_status == 'completed') badge-success @else badge-danger  @endif lottery_status"><b>Jackpot Result Status:</b> {{ $lottery_status }}</span></h4>
	</div>
</div> -->
<hr/>
<div class="row">
    <div class="col-lg-12">
        <!-- <div class="card b-radius--10">
            <div class="card-body p-0"> -->
            	@if(count($new_user_lottery_array)>0)
            	<div class="table-responsive--sm table-responsive">
	            	<table id="example" class="display" style="width:100%">
				        <thead>
				            <tr>
				                <th>@lang('Serial Number')</th>
				                <th class="text-center">@lang('Username')</th>
				                <th class="text-center">@lang('Ticket Number')</th>
				                <th class="text-center">@lang('Total Score')</th>
				                <th class="text-center">@lang('No. Of Teams In Winning Zone')</th>
				                <th>@lang('Actions')</th>
				            </tr>
				        </thead>
				        <tbody>
				           @forelse($new_user_lottery_array as $key => $lottery)
				          <tr class="@if($lottery['total_teams_in_winning'] == 6 && $lottery['total_score']>0) bg-success @elseif($lottery['total_teams_in_winning'] == 5 && $lottery['total_score']>0) bg-warning @elseif($lottery['total_teams_in_winning'] == 4 && $lottery['total_score']>0) bg-danger @endif">

                            <td data-label="@lang('Serial Number')">{{ $key+1 }}</td>
                            <td class="text-center" data-label="@lang('Username')">{{ $lottery['username'] }}</td>
                            <td class="text-center" data-label="@lang('Ticket Number')">{{ $lottery['ticket_number'] }}</td>
                            <td class="text-center" data-label="@lang('Total Score')">{{ $lottery['total_score'] }}</td>
                            <td class="text-center" data-label="@lang('No. Of Teams In Winning Zone')">@if($lottery['total_score']>0) {{ $lottery['total_teams_in_winning'] }} @else 0 @endif </td>
                            <td data-label="@lang('Actions')">
                            	<a href="javascript:void(0)" class="icon-btn winner_team_popup" data-id="{{ route('admin.lottery.winner_team_popup') }}" data-toggle="tooltip" data-original-title="View Teams" data-lotterie_id="{{ $lotterie_id }}" data-ticket_id="{{ $lottery['ticket_id'] }}">
                                    <i class="las la-users"></i>
                                </a>
                            </td>
                            </tr>
                           @empty
                            <tr>
                                <td class="text-muted text-center" colspan="6">@lang('Date Not Found')</td>
                            </tr>
				           @endforelse
				        </tbody>
				    </table>
				<!-- </div>
            </div> -->
        </div>
        @else
        <div>
        	<h2 class="text-center">Date Not Found</h2>
        </div>
        @endif
    </div>
</div>
<div class="modal" tabindex="-1" role="dialog" id="ticket-teams">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Teams</h5>
                <button type="button" onclick="$('#ticket-teams').hide()" class="cloas-btn" data-dismiss="modal" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <div class="modal-body" style="max-height: 80vh;overflow: auto;"></div>
        </div>
    </div>
</div>      
<div class="modal" tabindex="-1" role="dialog" id="lotteryCurrentStatusPopup">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Teams</h5>
                <button type="button" onclick="$('#lotteryCurrentStatusPopup').hide()" class="cloas-btn" data-dismiss="modal" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <div class="modal-body" style="max-height: 80vh;overflow: auto;"></div>
        </div>
    </div>
</div>            	
@endsection
@push('breadcrumb-plugins')
    <div class="cust_search">
    	<div class="input-group has_append mr-2">
	        <input type="text" name="cust_ticket_number" class="form-control" placeholder="Ticket Number" id="cust_ticket_number" value="">
	        <div class="input-group-append">
	            <button class="btn btn--primary" type="submit" id="btn_ticket_number"><i class="fa fa-search"></i></button>
	        </div>
    	</div>
    	<div class="input-group has_append">
	        <input type="text" name="cust_username" class="form-control" placeholder="Username" id="cust_username" value="">
	        <div class="input-group-append">
	            <button class="btn btn--primary" type="submit" id="btn_cust_username"><i class="fa fa-search"></i></button>
	        </div>
    	</div>
    </div>
@endpush
