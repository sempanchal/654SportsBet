@extends('admin.layouts.app')
@section('panel')
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <form action="{{ route('admin.lottery.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <div class="row">
                        <!-- <div class="col-md-3"> 
                            <div class="sport_logo">
                                <img id="sport_img_logo" src="{{ asset('assets/images/sport_logo/default.png') }}" class="img-thumbnail">
                            </div>                              
                        </div> -->
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>@lang('Jackpot Name')</label>
                                <input type="text" class="form-control" value="{{ old('jackpot_name') }}" placeholder="@lang('Jackpot Name')" name="jackpot_name"/>
                            </div>
                            <div class="form-group">
                                <label>@lang('Sport')</label>
                                <div>
                                    <select name="name" class="form--control select2" id="sport_id" requierd>
                                        <option value="" data-id="0" >--SELECT--</option>
                                        <option value="NFL" data-id="2" data-url="{{ asset('assets/images/sport_logo/2.png') }}" @if(old('sport_id') == "")selected="selected"@endif>NFL</option>
                                        <option value="NBA" data-id="4" data-url="{{ asset('assets/images/sport_logo/4.png') }}" @if(old('sport_id') == 4)selected="selected"@endif>NBA</option>
                                        <option value="NHL" data-id="6" data-url="{{ asset('assets/images/sport_logo/6.png') }}"  @if(old('sport_id') == 6)selected="selected"@endif>NHL</option>
                                        <option value="MLB" data-id="3" data-url="{{ asset('assets/images/sport_logo/3.png') }}"  @if(old('sport_id') == 3)selected="selected"@endif>MLB</option>
                                        <option value="MLS" data-id="10" data-url="{{ asset('assets/images/sport_logo/10.jpg') }}"  @if(old('sport_id') == 10)selected="selected"@endif>MLS</option>
                                        <option value="EPL" data-id="11" data-url="{{ asset('assets/images/sport_logo/11.jpg') }}"  @if(old('sport_id') == 11)selected="selected"@endif>EPL</option>
                                       
                                    </select>
                                    <input type="hidden" name="sport_id" value="{{ old('sport_id') }}" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label>@lang('Date')</label>
                                <input name="date" data-multiple-dates="true" type="text" data-language="en" class="datepicker-here form-control" value="{{ old('date') }}" data-position="bottom right" data-date-format="yyyy-mm-dd" placeholder="Date" autocomplete="off" readonly>
                            </div>
                            <div class="form-group">
                                <button type="button" id="btn-modal-team" class="btn btn-block btn-primary">Choose Team</button>
                            </div>
                            <!-- <div class="form-group">
                                <label>@lang('Total Winners')</label>
                                <input type="text" class="form-control" value="{{ old('total_winners') }}" placeholder="@lang('To be predicted by the user')" name="total_winners"/>
                            </div> -->
                            <div class="form-group">
                                <label>@lang('Ticket Price')</label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="@lang('Ticket Price')" name="ticket_price" value="{{ old('ticket_price') }}">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">{{ $general->cur_sym }}</span>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>@lang('Revenue Percentage')</label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="@lang('Ticket Price')" name="revenue_percentage" value="{{ old('revenue_percentage',50) }}">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">%</span>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>@lang('Starting Jackpot')</label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="@lang('minimum price money')" name="price" value="{{ old('price') }}">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">{{ $general->cur_sym }}</span>
                                  </div>
                                </div>
                            </div>
                            <!-- 20-12-2021 -->
                            <div class="form-group">
                                <label>@lang('1st place percentage')</label>
                                <input type="number" class="form-control" placeholder="@lang('Winner 1st place percentage')" max="100" name="first_place" value="70">
                            </div>
                            <div class="form-group">
                                <label>@lang('2st place percentage')</label>
                                <input type="number" class="form-control" placeholder="@lang('Winner 2st place percentage')" max="100" name="second_place" value="20">
                            </div>
                            <div class="form-group">
                                <label>@lang('3st place percentage')</label>
                                <input type="number" class="form-control" placeholder="@lang('Winner 3st place percentage')" max="100" name="third_place" value="10">
                            </div>
                            <!-- <input type="hidden" name="choose_team"> -->
                            <!--  -->
                            <!-- <div class="form-group">
                                <label class="form-control-label font-weight-bold">@lang('Jackpot type') </label>
                                <input type="checkbox" value="1" @if(old('jackpot_type'))checked="checked"@endif data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="@lang('Static')" data-off="@lang('Dynamic')" name="jackpot_type">
                            </div> 
                            <div class="form-group">
                                <label class="form-control-label font-weight-bold">@lang('Order Prediction') </label>
                                <input type="checkbox" value="1" @if(old('order_prediction'))checked="checked"@endif data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="@lang('Enable')" data-off="@lang('Disable')" name="order_prediction">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label font-weight-bold">@lang('Money Type') </label>
                                <input type="checkbox" value="1" @if(old('money_type'))checked="checked"@endif data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="@lang('Real Money')" data-off="@lang('Fantasy')" name="money_type">
                            </div>
                            <div class="form-group">
                                <label>@lang('Maximum participants')</label>
                                <input type="text" class="form-control" placeholder="@lang('game closed')" name="maximum_participants" value="{{ old('maximum_participants') }}"/>
                            </div>
                            <div class="form-group">
                                <label class="form-control-label font-weight-bold">@lang('Quick select') </label>
                                <input type="checkbox" value="1" @if(old('quick_select'))checked="checked"@endif data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="@lang('Enable')" data-off="@lang('Disable')" name="quick_select">
                            </div>-->
                            <div class="form-group">
                                <label>@lang('Maximum number of entries per user')</label>
                                <input type="number" class="form-control" placeholder="@lang('0 for infinite')" name="no_of_entries" value="{{ old('no_of_entries') }}"/>
                            </div>
                            <div class="form-group">
                                <!-- nicEdit -->
                                <label>@lang('Game Instruction')</label>
                                <textarea rows="8" class="ckeditor form-control" placeholder="@lang('Game Instruction')" name="detail">{{ old('detail') }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-row justify-content-center">
                        <div class="form-group col-md-12">
                            <button type="submit" class="btn btn-block btn--primary mr-2">@lang('Post')</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@include('admin.lottery.footerdata')
@endsection

@push('breadcrumb-plugins')
<a href="{{ route('admin.lottery.index') }}" class="icon-btn" ><i class="fa fa-fw fa-reply"></i>@lang('Back')</a> 
@endpush
