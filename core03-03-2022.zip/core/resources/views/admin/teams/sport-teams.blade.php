<table class="table custom-table-new">
            <tr>
                <th>Team Id</th>
                <th>Name</th>
                <th>Mascot</th>
                <th>Abbreviation</th>
                <th>Logo</th>
            </tr> 
        @php
            $i = 1;
        @endphp   
        @foreach($sportTeams as $key => $val)
            <tr>
                <td>
                    {{ $val['team_id'] }}
                    <input type="hidden" name="team[{{ $i }}][team_id]" value="{{ $val['team_id'] }}">
                </td>
                <td>
                {{ $val['name'] }}
                <input type="hidden" name="team[{{ $i }}][name]" value="{{ $val['name'] }}">
                </td>
                <td>
                    {{ $val['mascot'] }}
                    <input type="hidden" name="team[{{ $i }}][mascot]" value="{{ $val['mascot'] }}">
                </td>
                <td>
                    {{ $val['abbreviation'] }}
                    <input type="hidden" name="team[{{ $i }}][abbreviation]" value="{{ $val['abbreviation'] }}">
                </td>
                <td>
                    <div class="imageWrapper">
                        <img class="image logoteamimg" src="http://via.placeholder.com/700x500">
                        <input type="file" class="preview_img" name="team[{{ $i }}][logo]" oninvalid="this.setCustomValidity('Team logo is required.')" required/>
                        <!-- <button class="btn btn-primary file-upload ml-2">            
                          Choose Logo
                        </button> -->
                    </div>
                </td>
            </tr>
            @php
                $i++;
            @endphp
        @endforeach
</table>