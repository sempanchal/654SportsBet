
	<table class="table" style="width:100%">
	    <thead class="thead-dark">
	        <tr>
	            <th><?php echo app('translator')->get('Serial Number'); ?></th>
	            <th><?php echo app('translator')->get('Team Name'); ?></th>
	            <th><?php echo app('translator')->get('Team Logo'); ?></th>
	            <th><?php echo app('translator')->get('score'); ?></th>
	            <th><?php echo app('translator')->get('Sigma'); ?></th>
	            <th><?php echo app('translator')->get('away/home'); ?></th>
	        </tr>
	    </thead>
	    <tbody>
	       <?php $__empty_1 = true; $__currentLoopData = $get_teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $teams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	        <tr>
	            <td data-label="<?php echo app('translator')->get('Serial Number'); ?>"><?php echo e($key+1); ?> <?php if(in_array($teams['team_id'],$winning_team_arr) && $teams['score'] > 0): ?> <i class="las la-trophy"></i> <?php endif; ?></td>
	            <td data-label="<?php echo app('translator')->get('Team Name'); ?>"><?php echo e($teams['name']); ?></td>
	            <td data-label="<?php echo app('translator')->get('Team Logo'); ?>"><img src="<?php echo e(log_logos($teams['team_id'])); ?>" alt="logo" height="50" width="50"> <span><?php echo e($teams['abbreviation']); ?></span></td>
	            <td data-label="<?php echo app('translator')->get('Score'); ?>"><?php echo e($teams['score']); ?></td>
	            <td data-label="<?php echo app('translator')->get('Sigma'); ?>"><?php echo e($teams['sigma']); ?></td>
	            <td data-label="<?php echo app('translator')->get('away/home'); ?>"><?php echo e($teams['type']); ?></td>
	        </tr>
	       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	        <tr>
	            <td class="text-muted text-center" colspan="100%"><?php echo app('translator')->get('Date Not Found'); ?></td>
	        </tr>
	       <?php endif; ?>
	    </tbody>
	</table>
<?php /**PATH /var/www/html/core/resources/views/admin/lottery/lotteryCurrentStatus.blade.php ENDPATH**/ ?>