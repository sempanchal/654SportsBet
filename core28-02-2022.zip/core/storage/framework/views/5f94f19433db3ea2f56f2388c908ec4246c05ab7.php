<?php $__env->startSection('content'); ?>
   <section class="pt-50 lottery_wrap">
        <div class="container">
            <div class="row">
             <?php $__empty_1 = true; $__currentLoopData = $events_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-team-popup game-table" data-id="<?php echo e(route('team_popup',$event['id'])); ?>">
                    <div class="arrow-right <?php echo e($event['lottery_status']); ?>">
                        <span><?php echo e($event['lottery_status']); ?></span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                            <img src="<?php echo e(get_sport_logo($event['sport_id'])); ?>" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3><?php echo e($event['jackpot_name']); ?></h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: <?php echo e($event['date']); ?></p>
                                <a href="javascript:void(0);" data-id="<?php echo e(route('rules_popup',$event['id'])); ?>" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                <!-- <a href="javascript:void(0)" data-id="<?php echo e(route('team_popup',$event['id'])); ?>" class="text-white underline mr-3 btn-modal-team-popup">Place Bet</a> -->
                                    <!-- <a href="javascript:void(0)" data-id="<?php echo e(route('team_schedule',$event['id'])); ?>" class="text-white underline btn-modal-schedule-popup">Schedule</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e(showAmount($event['price'],0)); ?></h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e($event['ticket_price']); ?></h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            <!-- Golf -->
           <?php /* ?>
            <?php $__empty_1 = true; $__currentLoopData = $golflotteries_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-golf-popup game-table" data-id="<?php echo e(route('golf_team_popup',$event1['id'])); ?>">
                    <div class="arrow-right <?php echo e($event1['lottery_status']); ?>">
                        <span><?php echo e($event1['lottery_status']); ?></span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                             <img src="<?php echo e(asset('assets/images/sport_logo/golf.png')); ?>" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3><?php echo e($event1['jackpot_name']); ?></h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: <?php echo e($event1['end_date']); ?></p>
                                <!-- <a href="javascript:void(0);" data-id="<?php echo e(route('rules_popup',$event1['id'])); ?>" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e(showAmount($event1['jackpot_price'],0)); ?></h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e($event1['ticket_price']); ?></h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            <?php */ ?>
            </div>
        </div>
    </section>

<!--     <section class="pt-50 pb-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive--md">
                        <table class="table custom--table">
                        <thead>
                        <tr class="dark-gray">
                            <th class="text-center"><?php echo app('translator')->get('Jackpot Game'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Sport'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Rules'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Prize Pool'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Entry'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Actions'); ?></th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center" data-label="<?php echo app('translator')->get('Jackpot Game'); ?>"><?php echo e($event->jackpot_name); ?></td>
                                <td class="text-center" data-label="<?php echo app('translator')->get('Sport'); ?>">
                                    <div class="table-game">
                                        <img src="<?php echo e(get_sport_logo($event->sport_id)); ?>" alt="image" width="50">
                                        <h6 class="name"><?php echo e(__($event->name)); ?></h6>
                                    </div>
                                </td>
                                <td class="text-center" data-label="<?php echo app('translator')->get('Rules'); ?>"><a href="javascript:void(0)" data-id="<?php echo e(route('rules_popup',$event->id)); ?>" class="btn btn-modal-rules-popup btn-sm btn-outline--base dark-gray"><?php echo app('translator')->get('Pay Table and Rules'); ?></a></td>
                                <td class="text-center" data-label="<?php echo app('translator')->get('Prize Pool'); ?>"><?php echo e($general->cur_sym); ?><?php echo e(showAmount($event->price,0)); ?></td>
                                <td class="text-center" data-label="<?php echo app('translator')->get('Entry'); ?>"><?php echo e($general->cur_sym); ?><?php echo e($event->ticket_price); ?></td>
                                <td class="text-center" data-label="<?php echo app('translator')->get('Actions'); ?>">
                                    <a href="javascript:void(0)" data-id="<?php echo e(route('team_popup',$event->id)); ?>" class="btn btn-modal-team-popup btn-sm btn-outline--base dark-gray"><?php echo app('translator')->get('Place Bet'); ?></a>
                                    <a href="javascript:void(0)" data-id="<?php echo e(route('team_schedule',$event->id)); ?>" class="btn btn-modal-schedule-popup btn-sm btn-outline--base dark-gray"><?php echo app('translator')->get('Schedule'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <div class="mt-2">
                <?php echo e($phases->links()); ?>

            </div>
        </div>
    </section> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/templates/basic/lottery.blade.php ENDPATH**/ ?>