<div class="lottery_wrap">
        <div class="card game-table">
            <div class="arrow-right">
                <span><?php echo e($lottery_status); ?></span>
              </div>
          <div class="card-body text-white">
            <div class="d-flex align-items-center">
                    <div class="game-logo-img">
                        <img src="<?php echo e(asset('assets/images/sport_logo/golf.png')); ?>" alt="image" width="100">
                    </div>
                    <div class="d-flex flex-column game-title-wrapper">
                        <h3><?php echo e($golflotteries->jackpot_name); ?></h3>
                        <div class="d-flex justify-content-between">
                            <p>Pool Ends: <?php echo e($end_date); ?></p>
                            <?php /* ?>
                            <a href="javascript:void(0)" data-id="<?php echo e(route('rules_popup',$lottery_id)); ?>" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                            <?php */ ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="cut-footer ticket-info">
                        <ul class="">
                            <li class="text-center">
                                <h5><?php echo e($cur_sym.showAmount($golflotteries->jackpot_price,0)); ?></h5>
                                <span> Prize pool</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5><?php echo e($cur_sym.showAmount($golflotteries->ticket_price,0)); ?></h5>
                                <span>Entry</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5><?php echo e($total_tickets_bought); ?></h5>
                                <span>Total Entries</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
          </div>
        </div>
</div>
<div class="col-12"><hr/></div>
<form action="<?php echo e($action); ?>" method="post" id="form-choose-team" class="golf-form-wrap">
    <?php echo csrf_field(); ?>
    <div class="row">
        <?php $__currentLoopData = $entry_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 myteams text-center myplayer mb-4">
                <input class="golf-form-checkbox" data-val="<?php echo e($player->player_id); ?>" type="checkbox" name="players[]" value="<?php echo e($player->player_id); ?>" />
                <span class="game_ticket text-center">
                    <?php /* ?>
                    <div class="game_ticket_img">
                       <img src="<?php echo e(log_logos($team->team_id)); ?>" alt="logo" height="50" width="100" data-id="<?php echo e($player->team_id); ?>"> 
                    </div>
                    <?php */ ?>
                    <div>
                         <h4><?php echo e($player->country); ?> </h4>
                        <p><?php echo e($player->first_name.' '.$player->last_name); ?></p>
                    </div>
                </span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
               
    <input type="hidden" name="ticket_price" value="<?php echo e($golflotteries->ticket_price); ?>">
    <input type="hidden" name="lottery_id" value="<?php echo e($golflotteries->id); ?>">
</form>
<?php /**PATH /var/www/html/core/resources/views/templates/basic/golf_player.blade.php ENDPATH**/ ?>