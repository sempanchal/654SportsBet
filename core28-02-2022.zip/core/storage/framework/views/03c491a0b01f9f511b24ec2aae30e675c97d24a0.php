<!-- <div class="" id="form-choose-team 1">
    <div class="row">
        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkey => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 text-center mb-4">
            <div class="logo_name_score_wrap">
                <h3><img src="<?php echo e(log_logos($team->team_id)); ?>" alt="logo" height="50" width="50"> <span><?php echo e($team->abbreviation); ?></span></h3>
                <?php echo e($team->mascot); ?>

            </div>
        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div> -->

<div id="form-choose-team">
        <div class="row">
        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkey => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 myteams text-center mb-4">
                <span class="d-flex game_ticket align-items-center">
                    <div class="game_ticket_img">
                       <img src="<?php echo e(log_logos($team->team_id)); ?>" alt="logo" height="50" width="100" data-id="<?php echo e($team->team_id); ?>"> 
                    </div>
                    <div style="text-align: left;width: 50%;">
                         <h4><?php echo e($team->abbreviation); ?> </h4>
                        <p><?php echo e($team->mascot); ?></p>
                    </div>
                </span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>
<?php /**PATH /var/www/html/core/resources/views/templates/basic/user/userTeamsPopup.blade.php ENDPATH**/ ?>