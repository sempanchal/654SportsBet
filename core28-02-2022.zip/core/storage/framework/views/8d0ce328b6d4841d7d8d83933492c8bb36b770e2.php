
<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10">
                <div class="card-body p-0">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('User Name'); ?></th>
                                <th><?php echo app('translator')->get('Lottery - Phase'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Tickets'); ?></th>
                                <th><?php echo app('translator')->get('Result'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('User'); ?>">
                                        <span class="font-weight-bold"><?php echo e(@$ticket->user->fullname); ?></span>
                                        <br>
                                        <span class="small"> <a
                                                href="<?php echo e(route('admin.users.detail', $ticket->user_id)); ?>"><span>@</span><?php echo e(@$ticket->user->username); ?></a> </span>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Lottery - Phase'); ?>">
                                      <?php echo e(__($ticket->lottery->name)); ?> <br>
                                      <?php echo app('translator')->get('Phase'); ?> <?php echo e(__($ticket->phase->phase_number)); ?> 
                                    </td>
                                    <td class="text-center" data-label="<?php echo app('translator')->get('Tickets'); ?>">
                                        <strong><?php echo e($ticket->ticket_number); ?></strong>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Result'); ?>">
                                        <?php if($ticket->phase->draw_status == 1): ?>
                                            <span
                                                class="text--small badge font-weight-normal badge--success"><?php echo app('translator')->get('Published'); ?></span>
                                        <?php else: ?>
                                            <span
                                                class="text--small badge font-weight-normal badge--danger"><?php echo app('translator')->get('Will be Publish'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo e(__($empty_message)); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e($tickets->appends($_GET)->links('admin.partials.paginate')); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
    <form action="<?php echo e(route('admin.report.lotTick.search')); ?>" method="GET" class="form-inline float-sm-right bg--white">
        <div class="input-group has_append">
            <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('Username or ticket number'); ?>"
                   value="<?php echo e($search ?? ''); ?>">
            <div class="input-group-append">
                <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </div>
    </form>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/admin/reports/tickets.blade.php ENDPATH**/ ?>