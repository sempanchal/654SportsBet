<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGolfWorldRankingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('golf_world_rankings', function (Blueprint $table) {
            $table->id();
            $table->text('avg_points');
            $table->text('movement');
            $table->text('num_events');
            $table->integer('player_id');
            $table->text('player_name');
            $table->text('points_gained');
            $table->text('points_lost');
            $table->integer('position');
            $table->text('total_points');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('golf_world_rankings');
    }
}
