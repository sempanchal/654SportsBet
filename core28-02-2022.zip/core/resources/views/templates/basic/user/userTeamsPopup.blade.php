<!-- <div class="" id="form-choose-team 1">
    <div class="row">
        @foreach($teams as $tkey => $team)
        <div class="col-6 text-center mb-4">
            <div class="logo_name_score_wrap">
                <h3><img src="{{ log_logos($team->team_id) }}" alt="logo" height="50" width="50"> <span>{{ $team->abbreviation }}</span></h3>
                {{ $team->mascot }}
            </div>
        </div>
         @endforeach
    </div>
</div> -->

<div id="form-choose-team">
        <div class="row">
        @foreach($teams as $tkey => $team)
            <div class="col-6 myteams text-center mb-4">
                <span class="d-flex game_ticket align-items-center">
                    <div class="game_ticket_img">
                       <img src="{{ log_logos($team->team_id) }}" alt="logo" height="50" width="100" data-id="{{ $team->team_id }}"> 
                    </div>
                    <div style="text-align: left;width: 50%;">
                         <h4>{{ $team->abbreviation }} </h4>
                        <p>{{ $team->mascot }}</p>
                    </div>
                </span>
            </div>
        @endforeach
        </div>
</div>
