@extends($activeTemplate.'layouts.master')
@section('content')
    <section class="pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-mb-12 mb-5">
                    <h3 class="text-center">{{ $sub_title }}</h3>
                </div>
                <div class="col-md-12 mb-30">
                    <table class="table table-responsive--md custom--table">
                        <thead>
                        <tr>
                            <th class="text-center">@lang('Jackpot Game')</th>
                            <th class="text-center">@lang('Date Bet Placed')</th>
                            <th class="text-center">@lang('Bet Amount')</th>
                            <th class="text-center">@lang('Teams Picked ')</th>
                            <th class="text-center">@lang('Ticket Number')</th>
                            <th class="text-center">@lang('Result')</th>
                            <th class="text-center">@lang('Amount Won')</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($tickets_arr as $ticket)
                            <tr>
                                <td data-label="@lang('Jackpot Game')">{{ $ticket['jackport_name'] }}</td>
                                <td data-label="@lang('Date Bet Placed')">
                                    {{ \Carbon\Carbon::parse($ticket['date_bet_placed'])->format('F jS, Y h:i A') }}
                                </td>
                                <td data-label="@lang('Bet Amount')">{{ $ticket['bet_amount'] }}</td>
                                <td data-label="@lang('Teams Picked')">
                                    <a href="javascript:void(0)" data-id="{{ route('user.user_team_popup') }}" class="btn user_team_popup btn-sm btn-outline--base dark-gray" data-lottery_id="{{ $ticket['lottery_id'] }}" data-ticket_id="{{ $ticket['ticket_id'] }}">@lang('View')</a>
                                </td>
                                <td data-label="@lang('Ticket Number')">{{ $ticket['ticket_number'] }}</td>
                                    @if($ticket['lottery_status'] == 'completed')
                                    <td data-label="@lang('Result')">@if($ticket['total_teams_win'] >= 4 ) Won @else Lost @endif</td>
                                    <td data-label="@lang('Amount Won')">
                                        @if($ticket['total_teams_win'] == 4)
                                            {{ $gnl.showAmount(((float)$ticket['win_amount']/(int)$array_cv[$ticket['lottery_id']][4]),2) }}
                                        @elseif($ticket['total_teams_win'] == 5)
                                            {{ $gnl.showAmount(((float)$ticket['win_amount']/(int)$array_cv[$ticket['lottery_id']][5]),2) }}
                                        @elseif($ticket['total_teams_win'] == 6)
                                            {{ $gnl.showAmount(((float)$ticket['win_amount']/(int)$array_cv[$ticket['lottery_id']][6]),2) }}
                                        @else
                                            {{ $gnl.'0' }}
                                        @endif
                                    </td>
                                    @else
                                        <td data-label="@lang('Result')">Pending</td>
                                        <td data-label="@lang('Amount Won')">$0</td>
                                    @endif
                                
                                @empty
                                    <td colspan="7" class="not_found_d">@lang('No Bets Available')</td>
                            </tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
@endsection