@extends($activeTemplate.'layouts.master')
@section('content')
    <!-- dashboard section start -->
    <section class="lottery_wrap">
        <div class="container">
            <div class="row gy-4 align-items-center mt-2">
                <div class="col-lg-3 col-sm-6">
                    <div class="balance-card dark-gray">
                        <span class="text--dark">@lang('Wallet Balance')</span>
                        <h3 class="number text--dark">{{ __($general->cur_sym) }}{{ showAmount(getAmount($user->balance),0) }}</h3>
                    </div><!-- dashboard-card end -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="dashboard-card">
                        <span>@lang('Total Wins')</span>
                        <a href="{{ route('user.my-bets') }}" class="view--btn">@lang('Bet History')</a>
                        <h3 class="number">{{ $total_teams_win }}</h3>
                        <i class="las la-trophy icon"></i>
                    </div><!-- dashboard-card end -->
                </div>
            </div><!-- row end -->
            <div class="row mt-5">
             @forelse($events_arr as $event)
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-team-popup game-table" data-id="{{ route('team_popup',$event['id']) }}">
                    <div class="arrow-right {{ $event['lottery_status'] }}">
                        <span>{{ $event['lottery_status'] }}</span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                            <img src="{{ get_sport_logo($event['sport_id']) }}" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3>{{ $event['jackpot_name'] }}</h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: {{ $event['date'] }}</p>
                                <a href="javascript:void(0);" data-id="{{ route('rules_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                <!-- <a href="javascript:void(0)" data-id="{{ route('team_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-team-popup">Place Bet</a> -->
                                    <!-- <a href="javascript:void(0)" data-id="{{ route('team_schedule',$event['id']) }}" class="text-white underline btn-modal-schedule-popup">Schedule</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ showAmount($event['price'],0) }}</h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ $event['ticket_price'] }}</h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- <div class="row align-items-center">
                        <div class="col-md-2 text-center">
                            <img src="{{ get_sport_logo($event['sport_id']) }}" alt="image" width="100">
                        </div>
                        <div class="col-md-10">
                            <h4 class="card-title">{{ $event['jackpot_name'] }}</h4>
                            <div class="cut-body my-4">
                                <span class="white-colour"><b>Pool End:</b> {{ $event['date'] }}</span>
                                <div class="cut-links">
                                    <a href="javascript:void(0);" data-id="{{ route('rules_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                    
                                </div>
                            </div>
                            <div class="cut-footer mt-2">
                                <ul class="">
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ showAmount($event['price'],0) }}</h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ $event['ticket_price'] }}</h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div> -->
                  </div>
                </div>
              </div>
            @empty
            @endforelse
            </div>
        </div>
    </section>
    <!-- dashboard section end -->
@endsection

@push('style')
    <style>
        .copytext{
            cursor: pointer;
        }
    </style>
@endpush

@push('script')
    <script type="text/javascript">
        (function ($) {
            "use strict";
            $('#copyBoard').click(function(){
                var copyText = document.getElementById("referralURL");
                copyText.select();
                copyText.setSelectionRange(0, 99999);
                /*For mobile devices*/
                document.execCommand("copy");
                // iziToast.success({message: "Copied: " + copyText.value, position: "topRight"});
                Swal.fire({
                    toast: false,
                    title: "Copied: " + copyText.value,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    timer: 5000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            });
        })(jQuery);
    </script>
@endpush
