<form action="{{ $action }}" method="post" id="form-choose-team">
    <div class="table-responsive">
        @foreach($games as $gkey => $game)
        <table class="table custom--table">
            <!-- <thead>
                <tr>
                    <th colspan="2" class="text-center font-15">
                        {{ $game['name'] }}
                        <input type="hidden" name="games[{{ $gkey }}][game_id]" value="{{ $game['game_id'] }}" />
                        <input type="hidden" name="games[{{ $gkey }}][date]" value="{{ $game['date'] }}" />
                        <input type="hidden" name="games[{{ $gkey }}][price]" value="{{ $game['price'] }}" />
                    </th>
                </tr>
            </thead> -->
            <tbody>
                <tr>
                    @foreach($game['teams'] as $tkey => $team)
                    <td class="text-center">
                        <input type="checkbox" name="games[{{ $gkey }}][team_id][]" value="{{ $team['team_id'] }}" @if(in_array($team['team_id'], $active_teams))checked="checked"@endif />
                        <span>
                            {{ $team['name'] }}
                        </span>
                    </td>
                    @endforeach
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="2" class="text-center font-15">
                        {{ $game['name'] }}
                        <input type="hidden" name="games[{{ $gkey }}][game_id]" value="{{ $game['game_id'] }}" />
                        <input type="hidden" name="games[{{ $gkey }}][date]" value="{{ $game['date'] }}" />
                        <input type="hidden" name="games[{{ $gkey }}][price]" value="{{ $game['price'] }}" />
                    </th>
                </tr>
            </tfoot>
        </table>
        @endforeach
    </div>
    <input type="hidden" name="ticket_price" value="{{ $ticket_price }}">
</form>