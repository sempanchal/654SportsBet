<div class="lottery_wrap">
        <div class="card game-table">
            <div class="arrow-right">
                <span>{{ $lottery_status }}</span>
              </div>
          <div class="card-body text-white">
            <div class="d-flex align-items-center">
                    <div class="game-logo-img">
                        <img src="{{ asset('assets/images/sport_logo/golf.png') }}" alt="image" width="100">
                    </div>
                    <div class="d-flex flex-column game-title-wrapper">
                        <h3>{{ $golflotteries->jackpot_name }}</h3>
                        <div class="d-flex justify-content-between">
                            <p>Pool Ends: {{ $end_date }}</p>
                            @php /* @endphp
                            <a href="javascript:void(0)" data-id="{{ route('rules_popup',$lottery_id) }}" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                            @php */ @endphp
                        </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="cut-footer ticket-info">
                        <ul class="">
                            <li class="text-center">
                                <h5>{{ $cur_sym.showAmount($golflotteries->jackpot_price,0) }}</h5>
                                <span> Prize pool</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5>{{ $cur_sym.showAmount($golflotteries->ticket_price,0) }}</h5>
                                <span>Entry</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5>{{ $total_tickets_bought }}</h5>
                                <span>Total Entries</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
          </div>
        </div>
</div>
<div class="col-12"><hr/></div>
<form action="{{ $action }}" method="post" id="form-choose-team" class="golf-form-wrap">
    @csrf
    <div class="row">
        @foreach($entry_lists as $key => $player)
            <div class="col-6 myteams text-center myplayer mb-4">
                <input class="golf-form-checkbox" data-val="{{ $player->player_id }}" type="checkbox" name="players[]" value="{{ $player->player_id }}" />
                <span class="game_ticket text-center">
                    @php /* @endphp
                    <div class="game_ticket_img">
                       <img src="{{ log_logos($team->team_id) }}" alt="logo" height="50" width="100" data-id="{{ $player->team_id }}"> 
                    </div>
                    @php */ @endphp
                    <div>
                         <h4>{{ $player->country }} </h4>
                        <p>{{ $player->first_name.' '.$player->last_name }}</p>
                    </div>
                </span>
            </div>
        @endforeach
    </div>
               
    <input type="hidden" name="ticket_price" value="{{ $golflotteries->ticket_price }}">
    <input type="hidden" name="lottery_id" value="{{ $golflotteries->id }}">
</form>
