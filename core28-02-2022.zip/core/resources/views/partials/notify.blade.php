<link rel="stylesheet" href="{{ asset('assets/global/css/sweetalert2.min.css') }}">
<!-- <link rel=¨stylesheet¨ type=¨text/css¨ href=¨https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css¨> -->
<script src="{{ asset('assets/global/js/sweetalert2.all.min.js') }}"></script>
@if(session()->has('notify'))
    @foreach(session('notify') as $msg)
        <script> 
            "use strict";
            iziToast.{{ $msg[0] }}({message:"{{ __($msg[1]) }}", position: "topRight"}); 
        </script>
    @endforeach
@endif

@if ($errors->any())
    @php
        $collection = collect($errors->all());
        $errors = $collection->unique();
    @endphp

    <script>
        "use strict";
        @foreach ($errors as $error)
        // iziToast.error({
        //     message: '{{ __($error) }}',
        //     position: "topRight"
        // });
        Swal.fire({
            toast: false,
            title: '{{ __($error) }}',
            animation: false,
            position: 'center',
            showConfirmButton: true,
            timer: 5000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });
        @endforeach
    </script>

@endif
<script>
    "use strict";
    function notify(status,message) {
        // iziToast[status]({
        //     message: message,
        //     position: "topRight"
        // });
         Swal.fire({
            toast: false,
            title: message,
            animation: false,
            position: 'center',
            showConfirmButton: true,
            timer: 5000,
            timerProgressBar: true,
            didOpen: (toast) => {
              toast.addEventListener('mouseenter', Swal.stopTimer)
              toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });
    }
</script>
