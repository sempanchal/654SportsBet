<?php

namespace App\Lib;

class RapidAPI
{
    private static $apiUsername = 'dev654@oakridgeinteractive.com';
    private static $apiPassword = 'Score654**';
    private static $apiUrl = 'https://therundown-therundown-v1.p.rapidapi.com/';
    private static $apiKey = '7d37d969e4mshaf130b2861d469dp170318jsn9491abf4d1db';
    private static $apiHost = 'therundown-therundown-v1.p.rapidapi.com';
    
    public static function send($data){
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => self::$apiUrl . $data['url'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "x-rapidapi-host: " . self::$apiHost,
                "x-rapidapi-key: " . self::$apiKey
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        $responseData = json_decode($response, true);
        curl_close($curl);

        if ($err) {
            throw new \Exception("cURL Error #:" . $err);
        } else if(isset($responseData['message'])){
            throw new \Exception($responseData['message']);
        }else{
            return $responseData[$data['return_data']];
        }
    }

    public static function sendEvents($data){
        $returnData = array();

        $dates = @explode(",", $data['dates']);
        foreach ($dates as $date) {
            $curl = curl_init();
    
            curl_setopt_array($curl, [
                CURLOPT_URL => self::$apiUrl . 'sports/'.$data['sport_id'].'/events/'. $date.'?offset=300',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => [
                    "x-rapidapi-host: " . self::$apiHost,
                    "x-rapidapi-key: " . self::$apiKey
                ],
            ]);
    
            $response = curl_exec($curl);
            $err = curl_error($curl);
            $responseData = json_decode($response, true);

            curl_close($curl);

            if ($err) {
                throw new \Exception("cURL Error #:" . $err);
            } else if(isset($responseData['message'])){
                throw new \Exception($responseData['message']);
            }else{
                $returnData[] = $responseData[$data['return_data']];
            }

        }

        return $returnData;
    }

    public static function get_teams_result($sport_id,$dates,$type){
        $returnData = array();
        $dates = @explode(",", $dates);
        $i = 0;
        foreach ($dates as $k => $date) {
            $curl = curl_init();

            curl_setopt_array($curl, [
                CURLOPT_URL => self::$apiUrl . 'sports/'.$sport_id.'/events/'. $date.'?offset=300',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => [
                    "x-rapidapi-host: " . self::$apiHost,
                    "x-rapidapi-key: " . self::$apiKey
                ],
            ]);

            $response = curl_exec($curl);
            $err = curl_error($curl);
            $responseData = json_decode($response, true);

            curl_close($curl);

            if ($err) {
                throw new \Exception("cURL Error #:" . $err);
            } else if(isset($responseData['message'])){
                throw new \Exception($responseData['message']);
            }else{
                //$returnData[] = $responseData[$data['return_data']];
                if(!empty($responseData['events'])){
                    $events = $responseData['events'];
                    /*schedule*/
                    if($type == "schedule"){
                        foreach ($events as $key => $value) {
                            $returnData[$i][$key]['event_id'] = $value['event_id'];
                            $returnData[$i][$key]['sport_id'] = $value['sport_id'];
                            $returnData[$i][$key]['event_date'] = $value['event_date'];
                            $returnData[$i][$key]['score']['event_status'] = $value['score']['event_status'];
                            $returnData[$i][$key]['score']['score_away'] = $value['score']['score_away'];
                            $returnData[$i][$key]['score']['score_home'] = $value['score']['score_home'];
                            if(isset($value['teams'])){
                                foreach ($value['teams'] as $teamsk => $teamsv) {
                                    if($teamsv['is_away'] == 1){
                                        $returnData[$i][$key]['away_team']['score_away'] = $value['score']['score_away'];
                                        $returnData[$i][$key]['away_team']['team_id'] = $teamsv['team_id'];
                                        $returnData[$i][$key]['away_team']['team_normalized_id'] = $teamsv['team_normalized_id'];
                                        $returnData[$i][$key]['away_team']['name'] = $teamsv['name'];
                                        $returnData[$i][$key]['away_team']['mascot'] = $value['teams_normalized'][$teamsk]['mascot'];
                                        $returnData[$i][$key]['away_team']['abbreviation'] = $value['teams_normalized'][$teamsk]['abbreviation'];
                                    }
                                    if($teamsv['is_home'] == 1){
                                        $returnData[$i][$key]['home_team']['score_home'] = $value['score']['score_home'];
                                        $returnData[$i][$key]['home_team']['team_id'] = $teamsv['team_id'];
                                        $returnData[$i][$key]['home_team']['team_normalized_id'] = $teamsv['team_normalized_id'];
                                        $returnData[$i][$key]['home_team']['name'] = $teamsv['name'];
                                        $returnData[$i][$key]['home_team']['mascot'] = $value['teams_normalized'][$teamsk]['mascot'];
                                        $returnData[$i][$key]['home_team']['abbreviation'] = $value['teams_normalized'][$teamsk]['abbreviation'];
                                    }
                                }
                            }else{
                                foreach ($value['teams_normalized'] as $teamsk => $teamsv) {
                                    if($teamsv['is_away'] == 1){
                                        $returnData[$i][$key]['away_team']['score_away'] = $value['score']['score_away'];
                                        $returnData[$i][$key]['away_team']['team_id'] = $teamsv['team_id'];
                                        $returnData[$i][$key]['away_team']['team_normalized_id'] = $teamsv['team_id'];
                                        $returnData[$i][$key]['away_team']['name'] = $teamsv['name'];
                                        $returnData[$i][$key]['away_team']['mascot'] = $value['teams_normalized'][$teamsk]['mascot'];
                                        $returnData[$i][$key]['away_team']['abbreviation'] = $value['teams_normalized'][$teamsk]['abbreviation'];
                                    }
                                    if($teamsv['is_home'] == 1){
                                        $returnData[$i][$key]['home_team']['score_home'] = $value['score']['score_home'];
                                        $returnData[$i][$key]['home_team']['team_id'] = $teamsv['team_id'];
                                        $returnData[$i][$key]['home_team']['team_normalized_id'] = $teamsv['team_id'];
                                        $returnData[$i][$key]['home_team']['name'] = $teamsv['name'];
                                        $returnData[$i][$key]['home_team']['mascot'] = $value['teams_normalized'][$teamsk]['mascot'];
                                        $returnData[$i][$key]['home_team']['abbreviation'] = $value['teams_normalized'][$teamsk]['abbreviation'];
                                    }
                                }
                            }
                        }
                        $i++;
                    }
                    /*end*/
                    /*winner teams score date*/
                    if($type == "winner"){
                        $returnData['status'] = 0;
                         foreach ($events as $key => $value) {
                            if($value['score']['event_status'] == 'STATUS_SCHEDULED'){
                                $returnData['status'] = 1;
                            }
                            if(isset($value['teams'])){
                                foreach ($value['teams'] as $teamsk => $teamsv) {
                                    if($teamsv['is_away'] == 1){
                                        $returnData[$teamsv['team_normalized_id']] = $value['score']['score_away'];
                                    }
                                    if($teamsv['is_home'] == 1){
                                        $returnData[$teamsv['team_normalized_id']] = $value['score']['score_home'];
                                    }
                                }
                            }else{
                                foreach ($value['teams_normalized'] as $teamsk => $teamsv) {
                                    if($teamsv['is_away'] == 1){
                                        $returnData[$teamsv['team_id']] = $value['score']['score_away'];
                                    }
                                    if($teamsv['is_home'] == 1){
                                        $returnData[$teamsv['team_id']] = $value['score']['score_home'];
                                    }
                                }
                            }
                         }
                    }
                    /*end*/
                }
            }

        }
        return $returnData;
    }


    public static function getStatic($data){
        $response = file_get_contents(base_path('storage/app/public/json/'. $data['url'] . '.json'));
        $responseData = json_decode($response, true);
        return $responseData[$data['return_data']];
    }


    public static function get_sport_team($sport_id){
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => self::$apiUrl."sports/".$sport_id."/teams",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "x-rapidapi-host: therundown-therundown-v1.p.rapidapi.com",
                "x-rapidapi-key: 7d37d969e4mshaf130b2861d469dp170318jsn9491abf4d1db"
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
           $result = json_decode($response,true);
           return $result['teams'];
        }
    }

    public static function get_your_team1($sport_id,$dates,$teams){
        $returnData = array();
        $dates = @explode(",", $dates);
        $teams_arr = @explode(",", $teams);
        $i = 0;
        foreach ($dates as $k => $date) {
            $curl = curl_init();

            curl_setopt_array($curl, [
                CURLOPT_URL => self::$apiUrl . 'sports/'.$sport_id.'/events/'. $date.'?offset=300',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => [
                    "x-rapidapi-host: " . self::$apiHost,
                    "x-rapidapi-key: " . self::$apiKey
                ],
            ]);

            $response = curl_exec($curl);
            $err = curl_error($curl);
            $responseData = json_decode($response, true);

            curl_close($curl);

            if ($err) {
                throw new \Exception("cURL Error #:" . $err);
            } else if(isset($responseData['message'])){
                throw new \Exception($responseData['message']);
            }else{
                if(!empty($responseData['events'])){
                    $events = $responseData['events'];
                        foreach ($events as $key => $value) {
                        //echo "<pre>";print_r($value);die;
                            if(isset($value['teams'])){
                                foreach ($value['teams'] as $teamsk => $teamsv) {
                                    if(in_array($value['teams_normalized'][$teamsk]['team_id'],$teams_arr)){

                                        if($teamsv['is_away'] == 1){
                                            $returnData[$i]['score'] = $value['score']['score_away'];
                                            $returnData[$i]['sigma'] = (float)$value['score']['score_away']+1;
                                            $returnData[$i]['type'] = 'Away';
                                        }
                                        if($teamsv['is_home'] == 1){
                                            $returnData[$i]['score'] = $value['score']['score_home'];
                                            $returnData[$i]['sigma'] = (float)$value['score']['score_home']-1;
                                            $returnData[$i]['type'] = 'Home';
                                        }
                                        $returnData[$i]['team_id'] = $value['teams_normalized'][$teamsk]['team_id'];
                                        $returnData[$i]['name'] =   $value['teams_normalized'][$teamsk]['name'];
                                        $returnData[$i]['mascot'] = $value['teams_normalized'][$teamsk]['mascot'];
                                        $returnData[$i]['abbreviation'] = $value['teams_normalized'][$teamsk]['abbreviation'];
                                        $i++;
                                    }
                                }
                            }else{
                                foreach ($value['teams_normalized'] as $teamsk => $teamsv) {
                                    if(in_array($value['teams_normalized'][$teamsk]['team_id'],$teams_arr)){

                                        if($teamsv['is_away'] == 1){
                                            if(isset($value['score']['score_away'])){
                                                $score_away = $value['score']['score_away'];
                                            }else{
                                                $score_away = 0;
                                            }
                                            $returnData[$i]['score'] = $score_away;
                                            $returnData[$i]['sigma'] = (float)$score_away+1;
                                            $returnData[$i]['type'] = 'Away';
                                        }
                                        if($teamsv['is_home'] == 1){
                                            if(isset($value['score']['score_home'])){
                                                $score_home = $value['score']['score_home'];
                                            }else{
                                                $score_home = 0;
                                            }
                                            $returnData[$i]['score'] = $score_home;
                                            $returnData[$i]['sigma'] = (float)$score_home-1;
                                            $returnData[$i]['type'] = 'Home';
                                        }
                                        $returnData[$i]['team_id'] = $value['teams_normalized'][$teamsk]['team_id'];
                                        $returnData[$i]['name'] =   $value['teams_normalized'][$teamsk]['name'];
                                        $returnData[$i]['mascot'] = $value['teams_normalized'][$teamsk]['mascot'];
                                        $returnData[$i]['abbreviation'] = $value['teams_normalized'][$teamsk]['abbreviation'];
                                        $i++;
                                    }
                                }
                            }
                        }
                }
            }

        }
        return $returnData;
    }

}