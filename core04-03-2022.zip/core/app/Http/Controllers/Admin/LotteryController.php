<?php
namespace App\Http\Controllers\Admin;

use App\Models\Lottery;
use App\Models\Game;
use App\Models\Team;
use App\Http\Controllers\Controller;
use App\Models\Phase;
use App\Models\WinBonus;
use App\Rules\FileTypeValidate;
use App\Lib\RapidAPI;
use Carbon\Carbon;
use Illuminate\Http\Request;
use HTMLPurifier;
use Session;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Transaction;
use App\Models\Ticket;
use Mail;
//use Illuminate\Support\Facades\Validator;

class LotteryController extends Controller
{
    public function index(){
    	$pageTitle = "Games";
    	$lotteries = Lottery::orderBy('id','desc')->paginate(getPaginate());
    	$empty_message = "No Data Found";
    	return view('admin.lottery.index',compact('pageTitle','lotteries','empty_message'));
    }

     /*03-03-2022*/
     public function roll_over_price($id){
        //Get lotterie data
        $lotterie = DB::table('lotteries')->where('id',$id)->first();
        $lotterie_price = (float)$lotterie->price+(float)$lotterie->carry_over_amount;

        //Get top winning teams
        $get_teams = get_your_team11($id);
        $score = array_column($get_teams, 'score');
        $type = array_column($get_teams, 'type');
        array_multisort($score, SORT_DESC, $type, SORT_ASC, $get_teams);

        $winning_team_arr = [];
        $only_winning_team_arr = [];
        $team_six_score = 0;
        $team_six_sigma = 0;
        $j = 1;
        foreach ($get_teams as $team_key => $team_value) {
            if($j <= 6){
                $winning_team_arr[$team_value['team_id']] = $team_value['score'];
                $only_winning_team_arr[$team_value['team_id']] = $team_value;
                if($j == 6){
                    $team_six_score = (float)$team_value['score'];
                    $team_six_sigma = (float)$team_value['sigma'];
                }
                $j++;
            }
            if($j > 6){
                if($team_six_score == (float)$team_value['score']){
                    if($team_six_sigma == (float)$team_value['sigma']){
                        $winning_team_arr[$team_value['team_id']] = $team_value['score'];
                        $only_winning_team_arr[$team_value['team_id']] = $team_value;
                    }
                }
            } 
        }
        //end

        //Get lotterie tickets
        $tickets = DB::table('tickets')->where('lottery_id',$id)->get();
        $i = 0;
        $user_lottery_array = [];
        foreach ($tickets as $ticket_key => $ticket_value) {
            $ticket_id = $ticket_value->id;
            $user_id = $ticket_value->user_id;

            $users = DB::table('users')->where('id',$user_id)->first();

            //Get user teams using ticket id
            $user_teams = DB::table('user_teams')->where('lottery_id',$id)->where('ticket_id',$ticket_id)->get();
            $user_lotterie_teams = [];
            $total_score = 0;
            $wc = 0;
            foreach ($user_teams as $utvalue) {
                $user_lotterie_teams[] = $utvalue->team_id;
                if (array_key_exists($utvalue->team_id,$winning_team_arr))
                {
                  $total_score+= (float)$winning_team_arr[$utvalue->team_id];
                  $wc++;
                }
            }

            $user_lottery_array[$i]['total_score'] = $total_score;
            $user_lottery_array[$i]['total_teams_in_winning'] = $wc;
            $i++;
        }
        $score = array_column($user_lottery_array, 'total_score');
        $total_teams_in_winning = array_column($user_lottery_array, 'total_teams_in_winning');
        array_multisort($score, SORT_DESC,$total_teams_in_winning, SORT_DESC, $user_lottery_array);

        $position = 1;
        $temp_total_teams_in_winning = 0;
        $new_user_lottery_array = [];
        $a = 0;
        foreach ($user_lottery_array as $nkey => $nvalue) {
                if((int)$nvalue['total_teams_in_winning'] == 6){
                    $new_user_lottery_array[$a]['position'] = 1;
                }else if((int)$nvalue['total_teams_in_winning'] == 5){
                    $new_user_lottery_array[$a]['position'] = 2;

                }else if((int)$nvalue['total_teams_in_winning'] == 4){
                    $new_user_lottery_array[$a]['position'] = 3;
                }else{
                    $position++;
                    $new_user_lottery_array[$a]['position'] = 0;
                }
            $a++;
        }

        $winner_position = array_column($new_user_lottery_array, 'position');
        $winner_position_count = array_count_values($winner_position);

        $send_to_win = [];
        $stwc = 0;
        foreach($new_user_lottery_array as $nula){
            if((int)$nula['position'] <= 3){
                $send_to_win[$stwc] = $nula;
                $send_to_win[$stwc]['nowisp'] = $winner_position_count[$nula['position']];
                $stwc++;
            }
        }

        $winnerPrice = 0;
        foreach($send_to_win as $keyw => $valuew){
            $positionw = (int)$valuew['position'];
            if($positionw == 1){
                $winnerPrice = $winnerPrice+(((float)$lotterie_price*(int)$lotterie->first_place)/100)/$valuew['nowisp'];

            }
            if($positionw == 2){
                $winnerPrice = $winnerPrice+(((float)$lotterie_price*(int)$lotterie->second_place)/100)/$valuew['nowisp'];
            }
            if($positionw == 3){
                $winnerPrice = $winnerPrice+(((float)$lotterie_price*(int)$lotterie->third_place)/100)/$valuew['nowisp'];
            }
        }
        return $winnerPrice;
    }
    /*03032022*/

    public function create(){
        $pageTitle = "Game Create";
        $lotteries = Lottery::where('add_as_carry_over',0)->orderBy('id','desc')->get();
        $lottery_arr = [];
        foreach($lotteries as $lottery){
            $lottery_dates = explode(",",$lottery->date);
            $lottery_dates_arr = [];
            foreach($lottery_dates as $ldata){
                $lottery_dates_arr[] = strtotime($ldata);
            }
            rsort($lottery_dates_arr);
            $end = Carbon::parse($lottery_dates_arr[0])->toDateTimeString();
            if(Carbon::now() > $end){
                

                $winner_price = $this->roll_over_price($lottery->id);
                $rollOverPrice = (float)$lottery->price - (float)$winner_price;
                $data = [
                   'carry_over_amount' => $rollOverPrice,
                   'jackpot_name' => $lottery->jackpot_name,
                   'jackpot_price' => $lottery->price,
                   'jackpot_id' => $lottery->id,
                ];
                array_push($lottery_arr, $data);
            }
        }
        /*echo "<pre>";
        print_r($lottery_arr);die;*/
        return view('admin.lottery.create',compact('pageTitle','lottery_arr'));
    }

    public function store(Request $request){
    	/*$validator = $request->validate([
    		'name'=>'required',
            'jackpot_name'=>'required',
            'price'=>'required|numeric|gt:0',
            'ticket_price'=>'required|numeric|gt:0',
            'first_place'=>'required|numeric|gt:0',
            'second_place'=>'required|numeric|gt:0',
            'third_place'=>'required|numeric|gt:0',
            'detail'=>'required',
    	]);*/

        $messsages = [
              'name.required'=> 'Please select Sport Name',
              'jackpot_name.required'=> 'You cant leave Jackpot Name field empty',
              'price.required'=> 'You cant leave Starting Jackpot field empty',
              'ticket_price.required'=> 'You cant leave Ticket Price field empty',
              'revenue_percentage.required'=> 'You cant leave revenue percentage field empty',
              'first_place.required'=> 'You cant leave First placee field empty',
              'second_place.required'=> 'You cant leave Second place field empty',
              'third_place.required'=> 'You cant leave Third place field empty',
              'detail.required'=> 'You cant leave Game Instruction field empty',
              'date.required' => 'You cant leave Date field empty',
             ];

        $rules = [
              'name'=>'required',
              'jackpot_name'=>'required',
              'price'=>'required',
              'ticket_price'=>'required',
              'revenue_percentage'=>'required|numeric|gt:0|between:1,100',
              'first_place'=>'required',
              'second_place'=>'required',
              'third_place'=>'required',
              'detail'=>'required',
              'date'=>'required',
        ];

        $sports_data = session('sports_data') ?: array();
        $event_data = session('events') ?: array();
        $team_data = session('teams') ?: array();

        if(empty($sports_data) || empty($event_data) || empty($team_data)){
            $messsages['choose_team.required'] = 'Please select Sport Name and Date then click Choose Team button and select jackpot teams.';
            $rules['choose_team'] = 'required';
        }

        $validator = $this->validate($request,$rules,$messsages);

        $purifier = new HTMLPurifier();
        $detail = $purifier->purify($request->detail);
    	$lottery = Lottery::create([
    		'sport_id'=>$request->sport_id,
    		'name'=>$request->name,
            'jackpot_name'=>$request->jackpot_name,
            'ticket_price'=>$request->ticket_price,
            'revenue_percentage'=>$request->revenue_percentage,
            'carry_over_lottery_id' => $request->carry_over_lottery_id,
            'carry_over_amount' => $request->carry_over_amount,
            'first_place'=>$request->first_place,
            'second_place'=>$request->second_place,
            'third_place'=>$request->third_place,
            'price'=>$request->price,
            'detail'=>$detail,
            'date'=> $request->date,
            'no_of_entries' => $request->no_of_entries,
    	]);
        if($request->carry_over_lottery_id){
            $carry_over_lottery = Lottery::find($request->carry_over_lottery_id);
            $carry_over_lottery->update(['add_as_carry_over'=>1]);
        }
        


        foreach ($event_data as $event_id) {
            $name = $sports_data[$event_id]['event_name'];
            $date = $sports_data[$event_id]['event_date'];
            
            $game = Game::create([
                'lottery_id' => $lottery->id,
                'event_id' => $event_id,
                'name' => $name,
                'date' => $date,
            ]);

            if(isset($team_data[$event_id]) && is_array($team_data[$event_id])){
                foreach ($team_data[$event_id] as $team_id) {
                    $name = $sports_data[$event_id]['teams'][$team_id]['name'];
                    $mascot = $sports_data[$event_id]['teams'][$team_id]['mascot'];
                    $abbreviation = $sports_data[$event_id]['teams'][$team_id]['abbreviation'];
                    $is_away = $sports_data[$event_id]['teams'][$team_id]['is_away'];
                    $is_home = $sports_data[$event_id]['teams'][$team_id]['is_home'];
                    
                    $team = Team::create([
                        'lottery_id' => $lottery->id,
                        'game_id' => $game->id,
                        'team_id' => $team_id,
                        'name' => $name,
                        'mascot' => $mascot,
                        'abbreviation' => $abbreviation,
                        'is_away' => (int)$is_away,
                        'is_home' => (int)$is_home,
                    ]);
                }
            }
        }

        Session::forget('sports_data');
        Session::forget('events');
        Session::forget('teams');
        
    	$notify[] = ['success','Game created successfully'];
    	return redirect()->route('admin.lottery.winBonus',$lottery->id)->withNotify($notify);
    }

    public function update($id){
        $pageTitle = "Update Game";
        $lottery = Lottery::findOrFail($id);

        return view('admin.lottery.update',compact('lottery','pageTitle',));
    }

    public function edit(Request $request,$id){
    	$request->validate([
    		'name'=>'required',
            'jackpot_name'=>'required',
    		'price'=>'required|numeric|gt:0',
            'ticket_price'=>'required|numeric|gt:0',
            'revenue_percentage'=>'required|numeric|gt:0|between:1,100',
            'first_place'=>'required|numeric|gt:0',
            'second_place'=>'required|numeric|gt:0',
            'third_place'=>'required|numeric|gt:0',
            'detail'=>'required',
    	]);
    	$lottery = Lottery::find($id);

        $purifier = new HTMLPurifier();
        $detail = $purifier->purify($request->detail);
        $lottery->update([
    		'sport_id'=>$request->sport_id,
    		'name'=>$request->name,
            'jackpot_name'=>$request->jackpot_name,
            'ticket_price'=>$request->ticket_price,
            'revenue_percentage'=>$request->revenue_percentage,
            'first_place'=>$request->first_place,
            'second_place'=>$request->second_place,
            'third_place'=>$request->third_place,
            'price'=>$request->price,
            'detail'=>$detail,
            'date'=> $request->date,
            'no_of_entries' => $request->no_of_entries,
    	]);

    	$notify[] = ['success','Game uploaded successfully'];
    	return back()->withNotify($notify);

    }

    public function status($id){
    	$lottery = Lottery::find($id);
    	if ($lottery->status == 1) {
    		$lottery->update(['status'=>0]);
    	}else{
    		$lottery->update(['status'=>1]);
    	}
    	$notify[] = ['success','Game Status Updated'];
    	return back()->withNotify($notify);
    }

    public function phases(){
        $pageTitle = "Game Phases";
        $lotteries = Lottery::where('status',1)->get();
        $phases = Phase::with('lottery')->orderBy('id','desc')->whereHas('lottery',function($lottery){
            $lottery->where('status',1);
        })->paginate(getPaginate(15));
        $empty_message = "No Data Found";

        return view('admin.lottery.phases',compact('pageTitle','lotteries','phases', 'empty_message'));
    }

    public function lotteryPhase($lottery_id){
        $lottery = Lottery::findOrFail($lottery_id);
        $phases = Phase::where('lottery_id',$lottery_id)->with('lottery')->orderBy('id','desc')->paginate(getPaginate());
        $pageTitle = "Game Phase: ".$lottery->name;
        $empty_message = "No Data Found";
        $lotteries = Lottery::orderBy('name')->get();

        return view('admin.lottery.phases',compact('pageTitle','lottery','phases', 'empty_message', 'lotteries'));
    }

    public function phaseCreate(Request $request){
        $request->validate([
            'lottery_id'=>'required',
            'start'=>'required',
            'end'=>'required',
            'quantity'=>'required|integer|min:1',
            'draw_type'=>'required',
        ]);
        $lottery = Lottery::where('status',1)->findOrFail($request->lottery_id);
        if(collect($lottery->bonuses)->count() < 1){
            $notify[] = ['error','Create Game Bonus First'];
            return back()->withNotify($notify);
        }
        $exist = Phase::where('lottery_id',$request->lottery_id)->where('draw_status',0)->first();
        if ($exist) {
            $notify[] = ['error','Already 1 phase is running of this game'];
            return back()->withNotify($notify);
        }
        $start = Carbon::parse($request->start)->toDateTimeString();
        $end = Carbon::parse($request->end)->toDateTimeString();
        if(Carbon::now() > $end){
            $notify[] = ['error','End date must be a future date'];
            return back()->withNotify($notify);
        }
        if($start > $end){
            $notify[] = ['error','End date must be greater than start date'];
            return back()->withNotify($notify);
        }
        $phase_number = $lottery->phase->count();
        Phase::create([
            'lottery_id'=>$request->lottery_id,
            'phase_number'=>$phase_number + 1,
            'end'=>$end,
            'start'=>$start,
            'quantity'=>$request->quantity,
            'available'=>$request->quantity,
            'at_dr'=>$request->draw_type,
        ]);
        $notify[] = ['success','Game Phase Created Successfully'];
        return back()->withNotify($notify);
    }

    public function phaseUpdate(Request $request,$id){
        $request->validate([
            'end'=>'required',
            'start'=>'required',
            'quantity'=>'required|integer|min:1',
            'draw_type'=>'required',
        ]);
        $phase = Phase::where('status',1)->findOrFail($id);
        $start = Carbon::parse($request->start)->toDateTimeString();
        $end = Carbon::parse($request->end)->toDateTimeString();
        if(Carbon::now() > $end){
            $notify[] = ['error','End date must be a future date'];
            return back()->withNotify($notify);
        }
        if($start > $end){
            $notify[] = ['error','End date must be greater than start date'];
            return back()->withNotify($notify);
        }
        if ($request->quantity < $phase->salled) {
            $notify[] = ['error','Quantity must be greater than salled ticket'];
            return back()->withNotify($notify);
        }
        $phase->update([
            'end'=>Carbon::parse($request->end)->toDateTimeString(),
            'start'=>Carbon::parse($request->start)->toDateTimeString(),
            'quantity'=>$request->quantity,
            'available'=>$request->quantity - $phase->salled,
            'at_dr'=>$request->draw_type,
        ]);
        $notify[] = ['success','Game Phase Updated Successfully'];
        return redirect()->route('admin.lottery.phase.index')->withNotify($notify);
    }

    public function phaseStatus($id){
        $phase = Phase::find($id);
        if (!$phase) {
            $notify[] = ['error','Game Phase Not Found'];
            return back()->withNotify($notify);
        }
        if ($phase->status == 1) {
            $phase->update(['status'=>0]);
        }else{
            $phase->update(['status'=>1]);
        }

        $notify[] = ['success','Game Phase Status Updated Successfully'];
        return back()->withNotify($notify);
    }

    public function winBonus($id){
        $lottery = Lottery::find($id);
        $pageTitle = "Set Win Bonus For ".$lottery->name;
        return view('admin.lottery.winBonus',compact('lottery','pageTitle'));
    }

    public function bonus(Request $request){
        $this->validate($request, [
            'level.*' => 'required|integer|min:1',
            'amount.*' => 'required|numeric',
            'lottery_id' => 'required',
        ]);
        $bonuses = WinBonus::where('lottery_id',$request->lottery_id)->get();
        if ($bonuses->count() > 0) {
            foreach ($bonuses as $bonus) {
                $bonus->delete();
            }
        }
        for ($a = 0; $a < count($request->level); $a++){
            WinBonus::create([
                'level' => $request->level[$a],
                'amount' => $request->amount[$a],
                'lottery_id' => $request->lottery_id,
                'status' => 1,
            ]);
        }
        $notify[] = ['success', 'Create Successfully'];
        return back()->withNotify($notify);

    }

    public function get_team(Request $request){
        $json = array();
        
        $this->validate($request, [
            'sport_id' => 'required|numeric',
            'date' => 'required',
        ]);
        
        $data = array(
            'return_data' => 'events',
            'sport_id' => $request->sport_id,
            'dates' => $request->date,
        );
        $events = RapidAPI::sendEvents($data);

        $event_data = session('events') ?: array();
        $team_data = session('teams') ?: array();

        $action = route('admin.lottery.save_team');

        $json['html'] = view('admin.lottery.team',compact('events','action','event_data','team_data'))->render();
        $json['success'] = true;

        return response()->json($json);
    }

    public function save_team(Request $request){
        $json = array();
        
        $this->validate($request, [
            'event_id' => 'required',
            'team_id' => 'required',
        ]);

        $sports_data = $request->event;
        $event_data = $request->event_id;
        $team_data = $request->team_id;
        
        Session::put('sports_data', $sports_data);
        Session::put('events', $event_data);
        Session::put('teams', $team_data);

        $json['success'] = true;

        return response()->json($json);
    }

    /*25-12-2021*/
    public function winner($id){
        //Get lotterie data
        $lotterie = DB::table('lotteries')->where('id',$id)->first();
        $lotterie_sportId = $lotterie->sport_id;
        $lotterie_date = $lotterie->date;
        $lotterie_id = $lotterie->id;
        $lotterie_price = (float)$lotterie->price+(float)$lotterie->carry_over_amount;
        $sent_prize = $lotterie->sent_prize;
        $last_update_score = $lotterie->last_update_score;

        $lottery_dates = explode(",",$lotterie_date);
        $lottery_dates_arr = [];
        foreach($lottery_dates as $ldata){
            $lottery_dates_arr[] = strtotime($ldata);
        }
        rsort($lottery_dates_arr);
        $end = Carbon::parse($lottery_dates_arr[0])->toDateTimeString();
        $lsdc = count($lottery_dates_arr)-1;
        $lotterie_sdate =  Carbon::parse($lottery_dates_arr[$lsdc])->format('F jS, Y H:i');
        $lotterie_edate =  Carbon::parse($lottery_dates_arr[0])->format('F jS, Y H:i');
        if(Carbon::now() > $end){
            $lottery_status = "completed";
        }else{
            $lottery_status = "pending";
        }

        //============================================================================//

        //Get top winning teams
        $teams = DB::table('teams')->where('lottery_id',$id)->select('team_id')->get();
        $teams_arr = [];
        foreach ($teams as $tvalue) {
            $teams_arr[] = $tvalue->team_id;
        }
        $teams_str = implode(',', $teams_arr);
        $get_teams = get_your_team11($id);
        $score = array_column($get_teams, 'score');
        $type = array_column($get_teams, 'type');
        array_multisort($score, SORT_DESC, $type, SORT_ASC, $get_teams);

        $winning_team_arr = [];
        $only_winning_team_arr = [];
        $team_six_score = 0;
        $team_six_sigma = 0;
        $j = 1;

        foreach ($get_teams as $team_key => $team_value) {
            if($j <= 6){
                $winning_team_arr[$team_value['team_id']] = $team_value['score'];
                $only_winning_team_arr[$team_value['team_id']] = $team_value;
                if($j == 6){
                    $team_six_score = (float)$team_value['score'];
                    $team_six_sigma = (float)$team_value['sigma'];
                }
                $j++;
            }
            if($j > 6){
                if($team_six_score == (float)$team_value['score']){
                    if($team_six_sigma == (float)$team_value['sigma']){
                        $winning_team_arr[$team_value['team_id']] = $team_value['score'];
                        $only_winning_team_arr[$team_value['team_id']] = $team_value;
                    }
                }
            } 
        }
        //end

        // Get lotterie tickets
        $tickets = DB::table('tickets')->where('lottery_id',$id)->get();
        $i = 0;
        $user_lottery_array = [];
        foreach ($tickets as $ticket_key => $ticket_value) {
            $ticket_id = $ticket_value->id;
            $user_id = $ticket_value->user_id;

            $users = DB::table('users')->where('id',$user_id)->first();

            //Get user teams using ticket id
            $user_teams = DB::table('user_teams')->where('lottery_id',$id)->where('ticket_id',$ticket_id)->get();
            $user_lotterie_teams = [];
            $total_score = 0;
            $wc = 0;
            foreach ($user_teams as $utvalue) {
                $user_lotterie_teams[] = $utvalue->team_id;
                if (array_key_exists($utvalue->team_id,$winning_team_arr))
                {
                  $total_score+= (float)$winning_team_arr[$utvalue->team_id];
                  $wc++;
                }
            }

            $user_lottery_array[$i]['username'] = $users->username;
            $user_lottery_array[$i]['email'] = $users->email;
            $user_lottery_array[$i]['total_score'] = $total_score;
            $user_lottery_array[$i]['total_teams_in_winning'] = $wc;
            $user_lottery_array[$i]['ticket_id'] = $ticket_id;
            $user_lottery_array[$i]['ticket_number'] = $ticket_value->ticket_number;
            $user_lottery_array[$i]['user_id'] = $user_id;
            $user_lottery_array[$i]['user_teams'] = implode(',',$user_lotterie_teams);
            $user_lottery_array[$i]['transfer_winning_amount'] = $ticket_value->transfer_winning_amount;
            $user_lottery_array[$i]['lotterie_price'] = $lotterie_price;
            $i++;
        }
        $score = array_column($user_lottery_array, 'total_score');
        $total_teams_in_winning = array_column($user_lottery_array, 'total_teams_in_winning');
        array_multisort($score, SORT_DESC,$total_teams_in_winning, SORT_DESC, $user_lottery_array);

        $position = 1;
        $temp_total_teams_in_winning = 0;
        $new_user_lottery_array = [];
        $a = 0;
        foreach ($user_lottery_array as $nkey => $nvalue) {
                if((int)$nvalue['total_teams_in_winning'] == 6){
                    $temp_total_teams_in_winning = $nvalue['total_teams_in_winning'];
                    $new_user_lottery_array[$a] = $nvalue;
                    $new_user_lottery_array[$a]['position'] = 1;
                }else if((int)$nvalue['total_teams_in_winning'] == 5){
                    $temp_total_teams_in_winning = $nvalue['total_teams_in_winning'];
                    $new_user_lottery_array[$a] = $nvalue;
                    $new_user_lottery_array[$a]['position'] = 2;

                }else if((int)$nvalue['total_teams_in_winning'] == 4){
                    $temp_total_teams_in_winning = $nvalue['total_teams_in_winning'];
                    $new_user_lottery_array[$a] = $nvalue;
                    $new_user_lottery_array[$a]['position'] = 3;
                }else{
                    $position++;
                    $temp_total_teams_in_winning = $nvalue['total_teams_in_winning'];
                    $new_user_lottery_array[$a] = $nvalue;
                    $new_user_lottery_array[$a]['position'] = 0;
                }
            $a++;
        }

        $winner_position = array_column($new_user_lottery_array, 'position');
        $winner_position_count = array_count_values($winner_position);

        $send_to_win = [];
        $stwc = 0;
        foreach($new_user_lottery_array as $nula){
            if((int)$nula['position'] <= 3){
                $send_to_win[$stwc] = $nula;
                $send_to_win[$stwc]['nowisp'] = $winner_position_count[$nula['position']];
                $stwc++;
            }
        }

        $winner_statistics = [];
        $sp = 0;
        foreach($send_to_win as $keyw => $valuew){
            $positionw = (int)$valuew['position'];
            if($positionw == 1){
                $winner_statistics[$positionw][$sp] = $valuew;
                $winning_price = (((float)$valuew['lotterie_price']*(int)$lotterie->first_place)/100)/$valuew['nowisp'];
                $winner_statistics[$positionw][$sp]['winning_price'] = $winning_price;
            }
            if($positionw == 2){
                $winner_statistics[$positionw][$sp] = $valuew;
                $winning_price = (((float)$valuew['lotterie_price']*(int)$lotterie->second_place)/100)/$valuew['nowisp'];
                $winner_statistics[$positionw][$sp]['winning_price'] = $winning_price;
            }
            if($positionw == 3){
                $winner_statistics[$positionw][$sp] = $valuew;
                $winning_price = (((float)$valuew['lotterie_price']*(int)$lotterie->third_place)/100)/$valuew['nowisp'];
                $winner_statistics[$positionw][$sp]['winning_price'] = $winning_price;
            }
            $sp++;
        }
        

        $send_mail_data = json_encode($send_to_win);

        $pageTitle = "Winner";
        return view('admin.lottery.winner',compact('pageTitle','new_user_lottery_array','lotterie_sportId','lotterie_id','lottery_status','lotterie','lotterie_date','lotterie_sdate','lotterie_edate','winner_position_count','send_mail_data','sent_prize','only_winning_team_arr','winner_statistics','lotterie_price','last_update_score'));

    }
    /*End*/


    public function winner_team_popup(Request $request){
        $json = array();
        $teams = DB::table('user_teams')->where('lottery_id',$request->lotterie_id)->where('ticket_id',$request->ticket_id)->get();
        //print_r($teams);die;
        $json['html'] = view('admin.lottery.userlotteryTeams',compact('teams'))->render();
        $json['success'] = true;
        return response()->json($json);
    }
    /*07-01-2022*/
    public function send_win_amount(Request $request){
        $json = array();
        $lotterie_id = $request->lotterie_id;
        //$lottery = DB::table('lotteries')->where('id',$lotterie_id)->first();
        $lottery = Lottery::find($lotterie_id);
        $lottery_name = $lottery->  jackpot_name;
        $price = (float)$lottery->price;
        $first_place = (int)$lottery->first_place;
        $second_place = (int)$lottery->second_place;
        $third_place = (int)$lottery->third_place;

        $win_data = json_decode($request->win_data);
        foreach($win_data as $key => $value){
            $ticket_num = $value->ticket_number;
            $ticket = Ticket::find($value->ticket_id);
            $user_id = $value->user_id;
            $user = User::find($user_id);
            $userEmail = $user->email;
            $userName = $user->firstname.'-'.$user->lastname;
            $balance = (float)$user->balance;

            $nowisp = $value->nowisp;
            if((int)$value->position == 1){
                $winning_price = (((float)$price*(int)$first_place)/100)/$nowisp;
            }
            if((int)$value->position == 2){
                $winning_price = (((float)$price*(int)$second_place)/100)/$nowisp;
            }
            if((int)$value->position == 3){
                $winning_price = (((float)$price*(int)$third_place)/100)/$nowisp;
            }
            
            if($winning_price){
                // add balance to  winner wallet
                $available_balance = $balance+$winning_price;
                $user->balance = $available_balance;
                $add_balance = $user->save();
                if($add_balance){
                    //send mail
                    $subject = "Congratulations, you've won! 654sportsbet lottery";
                    $message = '<div align="center"><table align="center" border="0">
                                    <tr>
                                        <th>Lottery</th>
                                        <td>'.$lottery_name.'</td>
                                    </tr>
                                    <tr>
                                        <th>Won amount</th>
                                        <td>$'.$winning_price.'</td>
                                    </tr>
                                    <tr>
                                        <th>Ticket ID</th>
                                        <td>'.$ticket_num.'</td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">winning prize is sent to your wallet</th>
                                    </tr>   
                                </table></div>';
                    $receiver_name = "sunny panchal";
                    sendGeneralEmail($userEmail, $subject, $message, $userName);

                    // create new transaction
                    $trx = getTrx();
                    $transaction = new Transaction();
                    $transaction->user_id = $user_id;
                    $transaction->amount = $winning_price;
                    $transaction->charge = 0;
                    $transaction->post_balance = $available_balance;
                    $transaction->trx_type = '+';
                    $transaction->trx =  $trx;
                    $transaction->details = "Add lottery winning price";
                    $transaction->ticket_id = $value->ticket_id;
                    $transaction->save();

                    $winning_amount = ['transfer_winning_amount' => 1,'send_mail' => 1];
                    $ticket->update($winning_amount);
                }
            }
        }
        $lottery->update(["sent_prize" => 1]);
        $json['success'] = true;
        $json['add_balance_msg'] = "Transfer winning amount to winner successfully.";
        return response()->json($json);    
    }
    /*07-01-2022*/
    
    public function winner_send_mail_popup(Request $request){
        $json = array();
        $ticket_id = $request->ticket_id;
        $lotterie_id = $request->lotterie_id;
        $user_id = $request->user_id;
        //$place = (int)$request->place;
        $position = (int)$request->position;
        $nowisp = (int)$request->nowisp;

        $ticket = Ticket::find($ticket_id);
        $lottery = DB::table('lotteries')->where('id',$lotterie_id)->first();

        $user = User::find($user_id);
        $userEmail = $user->email;
        $userName = $user->firstname.'-'.$user->lastname;

        $balance = (float)$user->balance;

        if($position == 1){
            $winning_price = (((float)$lottery->price*(int)$lottery->first_place)/100)/$nowisp;
        }
        if($position == 2){
            $winning_price = (((float)$lottery->price*(int)$lottery->second_place)/100)/$nowisp;
        }
        if($position == 3){
            $winning_price = (((float)$lottery->price*(int)$lottery->third_place)/100)/$nowisp;
        }
        //echo $winning_price;die;

        if($winning_price){
            // add balance to  winner wallet
            $available_balance = $balance+$winning_price;
            $user->balance = $available_balance;
            $add_balance = $user->save();
            if($add_balance){
                // create new transaction
                $trx = getTrx();
                $transaction = new Transaction();
                $transaction->user_id = auth()->user()->id;
                $transaction->amount = $winning_price;
                $transaction->charge = 0;
                $transaction->post_balance = $available_balance;
                $transaction->trx_type = '+';
                $transaction->trx =  $trx;
                $transaction->details = "Add lottery winning price";
                $transaction->ticket_id = $ticket_id;
                $transaction->save();

                $winning_amount = ['transfer_winning_amount' => 1,'send_mail' => 1];
                $ticket->update($winning_amount);
                $json['success'] = true;
                $json['add_balance_msg'] = "Transfer winning amount to winner successfully.";

                return response()->json($json);                
            }
            //$subject = "Winning Mail";
            //$message = "mail send for winner";
            //$receiver_name = 'receiver_name';
            //sendGeneralEmail($userEmail, $subject, $message, $receiver_name);
            /*Mail::send('mail', $ticket, function ($message){
                $message->from('sunny@telsamedia.com', 'sunny panchal');
                $message->sender('sunny@telsamedia.com', 'sunny panchal');
                $message->to($userEmail, 'John Doe to');
                //$message->cc($userEmail, 'John Doe cc');
                //$message->bcc($userEmail, 'John Doe bcc');
                //$message->replyTo('vivek@telsamedia.com', 'vivek prajapti');
                $message->subject('invoice mail..');
                //$message->priority(3);
                //$message->attach('pathToFile');
            });*/
             /*$data = array('name'=>"Virat Gandhi");
              Mail::send('mail', $data, function($message) {
                 $message->to('panchal.sun15@gmail.com', 'Tutorials Point')->subject
                    ('Laravel Testing Mail with Attachment');
                 //$message->attach('C:\laravel-master\laravel\public\uploads\image.png');
                 //$message->attach('C:\laravel-master\laravel\public\uploads\test.txt');
                 //$message->from('xyz@gmail.com','Virat Gandhi');
              });*/
        }
    }

    public function lottery_current_status(Request $request){
        $json = array();
        $lotterie_id = $request->lotterie_id;
        $sportId = $request->sportId;
        $lotterie_date = $request->lotterie_date;
        $teams = DB::table('teams')->where('lottery_id',$lotterie_id)->select('team_id')->get();
        $teams_arr = [];
        foreach ($teams as $key => $value) {
            $teams_arr[] = $value->team_id;
        }
        $teams_str = implode(',', $teams_arr);

        $get_teams = get_your_team11($lotterie_id);
        // echo "<pre>";
        // print_r($get_teams);
        // echo "<pre>";die;

        $score = array_column($get_teams, 'score');
        $type = array_column($get_teams, 'type');
        array_multisort($score, SORT_DESC, $type, SORT_ASC, $get_teams);
        //print_r($get_teams);die;
        /*25-12-2021*/
        //get top winning teams
        $winning_team_arr = [];
        $team_six_score = 0;
        $team_six_sigma = 0;
        $j = 1;
        foreach ($get_teams as $team_key => $team_value) {
            if($j <= 6){
                $winning_team_arr[] = $team_value['team_id'];
                if($j == 6){
                    $team_six_score = (float)$team_value['score'];
                    $team_six_sigma = (float)$team_value['sigma'];
                }
                $j++;
            }
            if($j > 6){
                if($team_six_score == (float)$team_value['score']){
                    if($team_six_sigma == (float)$team_value['sigma']){
                        $winning_team_arr[] = $team_value['team_id'];
                    }
                }
            } 
        }

        if($get_teams){
            $json['success'] = true;
            $json['html'] = view('admin.lottery.lotteryCurrentStatus',compact('get_teams','winning_team_arr'))->render();
        }else{
            $json['error'] = true;
        }
        return response()->json($json);
    }

    /*08-02-2022*/
    public function update_score(Request $request){
        $currnt_date_time = Carbon::now();
        $lotterie = Lottery::find($request->lotterie_id);
        $sport_id = $lotterie->sport_id;
        $date = $lotterie->date;

       $score_data = RapidAPI::get_teams_result($sport_id,$date,"winner");
       if(!empty($score_data)){
            $teams = Team::where('lottery_id',$request->lotterie_id)->get();
            foreach($teams as $team_key => $team_value){
                $id_team = $team_value->id;
                $lottery_id_team = $team_value->lottery_id;
                $game_id_team = $team_value->game_id;
                $team_id_team = $team_value->team_id;
                $name_team = $team_value->name;
                $mascot_team = $team_value->mascot;
                $abbreviation_team = $team_value->abbreviation;
                $is_away_team = $team_value->is_away;
                $is_home_team = $team_value->is_home;
                $match_date_team = $team_value->match_date;
                $score_team = $team_value->score;

                if(array_key_exists($team_id_team, $score_data)){ 
                    $save_score = Team::find($id_team);
                    $save_score->score = $score_data[$team_id_team];
                    $save_score->save();
                    //echo "<pre>";
                    //info("update--".$score_data[$team_id_team]);
                    //echo "</pre>";
                }
            }
        $lotterie->update(['last_update_score' => $currnt_date_time]);
       }
    }

    public function deleteLottery($lottery_id){
        $ticket = DB::table('tickets')->where('lottery_id',$lottery_id);
        if($ticket){
            $ticket->delete();    
            $lottery = Lottery::findOrFail($lottery_id);
            if($lottery){
                $lottery->delete();    
            }
        }
        $notify[] = ['success','Game created successfully'];
        return redirect()->route('admin.lottery.index')->withNotify($notify);
    }

}
