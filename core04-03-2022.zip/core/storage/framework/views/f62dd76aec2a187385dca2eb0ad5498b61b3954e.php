<?php
	$captcha = loadCustomCaptcha();
?>
<?php if($captcha): ?>
    <div class="form-group <?php if(request()->routeIs('user.register')): ?> col-lg-6 <?php endif; ?>">
        <?php echo $captcha ?>
    </div>
    <div class="form-group <?php if(request()->routeIs('user.register')): ?> col-lg-6 <?php endif; ?>">
        <input type="text" name="captcha" placeholder="<?php echo app('translator')->get('Enter Code'); ?>" class="form--control" required>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/core/resources/views/templates/basic/partials/custom_captcha.blade.php ENDPATH**/ ?>