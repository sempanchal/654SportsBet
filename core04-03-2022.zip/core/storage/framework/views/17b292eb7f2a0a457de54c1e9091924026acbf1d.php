

<?php $__env->startSection('panel'); ?>
<div class="row">

    <div class="col-lg-12">
        <div class="card b-radius--10">
            <div class="card-body p-0">
                <div class="table-responsive--sm table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Sports'); ?></th>
                                <th><?php echo app('translator')->get('Jackpot Name'); ?></th>
                                <th><?php echo app('translator')->get('Jackpot Price'); ?></th>
                                <th><?php echo app('translator')->get('Carry Over Amount'); ?></th>
                                <th><?php echo app('translator')->get('Total Price'); ?></th> 
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $lotteries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lottery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Game Name'); ?>"><?php echo e($lottery->name); ?></td>
                                <td data-label="<?php echo app('translator')->get('Jackpot Name'); ?>"><?php echo e($lottery->jackpot_name); ?></td>
                                <td data-label="<?php echo app('translator')->get('Price'); ?>"><?php echo e(getAmount($lottery->price)); ?> <?php echo e($general->cur_text); ?></td>
                                <td data-label="<?php echo app('translator')->get('Carry Over Amount'); ?>"><?php if((float)$lottery->carry_over_amount>0): ?><?php echo e($lottery->carry_over_amount); ?>  <?php else: ?> 0 <?php endif; ?> <?php echo e($general->cur_text); ?></td>
                                 <td data-label="<?php echo app('translator')->get('Total Price'); ?>"><?php echo e((float)getAmount($lottery->price)+(float)$lottery->carry_over_amount); ?> <?php echo e($general->cur_text); ?></td>
                                <!--<td data-label="<?php echo app('translator')->get('Total Draw'); ?>"><?php echo e($lottery->phase->where('draw_status',1)->count()); ?></td> -->
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($lottery->status == 1): ?>
                                        <span class="text--small badge font-weight-normal badge--success">
                                            <?php echo app('translator')->get('active'); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text--small badge font-weight-normal badge--danger">
                                            <?php echo app('translator')->get('inactive'); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a href="<?php echo e(route('admin.lottery.edit',$lottery->id)); ?>" class="icon-btn"><i class="la la-pencil"></i></a>
                                    <a href="<?php echo e(route('admin.lottery.winner',$lottery->id)); ?>" class="icon-btn bg--info" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Jackpot Winner'); ?>"><i class="las la-trophy"></i></a>
                                    <a href="<?php echo e(route('admin.lottery.phase.singleLottery',$lottery->id)); ?>" class="icon-btn bg--7" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('See Phases'); ?>"><i class="fas fa-layer-group"></i></a>
                                    <?php if($lottery->status == 1): ?>
                                        <a href="<?php echo e(route('admin.lottery.status',$lottery->id)); ?>" class="icon-btn bg--danger"><i class="la la-eye-slash"></i></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('admin.lottery.status',$lottery->id)); ?>" class="icon-btn bg--success"><i class="la la-eye"></i></a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('admin.lottery.delete',$lottery->id)); ?>" class="icon-btn bg--danger" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Delete'); ?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo app('translator')->get('Ticket Not Found'); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer py-4">
                <?php echo e($lotteries->links('admin.partials.paginate')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.glof.index')); ?>" class="icon-btn"><i class="la la-eye"></i> <?php echo app('translator')->get('PGA Games'); ?></a> 
<a href="<?php echo e(route('admin.glof.create')); ?>" class="icon-btn"><i class="fa fa-plus"></i> <?php echo app('translator')->get('Create PGA Game'); ?></a> 
<a href="<?php echo e(route('admin.lottery.create')); ?>" class="icon-btn"><i class="fa fa-plus"></i> <?php echo app('translator')->get('Create Game'); ?></a> 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/admin/lottery/index.blade.php ENDPATH**/ ?>