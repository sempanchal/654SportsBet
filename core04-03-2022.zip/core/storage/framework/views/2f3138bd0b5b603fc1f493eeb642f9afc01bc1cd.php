<?php $__env->startSection('content'); ?>
    <section class="pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive--md">
                        <table class="table custom--table">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Transaction ID'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Post Balance'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Details'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($logs) >0): ?>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td data-label="#<?php echo app('translator')->get('Trx'); ?>"><?php echo e($data->trx); ?></td>
                                        <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                            <strong <?php if($data->trx_type == '+'): ?> class="text-success"
                                                    <?php else: ?> class="text-danger" <?php endif; ?>> <?php echo e(($data->trx_type == '+') ? '+':'-'); ?> <?php echo e(getAmount($data->amount)); ?> <?php echo e($general->cur_text); ?></strong>
                                        </td>
                                        <td data-label="<?php echo app('translator')->get('Remaining Balance'); ?>">
                                            <strong
                                                class="text-info"><?php echo e(getAmount($data->post_balance)); ?> <?php echo e(__($general->cur_text)); ?></strong>
                                        </td>
                                        <td data-label="<?php echo app('translator')->get('Details'); ?>"><?php echo e(__($data->details)); ?></td>
                                        <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(date('d M, Y', strtotime($data->created_at))); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="100%" class="text-center"> <?php echo app('translator')->get('No results found'); ?>!</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3">
                        <?php echo e($logs->links()); ?>

                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/templates/basic/user/transactions.blade.php ENDPATH**/ ?>