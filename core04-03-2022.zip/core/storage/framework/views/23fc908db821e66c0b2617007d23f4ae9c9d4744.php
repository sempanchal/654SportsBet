<div class="modal-header">
    <h5 class="modal-title">Choose Team</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php if($events): ?>
<div class="modal-body" style="max-height: 700px;overflow: auto;">
    <form action="<?php echo e($action); ?>" method="post" id="form-choose-team">
        <div class="table-responsive">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventsss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $eventsss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ekey => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <table class="table">
                <thead>
                    <tr>
                        <th colspan="4" class="text-center"><?php echo e(\Carbon\Carbon::parse($event['event_date'])->timezone('America/New_York')); ?></th>
                    </tr>
                    <tr>
                        <th>
                            <input type="checkbox" name="event_id[]" value="<?php echo e($event['event_id']); ?>" <?php if(in_array($event['event_id'], $event_data)): ?>checked="checked"<?php endif; ?> />
                            <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][event_id]" value="<?php echo e($event['event_id']); ?>" />
                            <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][event_name]" value="<?php echo e($event['schedule']['event_name']); ?>" />
                            <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][event_date]" value="<?php echo e(\Carbon\Carbon::parse($event['event_date'])->timezone('America/New_York')); ?>" />
                        </th>
                        <th class="text-left">Team Name</th>
                        <th class="text-left">Is Away</th>
                        <th class="text-left">Is Home</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($event['teams_normalized']) && is_array($event['teams_normalized'])): ?>
                        <?php $__currentLoopData = $event['teams_normalized']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkey => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="ssuunn">
                                <input type="checkbox" name="team_id[<?php echo e($event['event_id']); ?>][]" class="team_id" value="<?php echo e($team['team_id']); ?>" <?php if(isset($team_data[$event['event_id']]) && in_array($team['team_id'], $team_data[$event['event_id']])): ?>checked="checked"<?php endif; ?> />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>]" value="<?php echo e($team['team_id']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][name]" value="<?php echo e($team['name']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][mascot]" value="<?php echo e($team['mascot']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][abbreviation]" value="<?php echo e($team['abbreviation']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][is_away]" value="<?php echo e($team['is_away']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][is_home]" value="<?php echo e($team['is_home']); ?>" />
                            </td>
                            <td class="text-left"><?php echo e($team['name']); ?></td>
                            <td class="text-left"><?php echo e($team['is_away'] == 1 ? "Yes" : "No"); ?></td>
                            <td class="text-left"><?php echo e($team['is_home'] == 1 ? "Yes" : "No"); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif(isset($event['teams']) && is_array($event['teams'])): ?>
                        <?php $__currentLoopData = $event['teams']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkey => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="team_id[<?php echo e($event['event_id']); ?>][]" class="team_id" value="<?php echo e($team['team_id']); ?>" <?php if(isset($team_data[$event['event_id']]) && in_array($team['team_id'], $team_data[$event['event_id']])): ?>checked="checked"<?php endif; ?> />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>]" value="<?php echo e($team['team_id']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][name]" value="<?php echo e($team['name']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][is_away]" value="<?php echo e($team['is_away']); ?>" />
                                <input type="hidden" name="event[<?php echo e($event['event_id']); ?>][teams][<?php echo e($team['team_id']); ?>][is_home]" value="<?php echo e($team['is_home']); ?>" />
                            </td>
                            <td class="text-left"><?php echo e($team['name']); ?></td>
                            <td class="text-left"><?php echo e($team['is_away'] == 1 ? "Yes" : "No"); ?></td>
                            <td class="text-left"><?php echo e($team['is_home'] == 1 ? "Yes" : "No"); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </form>
</div>
<div class="modal-footer">
    <input type="checkbox" data-width="120px" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Check all'); ?>" data-off="<?php echo app('translator')->get('Uncheck all'); ?>" name="checkallgame">
    <button type="submit" form="form-choose-team" class="btn btn-primary">Save</button>
</div>
<script>
$('[name="checkallgame"]').bootstrapToggle();
</script>
<?php else: ?>
<div class="modal-body" style="max-height: 700px;overflow: auto;">
    <table>
        <tr>
            <td class="text-center">No games found!</td>
        </tr>
    </table>
</div>
<?php endif; ?><?php /**PATH /var/www/html/core/resources/views/admin/lottery/team.blade.php ENDPATH**/ ?>