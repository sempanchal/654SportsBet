
<?php $__env->startSection('content'); ?>
    <section class="pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-mb-12 mb-5">
                    <h3 class="text-center"><?php echo e($sub_title); ?></h3>
                </div>
                <div class="col-md-12 mb-30">
                    <table class="table table-responsive--md custom--table">
                        <thead>
                        <tr>
                            <th class="text-center"><?php echo app('translator')->get('Jackpot Game'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Date Bet Placed'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Bet Amount'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Teams Picked '); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Ticket Number'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Result'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Amount Won'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tickets_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Jackpot Game'); ?>"><?php echo e($ticket['jackport_name']); ?></td>
                                <td data-label="<?php echo app('translator')->get('Date Bet Placed'); ?>">
                                    <?php echo e(\Carbon\Carbon::parse($ticket['date_bet_placed'])->format('F jS, Y h:i A')); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Bet Amount'); ?>"><?php echo e($ticket['bet_amount']); ?></td>
                                <td data-label="<?php echo app('translator')->get('Teams Picked'); ?>">
                                    <a href="javascript:void(0)" data-id="<?php echo e(route('user.user_team_popup')); ?>" class="btn user_team_popup btn-sm btn-outline--base dark-gray" data-lottery_id="<?php echo e($ticket['lottery_id']); ?>" data-ticket_id="<?php echo e($ticket['ticket_id']); ?>"><?php echo app('translator')->get('View'); ?></a>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Ticket Number'); ?>"><?php echo e($ticket['ticket_number']); ?></td>
                                    <?php if($ticket['lottery_status'] == 'completed'): ?>
                                    <td data-label="<?php echo app('translator')->get('Result'); ?>"><?php if($ticket['total_teams_win'] >= 4 ): ?> Won <?php else: ?> Lost <?php endif; ?></td>
                                    <td data-label="<?php echo app('translator')->get('Amount Won'); ?>">
                                        <?php if($ticket['total_teams_win'] == 4): ?>
                                            <?php echo e($gnl.showAmount(((float)$ticket['win_amount']/(int)$array_cv[$ticket['lottery_id']][4]),2)); ?>

                                        <?php elseif($ticket['total_teams_win'] == 5): ?>
                                            <?php echo e($gnl.showAmount(((float)$ticket['win_amount']/(int)$array_cv[$ticket['lottery_id']][5]),2)); ?>

                                        <?php elseif($ticket['total_teams_win'] == 6): ?>
                                            <?php echo e($gnl.showAmount(((float)$ticket['win_amount']/(int)$array_cv[$ticket['lottery_id']][6]),2)); ?>

                                        <?php else: ?>
                                            <?php echo e($gnl.'0'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <?php else: ?>
                                        <td data-label="<?php echo app('translator')->get('Result'); ?>">Pending</td>
                                        <td data-label="<?php echo app('translator')->get('Amount Won'); ?>">$0</td>
                                    <?php endif; ?>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td colspan="7" class="not_found_d"><?php echo app('translator')->get('No Bets Available'); ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/templates/basic/user/my_bets.blade.php ENDPATH**/ ?>