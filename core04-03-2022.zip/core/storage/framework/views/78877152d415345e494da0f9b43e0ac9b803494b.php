<table class="table custom-table-new">
            <tr>
                <th>Team Id</th>
                <th>Name</th>
                <th>Mascot</th>
                <th>Abbreviation</th>
                <th>Logo</th>
            </tr> 
        <?php
            $i = 1;
        ?>   
        <?php $__currentLoopData = $sportTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($val['team_id']); ?>

                    <input type="hidden" name="team[<?php echo e($i); ?>][team_id]" value="<?php echo e($val['team_id']); ?>">
                </td>
                <td>
                <?php echo e($val['name']); ?>

                <input type="hidden" name="team[<?php echo e($i); ?>][name]" value="<?php echo e($val['name']); ?>">
                </td>
                <td>
                    <?php echo e($val['mascot']); ?>

                    <input type="hidden" name="team[<?php echo e($i); ?>][mascot]" value="<?php echo e($val['mascot']); ?>">
                </td>
                <td>
                    <?php echo e($val['abbreviation']); ?>

                    <input type="hidden" name="team[<?php echo e($i); ?>][abbreviation]" value="<?php echo e($val['abbreviation']); ?>">
                </td>
                <td>
                    <div class="imageWrapper">
                        <img class="image logoteamimg" src="http://via.placeholder.com/700x500">
                        <input type="file" class="preview_img" name="team[<?php echo e($i); ?>][logo]" oninvalid="this.setCustomValidity('Team logo is required.')" required/>
                        <!-- <button class="btn btn-primary file-upload ml-2">            
                          Choose Logo
                        </button> -->
                    </div>
                </td>
            </tr>
            <?php
                $i++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH /var/www/html/core/resources/views/admin/teams/sport-teams.blade.php ENDPATH**/ ?>