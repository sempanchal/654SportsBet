<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGlofLotteriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('glof_lotteries', function (Blueprint $table) {
            $table->id();
            $table->text('jackpot_name');
            $table->text('sport');
            $table->integer('tournament_id');
            $table->integer('ticket_price');
            $table->integer('jackpot_price');
            $table->integer('first_place');
            $table->integer('second_place');
            $table->integer('third_place');
            $table->integer('no_of_entries');
            $table->text('detail');
            $table->dateTime('last_update_score');
            $table->integer('status')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('glof_lotteries');
    }
}
