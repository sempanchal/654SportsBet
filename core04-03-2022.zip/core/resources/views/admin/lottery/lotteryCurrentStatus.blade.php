
	<table class="table" style="width:100%">
	    <thead class="thead-dark">
	        <tr>
	            <th>@lang('Serial Number')</th>
	            <th>@lang('Team Name')</th>
	            <th>@lang('Team Logo')</th>
	            <th>@lang('score')</th>
	            <th>@lang('Sigma')</th>
	            <th>@lang('away/home')</th>
	        </tr>
	    </thead>
	    <tbody>
	       @forelse($get_teams as $key => $teams)
	        <tr>
	            <td data-label="@lang('Serial Number')">{{ $key+1 }} @if(in_array($teams['team_id'],$winning_team_arr) && $teams['score'] > 0) <i class="las la-trophy"></i> @endif</td>
	            <td data-label="@lang('Team Name')">{{ $teams['name'] }}</td>
	            <td data-label="@lang('Team Logo')"><img src="{{ log_logos($teams['team_id']) }}" alt="logo" height="50" width="50"> <span>{{ $teams['abbreviation'] }}</span></td>
	            <td data-label="@lang('Score')">{{ $teams['score'] }}</td>
	            <td data-label="@lang('Sigma')">{{ $teams['sigma'] }}</td>
	            <td data-label="@lang('away/home')">{{ $teams['type'] }}</td>
	        </tr>
	       @empty
	        <tr>
	            <td class="text-muted text-center" colspan="100%">@lang('Date Not Found')</td>
	        </tr>
	       @endforelse
	    </tbody>
	</table>
