<div class="row">
    @foreach($teams as $key => $team)
    <div class="col-md-6 col-6 text-center mb-2">
        <div class="logo_name_score_wrap">
            <h3><img src="{{ log_logos($team->team_id) }}" alt="logo" height="50" width="50"> <span>{{ $team->abbreviation }}</span></h3>
            {{ $team->mascot }}
        </div>
    </div>
    @endforeach
</div>