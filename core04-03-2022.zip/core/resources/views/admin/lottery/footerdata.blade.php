<div class="modal" tabindex="-1" role="dialog" id="modal-choose-team">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content"></div>
    </div>
</div>

@push('script')
<script type="text/javascript" src="{{ asset('assets/admin/js/datepicker.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/js/moment.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/admin/js/datepicker.en.js') }}"></script>
<script type="text/javascript">
$('.select2').select2();
$('[name="name"]').on('change', function(){
    var value = $(this).val();
    var id = $(this).find('option[value="'+value+'"]').attr('data-id');
    $('[name="sport_id"]').val(id);
});
$('[name="name"]').trigger('change');

$('[name="carry_over_lottery_id"]').on('change', function(){
    var value = $(this).val();
    var id = $(this).find('option[value="'+value+'"]').attr('data-id');
    $('[name="carry_over_amount"]').val(id);
});
$('[name="carry_over_lottery_id"]').trigger('change');


$('#btn-modal-team').on('click', function(){
    $btn = $(this);
    $.ajax({
        url: "{{ route('admin.lottery.get_team') }}",
        type: 'post',
        dataType: 'json',
        data: {
            sport_id: $('[name="sport_id"]').val(),
            date: $('[name="date"]').val()
        },
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            if(json.success){
                $('#modal-choose-team .modal-content').html(json.html);
                $('#modal-choose-team').modal({
                    keyboard: false,
                    backdrop: 'static'
                });
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
        error: function(xhr, exception){
            $btn.prop('disabled', false);

            if(xhr.responseJSON){
                $.each(xhr.responseJSON.errors, function(k,v){
                    /*iziToast['error']({
                        message: v[0],
                        position: "topRight"
                    });*/
                });
            }
        }
    });
});
$(document).delegate('#form-choose-team', 'submit', function(e){
    e.preventDefault();

    $form = $(this);
    $btn = $('[form="form-choose-team"]');
    $.ajax({
        url: $form.attr('action'),
        type: $form.attr('method'),
        dataType: 'json',
        data: $form.serialize(),
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            if(json.success){
                $('#modal-choose-team').modal('hide');
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
        error: function(xhr, exception){
            $btn.prop('disabled', false);

            if(xhr.responseJSON){
                $.each(xhr.responseJSON.errors, function(k,v){
                    /*iziToast['error']({
                        message: v[0],
                        position: "topRight"
                    });*/
                });
            }
        }
    });
});
$(document).delegate('[name="event_id[]"]', 'change', function(){
    var checked = $(this).prop('checked');
    $(this).closest('table').find('.team_id').prop('checked', checked);
});
$(document).delegate('.team_id', 'change', function(){
    var checked = $(this).prop('checked');
    var event_checked = $(this).closest('table').find('[name="event_id[]"]').prop('checked');
    if(checked && !event_checked){
        $(this).closest('table').find('[name="event_id[]"]').prop('checked', checked);
    }

    var parent = $(this).closest('table');
    var total_checked = $(parent).find('.team_id:checked');
    if(!total_checked.length){
        $(this).closest('table').find('[name="event_id[]"]').prop('checked', false);   
    }
});
$(document).delegate('[name="checkallgame"]', 'change', function(){
    var checked = $(this).prop('checked');
    $('[name="event_id[]"]').prop('checked', checked);
    $('[name="event_id[]"]').trigger('change');
});
</script>
@endpush