<div id="form-choose-team">
    <div class="table-responsive">
        <table class="table custom-table-new">
            <tr>
                <td><h3 class="text-center pb-3">Away</h3></td>
                <td><h3 class="text-center pb-3">Home</h3></td>
            </tr>    
        @foreach($games as $gkey => $game)
            <tr>
                <tr>
                    <th colspan="2" class="text-center font-15">
                        {{ $game['name'] }} - {{ \Carbon\Carbon::parse($game['date'])->format('F jS, Y h:i A') }}
                    </th>
                </tr>
                @foreach($game['teams'] as $tkey => $team)
                <td class="text-center">
                    <!-- <input type="checkbox" name="games[{{ $gkey }}][team_id][]" value="{{ $team['team_id'] }}"/> -->
                    <span>
                        <img src="{{ log_logos($team['team_id']) }}" alt="logo" height="50" width="50" style="width: 50px; height: 50px;">  &nbsp {{ $team['abbreviation'] }} 
                        <div>{{ $team['name'].' - '.$team['score'] }}</div>
                    </span>
                </td>
                @endforeach
            </tr>
        @endforeach
        </table>
    </div>
</div>
