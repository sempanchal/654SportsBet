<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Lib\GlofAPI;
use App\Models\GolfWorldRanking;
use App\Models\GlofFixture;
use App\Models\glofEntryList;
use App\Models\glofLotterie;
use Illuminate\Support\Facades\DB;
use App\Models\GlofLotterieTicket;
use App\Models\UserGolfPlayer;
use Carbon\Carbon;

class GlofController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pageTitle = "Golf Lotteries";
        $lotteries = glofLotterie::orderBy('id','desc')->paginate(getPaginate());
        return view('admin.glof.index',compact('pageTitle','lotteries'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pageTitle = "Game Create";
        $tournaments = GlofFixture::get();
        return view('admin.glof.create',compact('pageTitle','tournaments'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //die('47');
        $validator = $request->validate([
            'jackpot_name'=>'required',
            'sport'=>'required',
            'tournament_id'=>'required|numeric|gt:0',
            'ticket_price'=>'required|numeric|lt:jackpot_price',
            'jackpot_price'=>'required|numeric|gt:0',
            'first_place'=>'required|numeric|gt:0|between:1,100',
            'second_place'=>'required|numeric|gt:0|lt:first_place',
            'third_place'=>'required|numeric|gt:0|lt:second_place',
            'no_of_entries'=>'required|numeric|between:1,10',
            'detail'=>'required',
        ]);

        $entryList = GlofAPI::entryList($request->tournament_id);
        if(!empty($entryList)){
            $lotterie_arr = [
                'jackpot_name' => $request->jackpot_name,
                'sport' => $request->sport,
                'tournament_id' => $request->tournament_id,
                'ticket_price' => $request->ticket_price,
                'jackpot_price' => $request->jackpot_price,
                'first_place' => $request->first_place,
                'second_place' => $request->second_place,
                'third_place' => $request->third_place,
                'no_of_entries' => $request->no_of_entries,
                'detail' => $request->detail,
            ];
            $lotterie = glofLotterie::create($lotterie_arr);
            $lotterieId  = $lotterie->id;
            $tournamentId  = $lotterie->tournament_id;
            foreach($entryList as $ek => $ev){
                $data['player_id'] = $ev['player_id'];
                $data['first_name'] = $ev['first_name'];
                $data['last_name'] = $ev['last_name'];
                $data['country'] = $ev['country'];
                $data['tournament_id'] = $tournamentId;
                $data['lottery_id'] = $lotterieId;
                glofEntryList::create($data);
            }
        }
        $notify[] = ['success','Game created successfully'];
        return redirect()->route('admin.glof.index')->withNotify($notify);
    }

    public function status($id){
        $lottery = glofLotterie::find($id);
        if ($lottery->status == 1) {
            $lottery->update(['status'=>0]);
        }else{
            $lottery->update(['status'=>1]);
        }
        $notify[] = ['success','Game Status Updated'];
        return back()->withNotify($notify);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   $pageTitle = "Update Game";
        $lottery = glofLotterie::find($id);
        return view('admin.glof.update',compact('lottery','pageTitle'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $request->validate([
            'jackpot_name'=>'required',
            'ticket_price'=>'required|numeric|lt:jackpot_price',
            'jackpot_price'=>'required|numeric|gt:0',
            'first_place'=>'required|numeric|gt:0|between:1,100',
            'second_place'=>'required|numeric|gt:0|lt:first_place',
            'third_place'=>'required|numeric|gt:0|lt:second_place',
            'no_of_entries'=>'required|numeric|between:1,10',
            'detail'=>'required',
        ]);
        $lottery = glofLotterie::find($id);
        $lottery->update([
            'jackpot_name' => $request->jackpot_name,
            'sport' => $request->sport,
            'ticket_price' => $request->ticket_price,
            'jackpot_price' => $request->jackpot_price,
            'first_place' => $request->first_place,
            'second_place' => $request->second_place,
            'third_place' => $request->third_place,
            'no_of_entries' => $request->no_of_entries,
            'detail' => $request->detail,
        ]);
        $notify[] = ['success','Game uploaded successfully'];
        return redirect()->route('admin.glof.index')->withNotify($notify);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ticket = DB::table('tickets')->where('lottery_id',$id);
        if($ticket){
            $ticket->delete();    
        }
        $lottery = glofLotterie::find($id);
        if($lottery){
            $lottery->delete();
        }
        $notify[] = ['success','Game deleted successfully'];
        return redirect()->route('admin.glof.index')->withNotify($notify);
    }

    public function glofWorldRankings(){

        $worldRankings = GlofAPI::worldRankings();
        $data = GolfWorldRanking::get();
        $record_count = $data->count();
        if($record_count > 0){
            foreach($worldRankings as $wrk => $wrv){
                $player_data = GolfWorldRanking::where('player_id',$wrv['player_id'])->first();
                if($player_data){
                    $player_data->update($wrv);
                }else{
                    GolfWorldRanking::create($wrv);
                }
                
            }
        }else{
            foreach($worldRankings as $wrk => $wrv){
                GolfWorldRanking::create($wrv);
            }
        }
        
        
    }

     public function glofFixtures(){
        $fixtures =GlofAPI::fixtures();
        $data = GlofFixture::get();
        $record_count = $data->count();
        if($record_count > 0){ 
            foreach ($fixtures as $key => $value) {
                $data = [];
                $data['tournament_id'] = $value['id'];
                $data['type'] = $value['type'];
                $data['status'] = $value['status'];
                $data['name'] = $value['name'];
                $data['tour_id'] = $value['tour_id'];
                $data['country'] = $value['country'];
                $data['course'] = $value['course'];
                $data['start_date'] = $value['start_date'];
                $data['end_date'] = $value['end_date'];
                $data['season'] = $value['season'];
                $data['timezone'] = $value['timezone'];
                $data['prize_fund'] = $value['prize_fund'];
                $data['fund_currency'] = $value['fund_currency'];
                $data['updated'] = $value['updated'];
                $fixtures_data = GlofFixture::where('tournament_id',$value['id'])->first();
                if($fixtures_data){
                    $fixtures_data->update($data);
                }else{
                     GlofFixture::create($data);
                }
            }
        }else{
            foreach ($fixtures as $key => $value) {
                $data = [];
                $data['tournament_id'] = $value['id'];
                $data['type'] = $value['type'];
                $data['status'] = $value['status'];
                $data['name'] = $value['name'];
                $data['tour_id'] = $value['tour_id'];
                $data['country'] = $value['country'];
                $data['course'] = $value['course'];
                $data['start_date'] = $value['start_date'];
                $data['end_date'] = $value['end_date'];
                $data['season'] = $value['season'];
                $data['timezone'] = $value['timezone'];
                $data['prize_fund'] = $value['prize_fund'];
                $data['fund_currency'] = $value['fund_currency'];
                $data['updated'] = $value['updated'];
                GlofFixture::create($data);
            }
            //echo "Done";die('138');
        }
       
     }

     public function golfWinner($lotteryId){
        $players = getPlayerPosition($lotteryId);

        $lotterie = glofLotterie::find($lotteryId)->first();

        $tournaments = GlofFixture::where('tournament_id', $lotterie->tournament_id)->first();

        $start_date = Carbon::parse($tournaments->start_date)->format('F jS');
        $end_date = Carbon::parse($tournaments->end_date)->format('F jS');
        $end = Carbon::parse($tournaments->end_date)->toDateTimeString();
        if(Carbon::now() > $end){
            $lottery_status = "End";
        }else{  
            $lottery_status = "Live";
        }

        $winner_list_arr = [];
        $i = 0;
        $tickets = GlofLotterieTicket::where('lottery_id',$lotteryId)->get();
        foreach ($tickets as $ticket_key => $ticket_value) {
            $userSelectedPlayers = UserGolfPlayer::where('ticket_id',$ticket_value->id)->first();
            $selectedPlayers = json_decode($userSelectedPlayers->players,true);

            $wc = 0;
            foreach ($players as $player) {
                if(in_array($player['player_id'], $selectedPlayers)){
                    $wc++;
                }
            }
            if($wc == 6){
                $winner_list_arr[$i]['position'] = 1;
            }else if($wc == 5){
                $winner_list_arr[$i]['position'] = 2;
            }else if($wc == 4){
                $winner_list_arr[$i]['position'] = 3;
            }else{
                $winner_list_arr[$i]['position'] = 0;
            }

            $users = DB::table('users')->where('id',$ticket_value->user_id)->first();
            $winner_list_arr[$i]['ticket_id'] = $ticket_value->id;
            $winner_list_arr[$i]['user_id'] = $ticket_value->user_id;
            $winner_list_arr[$i]['username'] = $users->username;
            $winner_list_arr[$i]['email'] = $users->email;
            $winner_list_arr[$i]['ticket_number'] = $ticket_value->ticket_number;
            $winner_list_arr[$i]['total_players_in_winning'] = $wc;
            $winner_list_arr[$i]['player'] = $userSelectedPlayers->players;
            $i++;
        }
        $position = array_column($winner_list_arr, 'position');
        array_multisort($position, SORT_DESC,$winner_list_arr);
        
        $pageTitle = "Winner";
        return view('admin.glof.winner',compact('pageTitle','winner_list_arr','lotteryId'));
     }

     public function selected_player_popup(Request $request){
        $json = array();
        $players = getPlayerPosition($request->lotterie_id);
        $userSelectedPlayers = UserGolfPlayer::where('ticket_id',$request->ticket_id)->select('players')->first();
        $selectedPlayers = json_decode($userSelectedPlayers->players,true);
        $my_player = [];
        foreach ($players as $player) {
            if(in_array($player['player_id'], $selectedPlayers)){
                array_push($my_player,$player);
            }
        }
        //print_r($my_player);die;
        $json['html'] = view('admin.glof.selected_player_popup',compact('my_player'))->render();
        $json['success'] = true;
        return response()->json($json);
     }
}
