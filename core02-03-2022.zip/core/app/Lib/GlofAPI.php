<?php
namespace App\Lib;

class GlofAPI
{
	private static $apiUrl = 'https://golf-leaderboard-data.p.rapidapi.com/';
	private static $apiKey = '7d37d969e4mshaf130b2861d469dp170318jsn9491abf4d1db';
    private static $apiHost = 'golf-leaderboard-data.p.rapidapi.com';

    public static function worldRankings(){

    	$curl = curl_init();

		curl_setopt_array($curl, [
			CURLOPT_URL => self::$apiUrl.'world-rankings',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => [
				"x-rapidapi-host: " . self::$apiHost,
                "x-rapidapi-key: " . self::$apiKey
			],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			return "cURL Error #:" . $err;
		} else {
			$result = json_decode($response, true);
			return $result['results']['rankings'];
		}

    }

    public static function fixtures(){
    	$curl = curl_init();

		curl_setopt_array($curl, [
			CURLOPT_URL => self::$apiUrl."/fixtures/2/2022",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => [
				"x-rapidapi-host: " . self::$apiHost,
                "x-rapidapi-key: " . self::$apiKey
			],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			return "cURL Error #:" . $err;
		} else {
			$result = json_decode($response, true);
			return $result['results'];
		}
    }

    public static function entryList($tournament_id){

    	$curl = curl_init();

		curl_setopt_array($curl, [
			CURLOPT_URL => self::$apiUrl."entry-list/".$tournament_id,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => [
				"x-rapidapi-host: " . self::$apiHost,
                "x-rapidapi-key: " . self::$apiKey
			],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			$result = json_decode($response, true);
			return $result['results']['entry_list'];
		}

    }

}
