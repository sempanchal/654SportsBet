<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GlofFixture extends Model
{
    use HasFactory;

    protected $fillable = [
        'tournament_id',
        'type',
        'status',
        'name',
        'tour_id',
        'country',
        'course',
        'start_date',
        'end_date',
        'season',
        'timezone',
        'prize_fund',
        'fund_currency',
        'updated',
    ];
}
