@extends('admin.layouts.app')
@section('panel')
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <form action="{{ route('admin.teams.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label>@lang('Game Name')</label>
                                <div>
                                    <select name="name" class="form--control select2" requierd>
                                        @if($sports)    
                                        @foreach($sports as $sport)    
                                        <option value="{{ $sport['sport_name'] }}" data-id="{{ $sport['sport_id'] }}" @if(old('sport_id') == $sport['sport_id'])selected="selected"@endif>{{ $sport['sport_name'] }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <input type="hidden" id="sport_id" name="sport_id" value="{{ old('sport_id') }}" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                        	<label></label>
                        	<div class="form-group">
                                <button type="button" id="get-sport-team" data-action="{{ route('admin.teams.get_team') }}" class="btn btn-block btn-primary">Get Teams</button>
                            </div>
                        </div>    
                    </div>
                    <div class="row">
                    	<div class="col-md-12" id="ajax_teams">

                    	</div>	
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-row justify-content-center">
                        <div class="form-group col-md-12">
                            <button type="submit" class="btn btn-block btn--primary mr-2">@lang('Post')</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@include('admin.lottery.footerdata')
@endsection

@push('breadcrumb-plugins')
<a href="{{ route('admin.teams.index') }}" class="icon-btn" ><i class="fa fa-fw fa-reply"></i>@lang('Back')</a> 
@endpush
