@php
    $lottery_content = getContent('lottery.content', true);
    $time = \Carbon\Carbon::now()->toDateTimeString();
    $phases = \App\Models\Phase::where('status',1)->where('draw_status',0)->where('start','<',$time)->orderBy('end')->whereHas('lottery',function($lottery){
          $lottery->where('status',1);
      })->limit(3)->with(['lottery'])->get();
    
    $events = \App\Models\Lottery::where('status', 1)->orderBy('id', 'DESC')->take(10)->get();
    $events_arr = [];
        $i=0;
        foreach($events as $event){
            $events_arr[$i]['id'] = $event->id;
            $events_arr[$i]['sport_id'] = $event->sport_id;
            $events_arr[$i]['name'] = $event->name;
            $events_arr[$i]['jackpot_name'] = $event->jackpot_name;
            $events_arr[$i]['ticket_price'] = $event->ticket_price;
            $events_arr[$i]['detail'] = $event->detail;
            $lottery_dates = explode(",",$event->date);
            $lottery_dates_arr = [];
            foreach($lottery_dates as $ldata){
                $lottery_dates_arr[] = strtotime($ldata);
            }
            rsort($lottery_dates_arr);
            $end = \Carbon\Carbon::parse($lottery_dates_arr[0])->toDateTimeString();
            if(\Carbon\Carbon::now() > $end){
                $lottery_status = "End";
            }else{  
                $lottery_status = "Live";
            }
            $events_arr[$i]['date'] = \Carbon\Carbon::parse($lottery_dates_arr[0])->format('F jS');
            $events_arr[$i]['price'] = $event->price;
            $events_arr[$i]['lottery_status'] = $lottery_status;
            $i++;
        }
@endphp
<!-- lottery calender section start -->
<section class="pt-50 lottery_wrap">
        <div class="container">
            <div class="row">
             @forelse($events_arr as $event)
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-team-popup game-table" data-id="{{ route('team_popup',$event['id']) }}">
                    <div class="arrow-right {{ $event['lottery_status'] }}">
                        <span>{{ $event['lottery_status'] }}</span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                            <img src="{{ get_sport_logo($event['sport_id']) }}" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3>{{ $event['jackpot_name'] }}</h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: {{ $event['date'] }}</p>
                                <a href="javascript:void(0);" data-id="{{ route('rules_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                <!-- <a href="javascript:void(0)" data-id="{{ route('team_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-team-popup">Place Bet</a> -->
                                    <!-- <a href="javascript:void(0)" data-id="{{ route('team_schedule',$event['id']) }}" class="text-white underline btn-modal-schedule-popup">Schedule</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ showAmount($event['price'],0) }}</h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ $event['ticket_price'] }}</h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- <div class="row align-items-center">
                        <div class="col-md-2 text-center">
                            <img src="{{ get_sport_logo($event['sport_id']) }}" alt="image" width="100">
                        </div>
                        <div class="col-md-10">
                            <h4 class="card-title">{{ $event['jackpot_name'] }}</h4>
                            <div class="cut-body my-4">
                                <span class="white-colour"><b>Pool End:</b> {{ $event['date'] }}</span>
                                <div class="cut-links">
                                    <a href="javascript:void(0);" data-id="{{ route('rules_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                    
                                </div>
                            </div>
                            <div class="cut-footer mt-2">
                                <ul class="">
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ showAmount($event['price'],0) }}</h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ $event['ticket_price'] }}</h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div> -->
                  </div>
                </div>
              </div>
            @empty
            @endforelse
            </div>
        </div>
    </section>
<!-- lottery calender section end -->
