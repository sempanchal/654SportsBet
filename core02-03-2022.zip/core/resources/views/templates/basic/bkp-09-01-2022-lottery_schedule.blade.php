<div class="table-responsive" id="form-choose-team">
    <!-- 08-12-2021 -->
     <!-- <div><h2 class="text-center font-15 mt-2 mb-2" style="background: #36f5f9; color: #000; line-height: 1.3; padding: 10px 0;">Jackpot Games Score</h2></div> -->
    <table class="table custom-table-new">
        <tr>
            <td><h3 class="text-center pb-3">Away</h3></td>
            <td><h3 class="text-center pb-3">Home</h3></td>
        </tr>
    @foreach($sports as $skey => $sValue)
            @foreach($sValue as $tkey => $team)
            <tr>
                <th colspan="2" class="text-center font-15">
                    <div>
                    {{ \Carbon\Carbon::parse($team['event_date'])->timezone('America/New_York')->format('F jS, Y h:i A') }}
                    </div>
                </th>
            </tr>
            <tr>
                <th class="text-center font-15">
                    <div class="logo_name_score_wrap">
                        <h3><img src="{{ log_logos($team['away_team']['team_normalized_id']) }}" alt="logo" height="50" width="50" style="width: 50px; height: 50px;"> <span>{{ $team['away_team']['abbreviation'] }}</span></h3>
                        {{ $team['away_team']['name'] }} - {{  $team['away_team']['score_away'] }}
                    </div>
                </th>
                <th class="text-center font-15">
                    <div class="logo_name_score_wrap">
                        <h3><img src="{{ log_logos($team['home_team']['team_normalized_id']) }}" alt="logo" height="50" width="50" style="    width: 50px; height: 50px;"> <span>{{ $team['home_team']['abbreviation'] }}</span></h3>
                        {{ $team['home_team']['name'] }} - {{  $team['home_team']['score_home'] }}
                    </div>
                </th>
            </tr>
             @endforeach
    @endforeach
    </table>
    
</div>