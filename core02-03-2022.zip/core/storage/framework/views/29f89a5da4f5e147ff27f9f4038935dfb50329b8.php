
<?php $__env->startSection('panel'); ?>
<?php /* ?>
<div class="row">
	<div class="col-md-12">

		<?php if($lottery_status == 'completed'): ?>
			<h3 class="mb-3 text-center">Statistics</h3>
			<hr>
			<div class="row">
				<div class="col-md-4 mb-2">
					<div class="card event-timing-col">
						<div class="card-body">
							<h5>Start Date: <span class="badge badge-primary"><?php echo e($lotterie_sdate); ?></span></h5>
						</div>
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card event-timing-col">
						<div class="card-body">
							<h5>End Date: <span class="badge badge-danger"><?php echo e($lotterie_edate); ?></span></h5>
						</div>
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card event-timing-col">
						<div class="card-body">
							<p>Total Jackpot Size: <span class="badge badge-success">$<?php echo e(showAmount($lotterie_price,0)); ?></span></p>
						</div>
					</div>
				</div>
			</div>
			<hr>
			
			<h4 class="mb-3">List of Winning Teams</h4>
			<div class="winner_teams mb-3">
				<?php $__empty_1 = true; $__currentLoopData = $only_winning_team_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kw => $vw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<div class="winner_teams_col">
						<img src="<?php echo e(log_logos($vw['team_id'])); ?>" alt="logo" height="50" width="50"> <span><?php echo e($vw['abbreviation']); ?></span>
						(<?php echo e($vw['score']); ?>)
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</div>
			<hr>

			<?php if($winner_statistics): ?>
			<h4 class="mb-2">No. of Winners</h4>
			<div class="row">
				<div class="col-md-4 mb-2">
					<div class="card prize-winning-col">
						<div class="card-header bg-success">
							<h4>1st Prize Winners</h4>
						</div>
						<?php if(isset($winner_statistics[1])): ?>
						<div class="card-body">
							<ul>
							<?php $__empty_1 = true; $__currentLoopData = $winner_statistics[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ks => $vs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<li>
									<h5><?php echo e($vs['username']); ?></h5>
									<p>Winning Amount: <strong>$<?php echo e($vs['winning_price']); ?></strong></p>
									<p>Ticket Number: <strong><?php echo e($vs['ticket_number']); ?></strong></p>
								<hr/>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							 	<li><span>No data found.</span></li>
							<?php endif; ?>
							</ul>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card prize-winning-col">
						<div class="card-header bg-warning">
							<h4>2nd Prize Winners</h4>
						</div>
						<div class="card-body">
							<?php if(isset($winner_statistics[2])): ?>
							<div class="card-body">
								<ul>
								<?php $__empty_1 = true; $__currentLoopData = $winner_statistics[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ks => $vs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<li>
										<h5><?php echo e($vs['username']); ?></h5>
										<p>Winning Amount: <strong>$<?php echo e($vs['winning_price']); ?></strong></p>
										<p>Ticket Number: <strong><?php echo e($vs['ticket_number']); ?></strong></p>
										<hr/>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<li><span>No data found.</span></li>
								<?php endif; ?>
								</ul>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>

				<div class="col-md-4 mb-2">
					<div class="card prize-winning-col">
						<div class="card-header bg-danger">
							<h4>3rd Prize Winners</h4>
						</div>
						<div class="card-body">
							<?php if(isset($winner_statistics[3])): ?>
							<div class="card-body">
								<ul>
								<?php $__empty_1 = true; $__currentLoopData = $winner_statistics[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ks => $vs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<li>
										<h5><?php echo e($vs['username']); ?></h5>
										<p>Winning Amount: <strong>$<?php echo e($vs['winning_price']); ?></strong></p>
										<p>Ticket Number: <strong><?php echo e($vs['ticket_number']); ?></strong></p>
									<hr/>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								 <li><span>No data found.</span></li>
								<?php endif; ?>
								</ul>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			<hr>
			<?php endif; ?>
		<?php endif; ?>


		<h4 class="mb-2"><?php echo e($lotterie->name .' - '. $lotterie->jackpot_name); ?></h4>

		<div class="d-flex justify-content-between">
			<div>
				<h4><span class="badge <?php if($lottery_status == 'completed'): ?> badge-success <?php else: ?> badge-danger  <?php endif; ?> lottery_status"><b>Jackpot Result Status:</b> <?php echo e($lottery_status); ?></span></h4>
			</div>
			<div>
				<button id="score_update" class="btn btn-primary" data-action="<?php echo e(route('admin.lottery.update_score')); ?>" data-lotterie_id="<?php echo e($lotterie_id); ?>" data-csrf="<?php echo e(csrf_token()); ?>">Update Score <i class="fas fa-info-circle" data-toggle="tooltip" data-placement="top" title="<?php echo e('last updated: '.\Carbon\Carbon::parse($last_update_score)->format('F jS, Y h:i A')); ?>"></i></button>
				<button id="send_to_winner" class="btn btn-primary"  <?php if($lottery_status == 'pending' || $sent_prize == 1): ?> disabled <?php endif; ?> data-id="<?php echo e(route('admin.lottery.send_win_amount')); ?>" data-win_data="<?php echo e($send_mail_data); ?>" data-csrf="<?php echo e(csrf_token()); ?>" data-lotterie_id="<?php echo e($lotterie_id); ?>">Send Mail To Winner</button>
				<button class="btn btn-danger" id="current_status" data-id="<?php echo e(route('admin.lottery.lottery_current_status')); ?>" data-lotterie_id="<?php echo e($lotterie_id); ?>" data-sportId="<?php echo e($lotterie_sportId); ?>" data-lotterie_date="<?php echo e($lotterie_date); ?>">Show current status</button>
			</div>
			
		</div>
	</div>
</div>
<?php */ ?>
<hr/>
<div class="row">
    <div class="col-lg-12">
        <!-- <div class="card b-radius--10">
            <div class="card-body p-0"> -->
            	<?php if(count($winner_list_arr)>0): ?>
            	<div class="table-responsive--sm table-responsive">
	            	<table id="example" class="display" style="width:100%">
				        <thead>
				            <tr>
				                <th><?php echo app('translator')->get('Serial Number'); ?></th>
				                <th class="text-center"><?php echo app('translator')->get('Username'); ?></th>
				                <th class="text-center"><?php echo app('translator')->get('Ticket Number'); ?></th>
				                <th class="text-center"><?php echo app('translator')->get('No. Of Player In Winning Zone'); ?></th>
				                <th><?php echo app('translator')->get('Actions'); ?></th>
				            </tr>
				        </thead>
				        <tbody>
				           <?php $__empty_1 = true; $__currentLoopData = $winner_list_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lottery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				          <tr class="<?php if($lottery['total_players_in_winning'] == 6): ?> bg-success <?php elseif($lottery['total_players_in_winning'] == 5): ?> bg-warning <?php elseif($lottery['total_players_in_winning'] == 4): ?> bg-danger <?php endif; ?>">

                            <td data-label="<?php echo app('translator')->get('Serial Number'); ?>"><?php echo e($key+1); ?></td>
                            <td class="text-center" data-label="<?php echo app('translator')->get('Username'); ?>"><?php echo e($lottery['username']); ?></td>
                            <td class="text-center" data-label="<?php echo app('translator')->get('Ticket Number'); ?>"><?php echo e($lottery['ticket_number']); ?></td>
                            <td class="text-center" data-label="<?php echo app('translator')->get('No. Of Teams In Winning Zone'); ?>"><?php echo e($lottery['total_players_in_winning']); ?></td>
                            <td data-label="<?php echo app('translator')->get('Actions'); ?>">
                            	<a href="javascript:void(0)" class="icon-btn selected_player_popup" data-id="<?php echo e(route('admin.glof.selected_player_popup')); ?>" data-toggle="tooltip" data-original-title="View Players" data-lotterie_id="<?php echo e($lotteryId); ?>" data-ticket_id="<?php echo e($lottery['ticket_id']); ?>">
                                    <i class="las la-users"></i>
                                </a>
                            </td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="6"><?php echo app('translator')->get('Date Not Found'); ?></td>
                            </tr>
				           <?php endif; ?>
				        </tbody>
				    </table>
				<!-- </div>
            </div> -->
        </div>
        <?php else: ?>
        <div>
        	<h2 class="text-center">Date Not Found</h2>
        </div>
        <?php endif; ?>
    </div>
</div>
<div class="modal" tabindex="-1" role="dialog" id="ticket-player">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Players</h5>
                <button type="button" onclick="$('#ticket-player').hide()" class="cloas-btn" data-dismiss="modal" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <div class="modal-body" style="max-height: 80vh;overflow: auto;"></div>
        </div>
    </div>
</div>      
<!-- <div class="modal" tabindex="-1" role="dialog" id="lotteryCurrentStatusPopup">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Teams</h5>
                <button type="button" onclick="$('#lotteryCurrentStatusPopup').hide()" class="cloas-btn" data-dismiss="modal" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <div class="modal-body" style="max-height: 80vh;overflow: auto;"></div>
        </div>
    </div>
</div>    -->         	
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
    <div class="cust_search">
    	<div class="input-group has_append mr-2">
	        <input type="text" name="cust_ticket_number" class="form-control" placeholder="Ticket Number" id="cust_ticket_number" value="">
	        <div class="input-group-append">
	            <button class="btn btn--primary" type="submit" id="btn_ticket_number"><i class="fa fa-search"></i></button>
	        </div>
    	</div>
    	<div class="input-group has_append">
	        <input type="text" name="cust_username" class="form-control" placeholder="Username" id="cust_username" value="">
	        <div class="input-group-append">
	            <button class="btn btn--primary" type="submit" id="btn_cust_username"><i class="fa fa-search"></i></button>
	        </div>
    	</div>
    </div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/admin/glof/winner.blade.php ENDPATH**/ ?>