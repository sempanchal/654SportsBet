<?php $__env->startSection('content'); ?>
    <!-- dashboard section start -->
    <section class="lottery_wrap">
        <div class="container">
            <div class="row gy-4 align-items-center mt-2">
                <div class="col-lg-3 col-sm-6">
                    <div class="balance-card dark-gray">
                        <span class="text--dark"><?php echo app('translator')->get('Wallet Balance'); ?></span>
                        <h3 class="number text--dark"><?php echo e(__($general->cur_sym)); ?><?php echo e(showAmount(getAmount($user->balance),0)); ?></h3>
                    </div><!-- dashboard-card end -->
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="dashboard-card">
                        <span><?php echo app('translator')->get('Total Wins'); ?></span>
                        <a href="<?php echo e(route('user.my-bets')); ?>" class="view--btn"><?php echo app('translator')->get('Bet History'); ?></a>
                        <h3 class="number"><?php echo e($total_teams_win); ?></h3>
                        <i class="las la-trophy icon"></i>
                    </div><!-- dashboard-card end -->
                </div>
            </div><!-- row end -->
            <div class="row mt-5">
             <?php $__empty_1 = true; $__currentLoopData = $events_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-team-popup game-table" data-id="<?php echo e(route('team_popup',$event['id'])); ?>">
                    <div class="arrow-right <?php echo e($event['lottery_status']); ?>">
                        <span><?php echo e($event['lottery_status']); ?></span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                            <img src="<?php echo e(get_sport_logo($event['sport_id'])); ?>" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3><?php echo e($event['jackpot_name']); ?></h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: <?php echo e($event['date']); ?></p>
                                <a href="javascript:void(0);" data-id="<?php echo e(route('rules_popup',$event['id'])); ?>" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                <!-- <a href="javascript:void(0)" data-id="<?php echo e(route('team_popup',$event['id'])); ?>" class="text-white underline mr-3 btn-modal-team-popup">Place Bet</a> -->
                                    <!-- <a href="javascript:void(0)" data-id="<?php echo e(route('team_schedule',$event['id'])); ?>" class="text-white underline btn-modal-schedule-popup">Schedule</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e(showAmount($event['price'],0)); ?></h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e($event['ticket_price']); ?></h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- <div class="row align-items-center">
                        <div class="col-md-2 text-center">
                            <img src="<?php echo e(get_sport_logo($event['sport_id'])); ?>" alt="image" width="100">
                        </div>
                        <div class="col-md-10">
                            <h4 class="card-title"><?php echo e($event['jackpot_name']); ?></h4>
                            <div class="cut-body my-4">
                                <span class="white-colour"><b>Pool End:</b> <?php echo e($event['date']); ?></span>
                                <div class="cut-links">
                                    <a href="javascript:void(0);" data-id="<?php echo e(route('rules_popup',$event['id'])); ?>" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                    
                                </div>
                            </div>
                            <div class="cut-footer mt-2">
                                <ul class="">
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e(showAmount($event['price'],0)); ?></h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e($event['ticket_price']); ?></h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div> -->
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- dashboard section end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .copytext{
            cursor: pointer;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        (function ($) {
            "use strict";
            $('#copyBoard').click(function(){
                var copyText = document.getElementById("referralURL");
                copyText.select();
                copyText.setSelectionRange(0, 99999);
                /*For mobile devices*/
                document.execCommand("copy");
                // iziToast.success({message: "Copied: " + copyText.value, position: "topRight"});
                Swal.fire({
                    toast: false,
                    title: "Copied: " + copyText.value,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    timer: 5000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>