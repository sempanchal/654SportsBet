<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /var/www/html/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>