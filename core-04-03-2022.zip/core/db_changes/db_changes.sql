-- 03-02-2022
ALTER TABLE `lotteries` ADD `roll_over_from` INT(11) NULL AFTER `last_update_score`;