<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGlofFixturesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('glof_fixtures', function (Blueprint $table) {
            $table->id();
            $table->integer('tournament_id');
            $table->text('type');
            $table->text('status');
            $table->text('name');
            $table->integer('tour_id');
            $table->text('country');
            $table->text('course');
            $table->dateTime('start_date');
            $table->dateTime('end_date');
            $table->text('season');
            $table->text('timezone');
            $table->text('prize_fund');
            $table->text('fund_currency');
            $table->dateTime('updated');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('glof_fixtures');
    }
}
