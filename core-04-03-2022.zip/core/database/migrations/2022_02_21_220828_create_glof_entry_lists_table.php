<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGlofEntryListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('glof_entry_lists', function (Blueprint $table) {
            $table->id();
            $table->text('country');
            $table->text('first_name');
            $table->text('last_name');
            $table->integer('player_id');
            $table->integer('tournament_id');
            $table->integer('lottery_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('glof_entry_lists');
    }
}
