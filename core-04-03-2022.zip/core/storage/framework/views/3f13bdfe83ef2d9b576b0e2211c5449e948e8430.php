<section class="inner-hero bg_img overlay--one" style="background-image: url(<?php echo e(asset('assets/images/frontend/breadcrumb/'.getContent('breadcrumb.content',true)->data_values->background_image)); ?>);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 text-center">
                <?php if(strtolower($pageTitle) == 'dashboard'): ?>
                <h2 class="page-title text-white"><?php echo e($general->sitename); ?> <?php echo e(__($pageTitle)); ?></h2>
                <?php else: ?>
                <h2 class="page-title text-white"><?php echo e(__($pageTitle)); ?></h2>
                <?php endif; ?>
                <!-- <ul class="page-breadcrumb justify-content-center">
                    <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                    <li><?php echo e(__('Games')); ?></li>
                </ul> -->
            </div>
        </div>
    </div>
</section>
<!-- inner hero end --><?php /**PATH /opt/lampp/htdocs/sportsBeat/core/resources/views/templates/basic/partials/breadcrumb.blade.php ENDPATH**/ ?>