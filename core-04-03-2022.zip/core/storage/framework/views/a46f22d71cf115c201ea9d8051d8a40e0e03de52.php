<?php $__env->startSection('content'); ?>
<?php
	$banner = getContent('banner.content', true);
?>
<!-- hero section start -->
<section class="hero bg_img" style="background-image: url('<?php echo e(getImage('assets/images/frontend/banner/' . @$banner->data_values->background_image, '1920x983')); ?>');">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xxl-7 col-xl-8 col-lg-10 text-center">
                <h2 class="hero__title wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">654SportsBet<sup>TM</sup> <?php echo e(__(@$banner->data_values->heading)); ?></h2>
                <p class="hero__description mt-3 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s"><?php echo e(__(@$banner->data_values->sub_heading)); ?><sup>TM</sup></p>
                <!-- <a href="<?php echo e(@$banner->data_values->button_link); ?>" class="btn btn--base btn--capsule mt-4 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.7s"><?php echo e(__(@$banner->data_values->button)); ?></a> -->
            </div>
        </div>
    </div>
</section>
<!-- hero section end -->
<?php
    $overview_elements = getContent('overview.element', false, null, true);
?>
<!-- overview section start -->
<!-- <div class="overview-section pb-50">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center overview-wrapper wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s">

        <?php $__empty_1 = true; $__currentLoopData = $overview_elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="overview-item mx-1">
                <div class="overview-card">
                    <div class="overview-card__icon">
                        <?php echo @$item->data_values->icon ?>
                    </div>
                    <div class="overview-card__content">
                        <h3 class="amount text--base text-shadow--base"><?php echo e(__(@$item->data_values->number)); ?></h3>
                        <p><?php echo e(__(@$item->data_values->title)); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>

        </div>
    </div>
</div> -->
<!-- overview section end -->


    <?php if($sections->secs != null): ?>
        <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/sportsBeat/core/resources/views/templates/basic/home.blade.php ENDPATH**/ ?>