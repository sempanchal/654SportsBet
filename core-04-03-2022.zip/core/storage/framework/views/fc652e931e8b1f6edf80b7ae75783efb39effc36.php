<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /opt/lampp/htdocs/sportsBeat/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>