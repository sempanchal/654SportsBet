<!-- lottery calender section start -->
<section class="pt-50 lottery_wrap">
        <div class="container">
            <div class="row">
             <?php $__empty_1 = true; $__currentLoopData = $events_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-team-popup game-table" data-id="<?php echo e(route('team_popup',$event['id'])); ?>">
                    <div class="arrow-right <?php echo e($event['lottery_status']); ?>">
                        <span><?php echo e($event['lottery_status']); ?></span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                            <img src="<?php echo e(get_sport_logo($event['sport_id'])); ?>" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3><?php echo e($event['jackpot_name']); ?></h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: <?php echo e($event['date']); ?></p>
                                <a href="javascript:void(0);" data-id="<?php echo e(route('rules_popup',$event['id'])); ?>" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                <!-- <a href="javascript:void(0)" data-id="<?php echo e(route('team_popup',$event['id'])); ?>" class="text-white underline mr-3 btn-modal-team-popup">Place Bet</a> -->
                                    <!-- <a href="javascript:void(0)" data-id="<?php echo e(route('team_schedule',$event['id'])); ?>" class="text-white underline btn-modal-schedule-popup">Schedule</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e(showAmount($event['price'],0)); ?></h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e($event['ticket_price']); ?></h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            <?php if(count($golflotteries_arr)>0): ?>
            <?php $__empty_1 = true; $__currentLoopData = $golflotteries_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-golf-popup game-table" data-id="<?php echo e(route('golf_team_popup',$event1['id'])); ?>">
                    <div class="arrow-right <?php echo e($event1['lottery_status']); ?>">
                        <span><?php echo e($event1['lottery_status']); ?></span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                             <img src="<?php echo e(asset('assets/images/sport_logo/golf.png')); ?>" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3><?php echo e($event1['jackpot_name']); ?></h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: <?php echo e($event1['end_date']); ?></p>
                                <!-- <a href="javascript:void(0);" data-id="<?php echo e(route('rules_popup',$event1['id'])); ?>" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e(showAmount($event1['jackpot_price'],0)); ?></h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5><?php echo e($general->cur_sym); ?><?php echo e($event1['ticket_price']); ?></h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            <?php endif; ?>
            </div>
        </div>
    </section>
<!-- lottery calender section end -->
<?php /**PATH /opt/lampp/htdocs/sportsBeat/core/resources/views/templates/basic/sections/lottery.blade.php ENDPATH**/ ?>