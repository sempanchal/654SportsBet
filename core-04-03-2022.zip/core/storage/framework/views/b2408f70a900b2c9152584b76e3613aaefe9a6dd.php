<?php $__env->startSection('content'); ?>
    <?php
        $contact_content = getContent('contact.content', true);
    ?>
<!-- contact section start -->
<section class="pt-100 pb-100">
    <div class="container">
        <div class="row justify-content-between gy-5">
            <div class="col-lg-4">
                <h2 class="mb-3"><?php echo e(__(@$contact_content->data_values->title)); ?></h2>
                <p><?php echo e(__(@$contact_content->data_values->content)); ?></p>

                <div class="row gy-4 mt-3">
                    <div class="col-lg-12">
                        <div class="contact-info-card rounded-3">
                            <h6 class="mb-3"><?php echo app('translator')->get('Office Address'); ?></h6>
                            <div class="contact-info d-flex">
                                <i class="las la-map-marked-alt"></i>
                                <p><?php echo e(__(@$contact_content->data_values->address)); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="contact-info-card rounded-3">
                            <h6 class="mb-3"><?php echo app('translator')->get('Phone'); ?></h6>
                            <div class="contact-info d-flex">
                                <i class="las la-phone-volume"></i>
                                <p><a href="tel:<?php echo e(@$contact_content->data_values->phone); ?>"><?php echo e(@$contact_content->data_values->phone); ?></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="contact-info-card rounded-3">
                            <h6 class="mb-3"><?php echo app('translator')->get('Email'); ?></h6>
                            <div class="contact-info d-flex">
                                <i class="las la-envelope"></i>
                                <p><a href="mailto:<?php echo e(@$contact_content->data_values->email); ?>"><?php echo e(@$contact_content->data_values->email); ?></a></p>
                            </div>
                        </div>
                    </div>
                </div><!-- row end -->

            </div>
            <div class="col-lg-8 ps-lg-5">
                <div class="contact-wrapper rounded-3">
                    <h2 class="mb-3"><?php echo app('translator')->get('Contact Us'); ?></h2>
                    <form class="contact-form" method="post" action="">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-lg-6 form-group">
                                <label><?php echo app('translator')->get('Name'); ?></label>
                                <div class="custom--field">
                                    <input name="name" type="text" placeholder="<?php echo app('translator')->get('Your Name'); ?>" class="form--control" value="<?php echo e(old('name')); ?>" required>
                                    <i class="las la-user"></i>
                                </div>
                            </div><!-- form-group end -->
                            <div class="col-lg-6 form-group">
                                <label><?php echo app('translator')->get('Email'); ?></label>
                                <div class="custom--field">
                                    <input name="email" type="text" placeholder="<?php echo app('translator')->get('Enter E-Mail Address'); ?>" class="form--control" value="<?php echo e(old('email')); ?>" required>
                                    <i class="las la-envelope"></i>
                                </div>
                            </div><!-- form-group end -->
                            <div class="col-lg-12 form-group">
                                <label><?php echo app('translator')->get('Subject'); ?></label>
                                <div class="custom--field">
                                    <input name="subject" type="text" placeholder="<?php echo app('translator')->get('Write your subject'); ?>" class="form--control" value="<?php echo e(old('subject')); ?>" required>
                                    <i class="las la-pen"></i>
                                </div>
                            </div><!-- form-group end -->
                            <div class="col-lg-12 form-group">
                                <label><?php echo app('translator')->get('Message'); ?></label>
                                <div class="custom--field">
                                    <textarea name="message" wrap="off" placeholder="<?php echo app('translator')->get('Write your message'); ?>" class="form--control"><?php echo e(old('message')); ?></textarea>
                                    <i class="las la-envelope"></i>
                                </div>
                            </div><!-- form-group end -->
                            <div class="col-lg-12 form-group">
                                <button type="submit" class="btn btn--base"><?php echo app('translator')->get('Submit Now'); ?></button>
                            </div><!-- form-group end -->
                        </div><!-- row end -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- contact section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/core/resources/views/templates/basic/contact.blade.php ENDPATH**/ ?>