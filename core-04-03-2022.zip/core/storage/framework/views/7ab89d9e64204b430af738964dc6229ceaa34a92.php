<div class="row">
    <?php $__currentLoopData = $my_player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 col-6 text-center mb-2">
        <div class="logo_name_score_wrap mb-2 p-2" style="background: #fefe;border-radius: 5px;">
            <h3><?php echo e($player['first_name'].' '.$player['last_name']); ?></h3>
            <h5><?php echo e($player['country']); ?></h5>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /var/www/html/core/resources/views/admin/glof/selected_player_popup.blade.php ENDPATH**/ ?>