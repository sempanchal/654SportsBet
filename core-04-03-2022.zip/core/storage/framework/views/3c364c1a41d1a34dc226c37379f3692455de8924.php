<div class="row">
    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 col-6 text-center mb-2">
        <div class="logo_name_score_wrap">
            <h3><img src="<?php echo e(log_logos($team->team_id)); ?>" alt="logo" height="50" width="50"> <span><?php echo e($team->abbreviation); ?></span></h3>
            <?php echo e($team->mascot); ?>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /var/www/html/core/resources/views/admin/lottery/userlotteryTeams.blade.php ENDPATH**/ ?>