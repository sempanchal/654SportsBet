<!doctype html>
<html lang="en" itemscope itemtype="http://schema.org/WebPage">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> <?php echo e($general->sitename(__($pageTitle))); ?></title>
<?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- bootstrap 5  -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/lib/bootstrap.min.css')); ?>">
    <!-- fontawesome 5  -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/all.min.css')); ?>">
    <!-- lineawesome font -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/line-awesome.min.css')); ?>">
    <!-- slick slider css -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/lib/slick.css')); ?>">
    <!-- main css -->
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/main.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/bootstrap-fileinput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset($activeTemplateTrue.'css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/vendor/bootstrap-toggle.min.css')); ?>">
    <!-- <link rel=¨stylesheet¨ type=¨text/css¨ href=¨https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css¨> -->

    <link rel="stylesheet"
          href="<?php echo e(asset($activeTemplateTrue.'css/color.php?color='.$general->base_color.'&secondColor='.$general->secondary_color)); ?>">

    <?php echo $__env->yieldPushContent('style-lib'); ?>

    <?php echo $__env->yieldPushContent('style'); ?>
    <style>
        .bottom-nav {
            margin-top: 100px;
            display: flex;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 0.8rem 0;
            background-color: #252a32;
            z-index: 99;
            will-change: transform;
            transform: translateZ(0);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 3px rgba(0, 0, 0, 0.24);
        
        }
        .bottom-nav img{
            height: 30px;
            width: 30px;
        }
        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            flex-grow: 1;
            justify-content: center;
            text-align: center;
            font-size: 0.8rem;
            color: #f1f5f8;
        }
        .bottom-nav-link {
            display: flex;
            flex-direction: column;
            align-items:center;
        }
        .bottom-nav .active {
            color: #F89316;
        }
        
        .top-nav{
            top: -10px;
            /*margin: 10px 0;*/
            position: relative;
            display: block;
            width: 3.5rem;
            height: 2.25rem;
            cursor: pointer;
            background: transparent;
            /*border-top: 2px solid;*/
            /*border-bottom: 2px solid;*/
            color: #fff;
            font-size: 0;
            -webkit-transition: all 0.25s ease-in-out;
            -o-transition: all 0.25s ease-in-out;
            transition: all 0.25s ease-in-out;
            cursor: pointer;
        }
        @media  only screen and (min-width: 600px) {
            .bottom-nav{
                display:none;
            }
            .top-nav{
                display:none;
            }
        }
    </style>
</head>
<body>

<?php echo $__env->yieldPushContent('fbComment'); ?>

<div class="preloader">
    <div class="preloader-container">
        <span class="animated-preloader"></span>
    </div>
</div>

<!-- scroll-to-top start -->
<!-- <div class="scroll-to-top" style="margin-bottom: 50px;">
    <span class="scroll-icon">
      <i class="fa fa-rocket" aria-hidden="true"></i>
    </span>
</div> -->
<!-- scroll-to-top end -->

<!-- header-section start  -->
<header class="header">
    <div class="header__bottom">
        <div class="container-fluid px-lg-5">
            <nav class="navbar navbar-expand-xl p-0 align-items-center">
                <a class="site-logo site-title" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/'.$general->logo)); ?>" alt="logo"></a>
               <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                    <span class="menu-toggle"></span>
                </button> -->
                <!-- 20-01-2022 -->
                 <?php if(auth()->guard()->check()): ?>
                    <!-- <div class="top-nav">
                      <div class="top-nav-item">
                        <a href="<?php echo e(route('user.logout')); ?>">
                        <div class="top-nav-link">
                            <img src="<?php echo e(getImage('assets/images/icons/logout.png')); ?>" alt="logout" />
                        </div>
                        </a>
                      </div>
                    </div> -->
                 <?php endif; ?>
                <!-- 20-01-2022 -->
                <div class="collapse navbar-collapse mt-lg-0 mt-3" id="navbarSupportedContent">
                    <ul class="navbar-nav main-menu me-auto">
                        <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                        <li><a href="<?php echo e(route('lottery')); ?>"><?php echo app('translator')->get('Games'); ?></a></li>

                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(__($data->name)); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- <li><a href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a></li> -->
                        <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
                    </ul>
                    <div class="nav-right">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('user.home')); ?>" class="btn btn-sm btn--base me-sm-3 me-2 btn--capsule px-3"><?php echo app('translator')->get('Dashboard'); ?></a>
                            <a href="<?php echo e(route('user.logout')); ?>" class="text-white fs--14px me-sm-3 me-2"><?php echo app('translator')->get('Logout'); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('user.login')); ?>" class="btn btn-sm btn--base me-sm-3 me-2 btn--capsule px-3"><?php echo app('translator')->get('Login'); ?></a>
                            <a href="<?php echo e(route('user.register')); ?>" class="text-white fs--14px me-sm-3 me-2"><?php echo app('translator')->get('Register'); ?></a>
                        <?php endif; ?>
                        <select class="language-select langSel">
                            <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </nav>
        </div>
    </div><!-- header__bottom end -->
</header>
<!-- header-section end  -->

<div class="main-wrapper">

    <?php if(!request()->routeIs('home')): ?>
        <?php echo $__env->make($activeTemplate.'partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

</div><!-- main-wrapper end -->

<?php
    $footer_content = getContent('footer.content', true);
    $footer_elements = getContent('footer.element');
    $extra_pages = getContent('extra.element');
?>
<!-- footer start -->
<footer class="footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-2 col-md-3 text-md-start text-center">
                <a href="<?php echo e(route('home')); ?>" class="footer-logo"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="image"></a>
            </div>
            <div class="col-lg-10 col-md-9 mt-md-0 mt-3">
                <ul class="inline-menu d-flex flex-wrap justify-content-md-end justify-content-center align-items-center">
                    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                    <li><a href="<?php echo e(route('lottery')); ?>"><?php echo app('translator')->get('Games'); ?></a></li>

                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(__($data->name)); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__empty_1 = true; $__currentLoopData = $extra_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li><a href="<?php echo e(route('links',[$item->id,slug($item->data_values->title)])); ?>"><?php echo e(__(@$item->data_values->title)); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div><!-- row end -->
        <hr class="mt-3">
        <div class="row align-items-center">
            <div class="col-md-4 text-md-start text-center">
                <p><?php echo e(__(@$footer_content->data_values->copyright)); ?></p>
            </div>
            <div class="col-md-6 text-center">
                <p>Covered by: Pat. 8,876,593 and Pat. 9,153,099.</p>
            </div>
            <div class="col-md-2 mt-md-0 mt-3">
                <ul class="inline-social-links d-flex align-items-center justify-content-md-end justify-content-center">
                    <?php $__empty_1 = true; $__currentLoopData = $footer_elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li><a href="<?php echo e(@$item->data_values->social_link); ?>" target="_blank"><?php echo @$item->data_values->social_icon ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- footer end -->
<nav class="bottom-nav">
      <div class="bottom-nav-item">
        <a href="<?php echo e(route('home')); ?>">
        <div class="bottom-nav-link">
        <img src="<?php echo e(getImage('assets/images/icons/home-page.png')); ?>" alt="games" />
          <span>Home</span>
        </div>
        </a>
      </div>
      <div class="bottom-nav-item">
        <a href="<?php echo e(route('lottery')); ?>">
        <div class="bottom-nav-link">
          <img src="<?php echo e(getImage('assets/images/icons/american-football.png')); ?>" alt="games" />
          <span>Games</span>
        </div>
        </a>
      </div>
      
      <div class="bottom-nav-item">
        <a href="<?php if(auth()->guard()->check()): ?> <?php echo e(route('user.my-bets')); ?> <?php else: ?> <?php echo e(route('user.login')); ?> <?php endif; ?>">
            <div class="bottom-nav-link">
            <img src="<?php echo e(getImage('assets/images/icons/my-bets.png')); ?>" alt="games" />
              <span>My Bets</span>
            </div>
        </a>
      </div>

      <div class="bottom-nav-item">
        <a href="<?php if(auth()->guard()->check()): ?> <?php echo e(route('user.home')); ?> <?php else: ?> <?php echo e(route('user.login')); ?> <?php endif; ?>">
            <div class="bottom-nav-link">
              <img src="<?php echo e(getImage('assets/images/icons/wallet.png')); ?>" alt="games" />
              <span>Wallet</span>
            </div>
        </a>
      </div>

      <div class="bottom-nav-item">
        <a href="<?php if(auth()->guard()->check()): ?> <?php echo e(route('user.profile.setting')); ?> <?php else: ?> <?php echo e(route('user.login')); ?> <?php endif; ?>">
            <div class="bottom-nav-link">
            <img src="<?php echo e(getImage('assets/images/icons/account.png')); ?>" alt="games" />
              <span>Account</span>
            </div>
        </a>
      </div>
    </nav>

<?php
    $cookie = App\Models\Frontend::where('data_keys','cookie.data')->first();
?>
<?php if(@$cookie->data_values->status && !session('cookie_accepted')): ?>
    <div class="cookie__wrapper">
        <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-between">
                <p class="txt my-2">

                    <?php echo @$cookie->data_values->description ?>

                    <a href="<?php echo e(@$cookie->data_values->link); ?>" target="_blank" class="text--base"><?php echo app('translator')->get('Read Policy'); ?></a>
                </p>
                <button class="btn btn--base btn-md my-2 acceptPolicy">Accept</button>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- jQuery library -->
<script src="<?php echo e(asset($activeTemplateTrue.'js/lib/jquery-3.6.0.min.js')); ?>"></script>
<!-- bootstrap js -->
<script src="<?php echo e(asset($activeTemplateTrue.'js/lib/bootstrap.bundle.min.js')); ?>"></script>
<!-- slick slider js -->
<script src="<?php echo e(asset($activeTemplateTrue.'js/lib/slick.min.js')); ?>"></script>
<!-- scroll animation -->
<script src="<?php echo e(asset($activeTemplateTrue.'js/lib/wow.min.js')); ?>"></script>
<!-- apex chart js -->
<script src="<?php echo e(asset($activeTemplateTrue.'js/lib/jquery.countdown.js')); ?>"></script>
<!-- main js -->
<script src="<?php echo e(asset($activeTemplateTrue.'js/app.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/js/vendor/bootstrap-toggle.min.js')); ?>"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.10.1/dist/sweetalert2.all.min.js"></script> -->

<?php echo $__env->yieldPushContent('script-lib'); ?>

<?php echo $__env->yieldPushContent('script'); ?>

<?php echo $__env->make('partials.plugins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('partials.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script>
    (function ($) {
        "use strict";
        $(".langSel").on("change", function () {
            window.location.href = "<?php echo e(route('home')); ?>/change/" + $(this).val();
        });

        //Cookie
        $(document).on('click', '.acceptPolicy', function () {
            $.ajax({
                url: "<?php echo e(route('cookie.accept')); ?>",
                method:'GET',
                success:function(data){
                    if (data.success){
                        $('.cookie__wrapper').addClass('d-none');
                        //notify('success', data.success)
                    }
                },
            });
        });
    })(jQuery);
</script>

<!-- Custom by amit -->
<div class="modal" tabindex="-1" role="dialog" id="modal-choose-team">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Choose 6 Teams</h5>
                <button type="button" onclick="$('#modal-choose-team').hide()" class="btn btn-sm btn-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="max-height: 70vh;overflow: auto;"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn--base" id="quick_picks">Quick Pick </button>
                <button type="button" class="btn btn--base" id="clear_picks">Clear Pick </button>
                <button type="submit" form="form-choose-team" class="btn btn--base" id="buy_ticket">Submit</button>
            </div>
        </div>
    </div>
</div>
<div class="modal" tabindex="-1" role="dialog" id="modal-game-schedule">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Schedules</h5>
                <button type="button" onclick="$('#modal-game-schedule').hide()" class="btn btn-sm btn-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="max-height: 70vh;overflow: auto;"></div>
        </div>
    </div>
</div>
<!-- Custom by sunny -->
<div class="modal" tabindex="-1" role="dialog" id="modal-game-rules">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Summary</h5>
                <button type="button" onclick="$('#modal-game-rules').hide()" class="btn btn-sm btn-danger" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="max-height: 70vh; overflow: auto;">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn--base" onclick="$('#modal-game-rules').hide()">Close</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
$(document).on("click",".cust_rules_popup",function(event) {
    $('#modal-choose-team').hide();
    $btn = $(this);
    $action = $btn.attr('data-id');
    //alert($action);
    $.ajax({
        url: $action + '?type=team',
        type: 'get',
        dataType: 'json',
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            console.log(json);
            if(json.success){
                $('#modal-game-rules .modal-body').html(json.html);
                $("#modal-game-rules").show();
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
    });
});
$(document).ready(function(){

    $(".btn-modal-rules-popup,.cust_rules_popup").click(function(event){
        event.stopPropagation();
        //alert("rules click");
        $btn = $(this);
        $action = $btn.attr('data-id');
        //alert($action);
        $.ajax({
            url: $action + '?type=team',
            type: 'get',
            dataType: 'json',
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                console.log(json);
                if(json.success){
                    $('#modal-game-rules .modal-body').html(json.html);
                    $("#modal-game-rules").show();
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            },
        });
    });
    //$('.card.btn-modal-team-popup').on('click', function(){
    $(".card.btn-modal-team-popup").click(function(event){
        //alert("cart click");
        $btn = $(this);
        $action = $btn.attr('data-id');
        $.ajax({
            url: $action + '?type=team',
            type: 'get',
            dataType: 'json',
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                if(json.success){
                    $('#modal-choose-team .modal-body').html(json.html);
                    //$('#modal-choose-team #buy_ticket').html(json.ticket_price);
                    $('#modal-choose-team').show();
                }else{
                    /*iziToast['error']({
                        message: json.error,
                        position: "topRight"
                    });*/
                    window.location.href = json.url;
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            },
            error: function(xhr, exception){
                $btn.prop('disabled', false);

                if(xhr.responseJSON){
                    $.each(xhr.responseJSON.errors, function(k,v){
                        /*iziToast['error']({
                            message: v[0],
                            position: "topRight"
                        });*/
                        Swal.fire({
                            toast: false,
                            title: v[0],
                            animation: false,
                            position: 'center',
                            showConfirmButton: true,
                            background:'#000000e3',
                            confirmButtonColor:'#ffb400',
                            customClass: {
                              title: 'cust_popup_title',
                            },
                            timer: 5000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                              toast.addEventListener('mouseenter', Swal.stopTimer)
                              toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        });
                    });
                }
            }
        });
    }); 

    //golf teams popup
    $(".card.btn-modal-golf-popup").click(function(event){
        //alert("cart click");
        $btn = $(this);
        $action = $btn.attr('data-id');
        $.ajax({
            url: $action,
            type: 'get',
            dataType: 'json',
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                //alert("cart click1");
                console.log(json);
                if(json.success){
                    $('#modal-choose-team .modal-body').html(json.html);
                    //$('#modal-choose-team #buy_ticket').html(json.ticket_price);
                    $('#modal-choose-team').show();
                }else{
                    /*iziToast['error']({
                        message: json.error,
                        position: "topRight"
                    });*/
                    window.location.href = json.url;
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            },
            error: function(xhr, exception){
                $btn.prop('disabled', false);

                if(xhr.responseJSON){
                    $.each(xhr.responseJSON.errors, function(k,v){
                        /*iziToast['error']({
                            message: v[0],
                            position: "topRight"
                        });*/
                        Swal.fire({
                            toast: false,
                            title: v[0],
                            animation: false,
                            position: 'center',
                            showConfirmButton: true,
                            background:'#000000e3',
                            confirmButtonColor:'#ffb400',
                            customClass: {
                              title: 'cust_popup_title',
                            },
                            timer: 5000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                              toast.addEventListener('mouseenter', Swal.stopTimer)
                              toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        });
                    });
                }
            }
        });
    });
});
$('.btn-modal-schedule-popup').on('click', function(){
    $btn = $(this);
    $action = $btn.attr('data-id');
    $.ajax({
        url: $action + '?type=schedule',
        type: 'get',
        dataType: 'json',
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            if(json.success){
                $('#modal-game-schedule .modal-body').html(json.html);
                $('#modal-game-schedule').show();
            }else{
                // iziToast['error']({
                //     message: json.error,
                //     position: "topRight"
                // });
                Swal.fire({
                    toast: false,
                    title: json.error,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    background:'#000000e3',
                    confirmButtonColor:'#ffb400',
                    customClass: {
                      title: 'cust_popup_title',
                    },
                    timer: 5000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
        error: function(xhr, exception){
            $btn.prop('disabled', false);

            if(xhr.responseJSON){
                $.each(xhr.responseJSON.errors, function(k,v){
                    // iziToast['error']({
                    //     message: v[0],
                    //     position: "topRight"
                    // });
                    Swal.fire({
                        toast: false,
                        title: v[0],
                        animation: false,
                        position: 'center',
                        showConfirmButton: true,
                        background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                        timer: 5000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener('mouseenter', Swal.stopTimer)
                          toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    });
                });
            }
        }
    });
});
$(document).delegate('#form-choose-team', 'submit', function(e){
    e.preventDefault();

    $form = $(this);
    $btn = $('[form="form-choose-team"]');
    $.ajax({
        url: $form.attr('action'),
        type: $form.attr('method'),
        dataType: 'json',
        data: $form.serialize(),
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        beforeSend: function(){
            $btn.prop('disabled', true);
        },
        success: function(json){
            if(json.success){
                $('#modal-choose-team').hide();

                /*iziToast['success']({
                    message: json.message,
                    position: "topRight"
                });*/

                Swal.fire({
                    toast: false,
                    title: json.message,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    background:'#000000e3',
                    confirmButtonColor:'#ffb400',
                    customClass: {
                          title: 'cust_popup_title',
                        },
                    timer: 5000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            }else{
                /*iziToast['error']({
                    message: json.error,
                    position: "topRight"
                });*/
                Swal.fire({
                    toast: false,
                    title: json.error,
                    animation: false,
                    position: 'center',
                    showConfirmButton: true,
                    background:'#000000e3',
                    confirmButtonColor:'#ffb400',
                    customClass: {
                          title: 'cust_popup_title',
                        },
                    timer: 5000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                      toast.addEventListener('mouseenter', Swal.stopTimer)
                      toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });
            }
        },
        complete: function(){
            $btn.prop('disabled', false);
        },
        error: function(xhr, exception){
            $btn.prop('disabled', false);

            if(xhr.responseJSON){
                $.each(xhr.responseJSON.errors, function(k,v){
                    /*iziToast['error']({
                        message: v[0],
                        position: "topRight"
                    });*/
                    Swal.fire({
                        toast: false,
                        title: v[0],
                        animation: false,
                        position: 'center',
                        showConfirmButton: true,
                        background:'#000000e3',
                        confirmButtonColor:'#ffb400',
                        customClass: {
                          title: 'cust_popup_title',
                        },
                        timer: 5000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                          toast.addEventListener('mouseenter', Swal.stopTimer)
                          toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    });

                });
            }
        }
    });
});
$(document).delegate('[name="checkall"]', 'change', function(){
    var checked = $(this).prop('checked');
    $('[name="team_id[]"]').prop('checked', checked);
});
</script>
<!-- End Custom by amit -->

</body>
</html>
<?php /**PATH /opt/lampp/htdocs/sportsBeat/core/resources/views/templates/basic/layouts/frontend.blade.php ENDPATH**/ ?>