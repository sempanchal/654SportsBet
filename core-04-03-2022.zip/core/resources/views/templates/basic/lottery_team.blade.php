<!-- <div class="row">
    <div class="col-2 text-center">
        <img src="{{ get_sport_logo($lottery->sport_id) }}" alt="image" height="70" width="70">
    </div>
    <div class="col-6">
        <h4>{{ $cur_sym.showAmount($lottery->price,0) }} &nbsp; {{ $lottery->jackpot_name }}</h4>
        <span> <i class="las la-ticket-alt"></i> {{ $total_tickets_bought }}</span>&nbsp; | &nbsp;<span><a href="javascript:void(0)" data-id="{{ route('rules_popup',$lottery_id) }}" class="cust_rules_popup text-success" style="text-decoration: underline;">@lang('Pay Table and Rules')</a></span>
    </div>
    <div class="col-12"><hr/></div>
</div> -->
<div class="lottery_wrap">
        <div class="card game-table">
            <div class="arrow-right">
                <span>{{ $lottery_status }}</span>
              </div>
          <div class="card-body text-white">
            <div class="d-flex align-items-center">
                    <div class="game-logo-img">
                        <img src="{{ get_sport_logo($lottery->sport_id) }}" alt="image" width="70">
                    </div>
                    <div class="d-flex flex-column game-title-wrapper">
                        <h3>{{ $lottery->jackpot_name }}</h3>
                        <div class="d-flex justify-content-between">
                            <p>Pool Ends: {{ $edate }}</p>
                            <a href="javascript:void(0)" data-id="{{ route('rules_popup',$lottery_id) }}" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                        </div>
                    </div>
                </div>
                
                <!-- <div class="cut-links">
                    <a href="javascript:void(0)" data-id="{{ route('rules_popup',$lottery_id) }}" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                </div> -->

                <!-- <div class="col-md-2 text-center">
                    <img src="{{ get_sport_logo($lottery->sport_id) }}" alt="image" width="70">
                </div> -->
                <div class="row">
                <div class="col-md-12 mt-3">
                    <!-- <h3 class="card-title">{{ $lottery->jackpot_name }}</h3>
                    <div class="cut-body my-4">
                        <span class="white-colour"><b>Pool Ends:</b> {{ $edate }}</span>
                        <div class="cut-links">
                            <a href="javascript:void(0)" data-id="{{ route('rules_popup',$lottery_id) }}" class="cust_rules_popup text-white underline">Pay Table and Rules</a>
                        </div>
                    </div> -->
                    <div class="cut-footer ticket-info">
                        <ul class="">
                            <li class="text-center">
                                <h5>{{ $cur_sym.showAmount($lottery->price,0) }}</h5>
                                <span> Prize pool</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5>$10</h5>
                                <span>Entry</span>
                            </li>
                            <li class="v-sep"></li>
                            <li class="text-center">
                                <h5>{{ $total_tickets_bought }}</h5>
                                <span>Total Entries</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
          </div>
        </div>
</div>
<div class="col-12"><hr/></div>
<form action="{{ $action }}" method="post" id="form-choose-team">
    <div class="table-responsive">
        <table class="table custom-table-new">
            <tr>
                <td><h3 class="text-center pb-3">Away</h3></td>
                <td><h3 class="text-center pb-3">Home</h3></td>
            </tr> 
        @php
            $i = 1;
        @endphp   
        @foreach($games as $gkey => $game)
            <tr>
                <tr>
                    <th colspan="2" class="text-center font-12">
                        {{ $game['name'] }} - {{ \Carbon\Carbon::parse($game['date'])->format('F jS, Y h:i A') }}
                        <input type="hidden" name="games[{{ $gkey }}][game_id]" value="{{ $game['game_id'] }}" />
                        <input type="hidden" name="games[{{ $gkey }}][date]" value="{{ $game['date'] }}" />
                        <input type="hidden" name="games[{{ $gkey }}][price]" value="{{ $game['price'] }}" />
                    </th>
                </tr>
                
                @foreach($game['teams'] as $tkey => $team)
                <td class="text-center">
                    <input type="checkbox" data-val="{{ $i.'-'.$team['team_id'] }}" name="games[{{ $gkey }}][team][{{ $i }}][team_id]" value="{{ $team['team_id'] }}"/>
                    <span class="d-flex game_ticket">
                        <div class="game_ticket_img">
                        <img src="{{ log_logos($team['team_id']) }}" alt="logo" height="50" width="100"> 
                    </div>
                    <div style="text-align: left;width: 50%;">
                        <h4>{{ $team['abbreviation'] }} </h4>
                        <p>{{ $team['mascot'] }}</p>
                        </div>
                    </span>
                    <input type="hidden" name="games[{{ $gkey }}][team][{{ $i }}][mascot]" value="{{ $team['mascot'] }}"/>
                    <input type="hidden" name="games[{{ $gkey }}][team][{{ $i }}][abbreviation]" value="{{ $team['abbreviation'] }}"/>
                </td>
                @php
                    $i++;
                @endphp
                @endforeach
            </tr>
        @endforeach
        </table>
    </div>
    <input type="hidden" name="ticket_price" value="{{ $ticket_price }}">
    <input type="hidden" name="lottery_id" value="{{ $lottery_id }}">
</form>
