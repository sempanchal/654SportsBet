@extends($activeTemplate.'layouts.frontend')
@section('content')
   <section class="pt-50 lottery_wrap">
        <div class="container">
            <div class="row">
             @forelse($events_arr as $event)
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-team-popup game-table" data-id="{{ route('team_popup',$event['id']) }}">
                    <div class="arrow-right {{ $event['lottery_status'] }}">
                        <span>{{ $event['lottery_status'] }}</span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                            <img src="{{ get_sport_logo($event['sport_id']) }}" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3>{{ $event['jackpot_name'] }}</h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: {{ $event['date'] }}</p>
                                <a href="javascript:void(0);" data-id="{{ route('rules_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a>
                                <!-- <a href="javascript:void(0)" data-id="{{ route('team_popup',$event['id']) }}" class="text-white underline mr-3 btn-modal-team-popup">Place Bet</a> -->
                                    <!-- <a href="javascript:void(0)" data-id="{{ route('team_schedule',$event['id']) }}" class="text-white underline btn-modal-schedule-popup">Schedule</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ showAmount($event['price'],0) }}</h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ $event['ticket_price'] }}</h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                  </div>
                </div>
              </div>
            @empty
            @endforelse
            <!-- Golf -->
           @php  @endphp
            @forelse($golflotteries_arr as $event1)
              <div class="col-md-6 mb-3">
                <div class="card btn-modal-golf-popup game-table" data-id="{{ route('golf_team_popup',$event1['id']) }}">
                    <div class="arrow-right {{ $event1['lottery_status'] }}">
                        <span>{{ $event1['lottery_status'] }}</span>
                      </div>
                  <div class="card-body text-white">
                    <div class="d-flex align-items-center">
                        <div class="game-logo-img">
                             <img src="{{ asset('assets/images/sport_logo/golf.png') }}" alt="image" width="100">
                        </div>
                        <div class="d-flex flex-column game-title-wrapper">
                            <h3>{{ $event1['jackpot_name'] }}</h3>
                            <div class="d-flex justify-content-between">
                                <p>Pool Ends: {{ $event1['end_date'] }}</p>
                                <!-- <a href="javascript:void(0);" data-id="{{ route('rules_popup',$event1['id']) }}" class="text-white underline mr-3 btn-modal-rules-popup">Pay Table and Rules</a> -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <div class="cut-footer ticket-info">
                                <ul class="">
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ showAmount($event1['jackpot_price'],0) }}</h5>
                                        <span> Prize pool</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>{{ $general->cur_sym }}{{ $event1['ticket_price'] }}</h5>
                                        <span>Entry</span>
                                    </li>
                                    <li class="v-sep"></li>
                                    <li class="text-center">
                                        <h5>UNLIMITED</h5>
                                        <span>Total Entries</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            @empty
            @endforelse
            @php  @endphp
            </div>
        </div>
    </section>

<!--     <section class="pt-50 pb-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive--md">
                        <table class="table custom--table">
                        <thead>
                        <tr class="dark-gray">
                            <th class="text-center">@lang('Jackpot Game')</th>
                            <th class="text-center">@lang('Sport')</th>
                            <th class="text-center">@lang('Rules')</th>
                            <th class="text-center">@lang('Prize Pool')</th>
                            <th class="text-center">@lang('Entry')</th>
                            <th class="text-center">@lang('Actions')</th>
                        </tr>
                        </thead>
                        <tbody>

                        @forelse($events as $event)
                            <tr>
                                <td class="text-center" data-label="@lang('Jackpot Game')">{{ $event->jackpot_name }}</td>
                                <td class="text-center" data-label="@lang('Sport')">
                                    <div class="table-game">
                                        <img src="{{ get_sport_logo($event->sport_id) }}" alt="image" width="50">
                                        <h6 class="name">{{ __($event->name) }}</h6>
                                    </div>
                                </td>
                                <td class="text-center" data-label="@lang('Rules')"><a href="javascript:void(0)" data-id="{{ route('rules_popup',$event->id) }}" class="btn btn-modal-rules-popup btn-sm btn-outline--base dark-gray">@lang('Pay Table and Rules')</a></td>
                                <td class="text-center" data-label="@lang('Prize Pool')">{{ $general->cur_sym }}{{ showAmount($event->price,0) }}</td>
                                <td class="text-center" data-label="@lang('Entry')">{{ $general->cur_sym }}{{ $event->ticket_price }}</td>
                                <td class="text-center" data-label="@lang('Actions')">
                                    <a href="javascript:void(0)" data-id="{{ route('team_popup',$event->id) }}" class="btn btn-modal-team-popup btn-sm btn-outline--base dark-gray">@lang('Place Bet')</a>
                                    <a href="javascript:void(0)" data-id="{{ route('team_schedule',$event->id) }}" class="btn btn-modal-schedule-popup btn-sm btn-outline--base dark-gray">@lang('Schedule')</a>
                                </td>
                            </tr>
                        @empty
                        @endforelse

                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <div class="mt-2">
                {{ $phases->links() }}
            </div>
        </div>
    </section> -->
@endsection