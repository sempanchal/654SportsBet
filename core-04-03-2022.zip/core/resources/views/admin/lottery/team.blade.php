<div class="modal-header">
    <h5 class="modal-title">Choose Team</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
@if($events)
<div class="modal-body" style="max-height: 700px;overflow: auto;">
    <form action="{{ $action }}" method="post" id="form-choose-team">
        <div class="table-responsive">
            @foreach($events as $eventsss)
            @foreach($eventsss as $ekey => $event)
            <table class="table">
                <thead>
                    <tr>
                        <th colspan="4" class="text-center">{{ \Carbon\Carbon::parse($event['event_date'])->timezone('America/New_York') }}</th>
                    </tr>
                    <tr>
                        <th>
                            <input type="checkbox" name="event_id[]" value="{{ $event['event_id'] }}" @if(in_array($event['event_id'], $event_data))checked="checked"@endif />
                            <input type="hidden" name="event[{{ $event['event_id'] }}][event_id]" value="{{ $event['event_id'] }}" />
                            <input type="hidden" name="event[{{ $event['event_id'] }}][event_name]" value="{{ $event['schedule']['event_name'] }}" />
                            <input type="hidden" name="event[{{ $event['event_id'] }}][event_date]" value="{{ \Carbon\Carbon::parse($event['event_date'])->timezone('America/New_York') }}" />
                        </th>
                        <th class="text-left">Team Name</th>
                        <th class="text-left">Is Away</th>
                        <th class="text-left">Is Home</th>
                    </tr>
                </thead>
                <tbody>
                    @if(isset($event['teams_normalized']) && is_array($event['teams_normalized']))
                        @foreach($event['teams_normalized'] as $tkey => $team)
                        <tr>
                            <td class="ssuunn">
                                <input type="checkbox" name="team_id[{{ $event['event_id'] }}][]" class="team_id" value="{{ $team['team_id'] }}" @if(isset($team_data[$event['event_id']]) && in_array($team['team_id'], $team_data[$event['event_id']]))checked="checked"@endif />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}]" value="{{ $team['team_id'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][name]" value="{{ $team['name'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][mascot]" value="{{ $team['mascot'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][abbreviation]" value="{{ $team['abbreviation'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][is_away]" value="{{ $team['is_away'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][is_home]" value="{{ $team['is_home'] }}" />
                            </td>
                            <td class="text-left">{{ $team['name'] }}</td>
                            <td class="text-left">{{ $team['is_away'] == 1 ? "Yes" : "No" }}</td>
                            <td class="text-left">{{ $team['is_home'] == 1 ? "Yes" : "No" }}</td>
                        </tr>
                        @endforeach
                    @elseif(isset($event['teams']) && is_array($event['teams']))
                        @foreach($event['teams'] as $tkey => $team)
                        <tr>
                            <td>
                                <input type="checkbox" name="team_id[{{ $event['event_id'] }}][]" class="team_id" value="{{ $team['team_id'] }}" @if(isset($team_data[$event['event_id']]) && in_array($team['team_id'], $team_data[$event['event_id']]))checked="checked"@endif />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}]" value="{{ $team['team_id'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][name]" value="{{ $team['name'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][is_away]" value="{{ $team['is_away'] }}" />
                                <input type="hidden" name="event[{{ $event['event_id'] }}][teams][{{ $team['team_id'] }}][is_home]" value="{{ $team['is_home'] }}" />
                            </td>
                            <td class="text-left">{{ $team['name'] }}</td>
                            <td class="text-left">{{ $team['is_away'] == 1 ? "Yes" : "No" }}</td>
                            <td class="text-left">{{ $team['is_home'] == 1 ? "Yes" : "No" }}</td>
                        </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
            @endforeach
            @endforeach
        </div>
    </form>
</div>
<div class="modal-footer">
    <input type="checkbox" data-width="120px" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="@lang('Check all')" data-off="@lang('Uncheck all')" name="checkallgame">
    <button type="submit" form="form-choose-team" class="btn btn-primary">Save</button>
</div>
<script>
$('[name="checkallgame"]').bootstrapToggle();
</script>
@else
<div class="modal-body" style="max-height: 700px;overflow: auto;">
    <table>
        <tr>
            <td class="text-center">No games found!</td>
        </tr>
    </table>
</div>
@endif