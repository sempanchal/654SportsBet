@extends('admin.layouts.app')
@section('panel')
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <form action="{{ route('admin.glof.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>@lang('Jackpot Name')</label>
                                <input type="text" class="form-control" value="{{ old('jackpot_name') }}" placeholder="@lang('Jackpot Name')" name="jackpot_name"/>
                            </div>
                            <div class="form-group">
                                <label>@lang('Sport')</label>
                                <input  type="text" data-language="en" name="sport" class="form-control" value="Golf PGA" readonly>
                            </div>
                            <div class="form-group">
                                <label>@lang('Tournament')</label>
                                <div>
                                    <select name="tournament_id" class="form--control select2" id="tournament_id" value="{{ old('tournament_id') }}" requierd>
                                        <option value="" data-id="0" >--SELECT--</option>
                                        @if($tournaments)    
                                        @foreach($tournaments as $tournament)    
                                        <option value="{{ $tournament->tournament_id }}">{{ $tournament->name.' ('.$tournament->start_date.' to '.$tournament->end_date.')' }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>@lang('Starting Jackpot')</label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="@lang('minimum price money')" name="jackpot_price" value="{{ old('jackpot_price') }}">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">{{ $general->cur_sym }}</span>
                                  </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>@lang('Ticket Price')</label>
                                <div class="input-group mb-3">
                                  <input type="number" class="form-control" placeholder="@lang('Ticket Price')" name="ticket_price" value="{{ old('ticket_price') }}">
                                  <div class="input-group-append">
                                    <span class="input-group-text" id="basic-addon2">{{ $general->cur_sym }}</span>
                                  </div>
                                </div>
                            </div>
                            <!-- 20-12-2021 -->
                            <div class="form-group">
                                <label>@lang('1st place percentage')</label>
                                <input type="number" class="form-control" placeholder="@lang('Winner 1st place percentage')" max="100" name="first_place" value="70">
                            </div>
                            <div class="form-group">
                                <label>@lang('2st place percentage')</label>
                                <input type="number" class="form-control" placeholder="@lang('Winner 2st place percentage')" max="100" name="second_place" value="20">
                            </div>
                            <div class="form-group">
                                <label>@lang('3st place percentage')</label>
                                <input type="number" class="form-control" placeholder="@lang('Winner 3st place percentage')" max="100" name="third_place" value="10">
                            </div>
                            <div class="form-group">
                                <label>@lang('Maximum number of entries per user')</label>
                                <input type="number" class="form-control" placeholder="@lang('0 for infinite')" name="no_of_entries" value="{{ old('no_of_entries') }}"/>
                            </div>
                            <div class="form-group">
                                <!-- nicEdit -->
                                <label>@lang('Game Instruction')</label>
                                <textarea rows="8" class="ckeditor form-control" placeholder="@lang('Game Instruction')" name="detail">{{ old('detail') }}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-row justify-content-center">
                        <div class="form-group col-md-12">
                            <button type="submit" class="btn btn-block btn--primary mr-2">@lang('Post')</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@include('admin.lottery.footerdata')
@endsection

@push('breadcrumb-plugins')
<a href="{{ route('admin.glof.index') }}" class="icon-btn" ><i class="fa fa-fw fa-reply"></i>@lang('Back')</a> 
@endpush
