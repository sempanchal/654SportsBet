@extends('admin.layouts.app')
@section('panel')
@endsection
@push('breadcrumb-plugins')
	<a href="{{ route('admin.teams.create') }}" class="icon-btn"><i class="fa fa-plus"></i> @lang('Add Teams')</a> 
@endpush