<?php

namespace App\Http\Controllers;
use App\Models\AdminNotification;
use App\Models\Frontend;
use App\Models\GeneralSetting;
use App\Models\Language;
use App\Models\Page;
use App\Models\Phase;
use App\Models\Lottery;
use App\Models\Game;
use App\Models\Team;
use App\Models\UserGame;
use App\Models\UserTeam;
use App\Models\Subscriber;
use App\Models\SupportAttachment;
use App\Models\SupportMessage;
use App\Models\SupportTicket;
use App\Models\Ticket;
use App\Models\Transaction;
use App\Models\Winner;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Lib\RapidAPI;
use App\Models\User;
use Illuminate\Support\Facades\URL;
use App\Models\glofLotterie;
use App\Models\GlofFixture;
use App\Models\glofEntryList;
use App\Models\GlofLotterieTicket;
use App\Models\UserGolfPlayer;


class SiteController extends Controller
{
    public function __construct(){
        $this->activeTemplate = activeTemplate();
    }

    public function index(){
        $count = Page::where('tempname',$this->activeTemplate)->where('slug','home')->count();
        if($count == 0){
            $page = new Page();
            $page->tempname = $this->activeTemplate;
            $page->name = 'HOME';
            $page->slug = 'home';
            $page->save();
        }

        $reference = @$_GET['reference'];
        if ($reference) {
            session()->put('reference', $reference);
        }

        $pageTitle = 'Home';
        /*lotterie*/
        $events = Lottery::where('status', 1)->orderBy('id', 'DESC')->get();
        
        $events_arr = [];
        $i=0;
        foreach($events as $event){
            $events_arr[$i]['id'] = $event->id;
            $events_arr[$i]['sport_id'] = $event->sport_id;
            $events_arr[$i]['name'] = $event->name;
            $events_arr[$i]['jackpot_name'] = $event->jackpot_name;
            $events_arr[$i]['ticket_price'] = $event->ticket_price;
            $events_arr[$i]['detail'] = $event->detail;
            $lottery_dates = explode(",",$event->date);
            $lottery_dates_arr = [];
            foreach($lottery_dates as $ldata){
                $lottery_dates_arr[] = strtotime($ldata);
            }
            rsort($lottery_dates_arr);
            $end = Carbon::parse($lottery_dates_arr[0])->toDateTimeString();
            if(Carbon::now() > $end){
                $lottery_status = "End";
            }else{  
                $lottery_status = "Live";
            }
            $events_arr[$i]['date'] = Carbon::parse($lottery_dates_arr[0])->format('F jS');
            $events_arr[$i]['price'] = $event->price;
            $events_arr[$i]['lottery_status'] = $lottery_status;
            $i++;
        }
        //golf
        $golflotteries = glofLotterie::where('status', 1)->orderBy('id','desc')->get();
        $golflotteries_arr = [];
        $key_index = 0;
        foreach ($golflotteries as $key => $value) {
           
            $golflotteries_arr[$key_index]['id'] = $value->id;
            $golflotteries_arr[$key_index]['jackpot_name'] = $value->jackpot_name;
            $golflotteries_arr[$key_index]['sport'] = $value->sport;
            $golflotteries_arr[$key_index]['tournament_id'] = $value->tournament_id;
            $golflotteries_arr[$key_index]['ticket_price'] = $value->ticket_price;
            $golflotteries_arr[$key_index]['jackpot_price'] = $value->jackpot_price;
            $golflotteries_arr[$key_index]['first_place'] = $value->first_place;
            $golflotteries_arr[$key_index]['second_place'] = $value->second_place;
            $golflotteries_arr[$key_index]['third_place'] = $value->third_place;
            $golflotteries_arr[$key_index]['detail'] = $value->detail;
            $golflotteries_arr[$key_index]['status'] = $value->status;

            $tournaments = GlofFixture::where('tournament_id', $value->tournament_id)->first();
            $golflotteries_arr[$key_index]['start_date'] = Carbon::parse($tournaments->start_date)->format('F jS');
            $golflotteries_arr[$key_index]['end_date'] = Carbon::parse($tournaments->end_date)->format('F jS');
            $end1 = Carbon::parse($tournaments->end_date)->toDateTimeString();
            if(Carbon::now() > $end1){
                $lottery_status1 = "End";
            }else{  
                $lottery_status1 = "Live";
            }
            $golflotteries_arr[$key_index]['lottery_status'] = $lottery_status1;
            $golflotteries_arr[$key_index]['tournaments_start_date'] = $tournaments->start_date;
            $golflotteries_arr[$key_index]['tournaments_end_date'] = $tournaments->end_date;
            $key_index++;
        }
        $sections = Page::where('tempname',$this->activeTemplate)->where('slug','home')->first();
        return view($this->activeTemplate . 'home', compact('pageTitle','sections','events_arr','golflotteries_arr'));
    }

    public function pages($slug)
    {
        $page = Page::where('tempname',$this->activeTemplate)->where('slug',$slug)->firstOrFail();
        $pageTitle = $page->name;
        $sections = $page->secs;
        return view($this->activeTemplate . 'pages', compact('pageTitle','sections'));
    }


    public function contact()
    {
        $pageTitle = "Contact Us";
        return view($this->activeTemplate . 'contact',compact('pageTitle'));
    }


    public function contactSubmit(Request $request)
    {

        $attachments = $request->file('attachments');
        $allowedExts = array('jpg', 'png', 'jpeg', 'pdf');

        $this->validate($request, [
            'name' => 'required|max:191',
            'email' => 'required|max:191',
            'subject' => 'required|max:100',
            'message' => 'required',
        ]);


        $random = getNumber();
        
        $ticket = new SupportTicket();
        $ticket->user_id = auth()->user() ? 1 : 0;
        $ticket->name = $request->name;
        $ticket->email = $request->email;
        $ticket->priority = 2;


        $ticket->ticket = $random;
        $ticket->subject = $request->subject;
        $ticket->last_reply = Carbon::now();
        $ticket->status = 0;
        $ticket->save();

        $adminNotification = new AdminNotification();
        $adminNotification->user_id = auth()->id() ?? 0;
        $adminNotification->title = 'A new support ticket has opened ';
        $adminNotification->click_url = urlPath('admin.ticket.view',$ticket->id);
        $adminNotification->save();

        $message = new SupportMessage();
        $message->supportticket_id = $ticket->id;
        $message->message = $request->message;
        $message->save();

        $notify[] = ['success', 'ticket created successfully!'];

        return redirect()->route('ticket.view', [$ticket->ticket])->withNotify($notify);
    }

    public function changeLanguage($lang = null)
    {
        $language = Language::where('code', $lang)->first();
        if (!$language) $lang = 'en';
        session()->put('lang', $lang);
        return redirect()->back();
    }

    public function blog()
    {
        $data['pageTitle'] = 'Blog';
        $data['blogs'] = Frontend::where('data_keys','blog.element')->orderBy('id','desc')->paginate(getPaginate());
        $data['blog_content'] = getContent('blog.content', true);
        return view($this->activeTemplate . 'blog.blogs', $data);
    }

    public function blogDetails($id,$slug){
        $blog = Frontend::where('id',$id)->where('data_keys','blog.element')->firstOrFail();
        $blog->increment('views');

        $recent_blogs = Frontend::where('id', '!=', $id)->where('data_keys', 'blog.element')->latest('id')->take(5)->get();

        $pageTitle = 'Blog Details';
        return view($this->activeTemplate.'blog.blog_details',compact('blog','pageTitle', 'recent_blogs'));
    }


    public function cookieAccept(){
        session()->put('cookie_accepted',true);

        return response()->json(['success' => 'Cookie accepted successfully']);
    }

    public function placeholderImage($size = null){
        $imgWidth = explode('x',$size)[0];
        $imgHeight = explode('x',$size)[1];
        $text = $imgWidth . '×' . $imgHeight;
        $fontFile = realpath('assets/font') . DIRECTORY_SEPARATOR . 'RobotoMono-Regular.ttf';
        $fontSize = round(($imgWidth - 50) / 8);
        if ($fontSize <= 9) {
            $fontSize = 9;
        }
        if($imgHeight < 100 && $fontSize > 30){
            $fontSize = 30;
        }

        $image     = imagecreatetruecolor($imgWidth, $imgHeight);
        $colorFill = imagecolorallocate($image, 100, 100, 100);
        $bgFill    = imagecolorallocate($image, 175, 175, 175);
        imagefill($image, 0, 0, $bgFill);
        $textBox = imagettfbbox($fontSize, 0, $fontFile, $text);
        $textWidth  = abs($textBox[4] - $textBox[0]);
        $textHeight = abs($textBox[5] - $textBox[1]);
        $textX      = ($imgWidth - $textWidth) / 2;
        $textY      = ($imgHeight + $textHeight) / 2;
        header('Content-Type: image/jpeg');
        imagettftext($image, $fontSize, 0, $textX, $textY, $colorFill, $fontFile, $text);
        imagejpeg($image);
        imagedestroy($image);
    }

    public function links($id,$slug){
        $data = Frontend::where('id',$id)->where('data_keys','extra.element')->firstOrFail();
        $pageTitle = $data->data_values->title;
        return view($this->activeTemplate.'links',compact('data','pageTitle'));
    }

    public function lottery()
    {
        $pageTitle = "Games";
        $phases = Phase::where('status',1)->where('draw_status',0)->where('start','<',Carbon::now()->toDateTimeString())->orderBy('end','asc')->whereHas('lottery',function($lottery){
            $lottery->where('status',1);
        })->with(['lottery'])->paginate(getPaginate());
        $empty_message = "Data Not Found";

        $events = Lottery::where('status', 1)->orderBy('id', 'DESC')->get();
        
        $events_arr = [];
        $i=0;
        foreach($events as $event){
            $events_arr[$i]['id'] = $event->id;
            $events_arr[$i]['sport_id'] = $event->sport_id;
            $events_arr[$i]['name'] = $event->name;
            $events_arr[$i]['jackpot_name'] = $event->jackpot_name;
            $events_arr[$i]['ticket_price'] = $event->ticket_price;
            $events_arr[$i]['detail'] = $event->detail;
            $lottery_dates = explode(",",$event->date);
            $lottery_dates_arr = [];
            foreach($lottery_dates as $ldata){
                $lottery_dates_arr[] = strtotime($ldata);
            }
            rsort($lottery_dates_arr);
            $end = Carbon::parse($lottery_dates_arr[0])->toDateTimeString();
            if(Carbon::now() > $end){
                $lottery_status = "End";
            }else{  
                $lottery_status = "Live";
            }
            $events_arr[$i]['date'] = Carbon::parse($lottery_dates_arr[0])->format('F jS');
            $events_arr[$i]['price'] = $event->price;
            $events_arr[$i]['lottery_status'] = $lottery_status;
            $i++;
        }
        //golf
        $golflotteries = glofLotterie::where('status', 1)->orderBy('id','desc')->get();
        $golflotteries_arr = [];
        $key_index = 0;
        foreach ($golflotteries as $key => $value) {
           
            $golflotteries_arr[$key_index]['id'] = $value->id;
            $golflotteries_arr[$key_index]['jackpot_name'] = $value->jackpot_name;
            $golflotteries_arr[$key_index]['sport'] = $value->sport;
            $golflotteries_arr[$key_index]['tournament_id'] = $value->tournament_id;
            $golflotteries_arr[$key_index]['ticket_price'] = $value->ticket_price;
            $golflotteries_arr[$key_index]['jackpot_price'] = $value->jackpot_price;
            $golflotteries_arr[$key_index]['first_place'] = $value->first_place;
            $golflotteries_arr[$key_index]['second_place'] = $value->second_place;
            $golflotteries_arr[$key_index]['third_place'] = $value->third_place;
            $golflotteries_arr[$key_index]['detail'] = $value->detail;
            $golflotteries_arr[$key_index]['status'] = $value->status;

            $tournaments = GlofFixture::where('tournament_id', $value->tournament_id)->first();
            $golflotteries_arr[$key_index]['start_date'] = Carbon::parse($tournaments->start_date)->format('F jS');
            $golflotteries_arr[$key_index]['end_date'] = Carbon::parse($tournaments->end_date)->format('F jS');
            $end1 = Carbon::parse($tournaments->end_date)->toDateTimeString();
            if(Carbon::now() > $end1){
                $lottery_status1 = "End";
            }else{  
                $lottery_status1 = "Live";
            }
            $golflotteries_arr[$key_index]['lottery_status'] = $lottery_status1;
            $golflotteries_arr[$key_index]['tournaments_start_date'] = $tournaments->start_date;
            $golflotteries_arr[$key_index]['tournaments_end_date'] = $tournaments->end_date;
            $key_index++;
        }
        // echo "<pre>";
        // print_r($golflotteries_arr);
        // echo "</pre>";die;

        return view($this->activeTemplate . 'lottery', compact('pageTitle','phases','empty_message','events','events_arr','golflotteries_arr'));
    }

    public function team_popup(Request $request, $id){
        $json = array();
        $lottery_id = $id;
        if(auth()->user()){
            $cur_sym = GeneralSetting::first()->cur_sym;
            $action = route('save_team');
            
            $lottery = Lottery::find($id);
            $all_games = Game::where('lottery_id', $id)->get();
            foreach ($all_games as $key => $game) {
                $teams = Team::where('game_id', $game->id)->get();
                $game_name_date = explode('-', $game->name);
                $games[] = array(
                    'game_id' => $game->id,
                    'name' => $game_name_date[0],
                    'date' => Carbon::parse($game->date)->format('F jS, Y H:i'),
                    'price' => $lottery->price,
                    'teams' => $teams ? $teams->toArray() : array()
                );
            }
            $ticket_price = $lottery->ticket_price;

            $total_tickets_bought = Ticket::where('lottery_id',$lottery_id)->get()->count();

            $lottery_dates = explode(",",$lottery->date);
            $lottery_dates_arr = [];
            foreach($lottery_dates as $ldata){
                $lottery_dates_arr[] = strtotime($ldata);
            }
            rsort($lottery_dates_arr);
            $end = Carbon::parse($lottery_dates_arr[0])->toDateTimeString();
            if(Carbon::now() > $end){
                $lottery_status = "End";
            }else{  
                $lottery_status = "Live";
            }
            $edate = Carbon::parse($lottery_dates_arr[0])->format('F jS');

            $json['html'] = view($this->activeTemplate . 'lottery_team',compact('action','games','ticket_price','lottery_id','lottery','cur_sym','total_tickets_bought','lottery_status','edate'))->render();

            //echo "<pre>";print_r($json['html']);die;
            $json['ticket_price'] = $cur_sym.$ticket_price." Place Bet";
            $json['success'] = true;
        }else{
            $json['url'] = URL::to('/login');
            $json['error'] = "User must be login!";
            $json['success'] = false;
        }

        return response()->json($json);
    }

    public function team_schedule($id){
        /*$lottery = Lottery::find($id);
        $date = $lottery->date;
        $sport_id = $lottery->sport_id;
        
        $sports = RapidAPI::get_teams_result($sport_id,$date,"schedule");*/
        //print_r($sports);die;
        $all_games = Game::where('lottery_id', $id)->get();
        foreach ($all_games as $key => $game) {
            $teams = Team::where('game_id', $game->id)->get();
            $game_name_date = explode('-', $game->name);
            $games[] = array(
                'game_id' => $game->id,
                'name' => $game_name_date[0],
                'date' => Carbon::parse($game->date)->format('F jS, Y H:i'),
                'teams' => $teams ? $teams->toArray() : array()
            );
        }
        if(!empty($games)){
            $json['html'] = view($this->activeTemplate . 'lottery_schedule',compact('games'))->render();
            $json['success'] = true;
        }
        return response()->json($json);
    }

    public function rules_popup($id){
        //if(auth()->user()){
            $general = GeneralSetting::first()->cur_sym;
            $lottery = Lottery::find($id);

            $rules_array = [];

            $rules_array['jackpot_name'] = $lottery->jackpot_name;
            $rules_array['name'] = $lottery->name;

            $lottery_dates = explode(",",$lottery->date);
            $lottery_dates_arr = [];
            foreach($lottery_dates as $ldata){
                $lottery_dates_arr[] = strtotime($ldata);
            }
            rsort($lottery_dates_arr);
            $sdate = Carbon::parse($lottery_dates_arr[count($lottery_dates_arr)-1])->format('F jS, Y');
            $rules_array['sdate'] = $sdate;
            $rules_array['edate'] = Carbon::parse($lottery_dates_arr[0])->format('F jS, Y');
            $rules_array['detail'] = $lottery->detail;
            $rules_array['price'] = $general.number_format((float)$lottery->price);
            $rules_array['ticket_price'] = $general.number_format((float)$lottery->ticket_price);
            $rules_array['no_of_entries'] = (int)$lottery->no_of_entries;
            
            $rules_array['first_place'] = $general.number_format(((float)$lottery->price*(int)$lottery->first_place)/100);
            $rules_array['second_place'] = $general.number_format(((float)$lottery->price*(int)$lottery->second_place)/100);
            $rules_array['third_place'] = $general.number_format(((float)$lottery->price*(int)$lottery->third_place)/100);
            $rules_array['data'] = $lottery;
            //$rules_array['success'] = true;
            //print_r($rules_array);die;
        if(!empty($rules_array)){
            $json['html'] = view($this->activeTemplate . 'play_table_rules',compact('rules_array'))->render();
            $json['success'] = true;
        }
        return response()->json($json);
    }

    public function save_team(Request $request){
        $json = array();
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        $balance = (float)$user->balance;
        $ticket_price = (float)$request->ticket_price;
        $trx = getTrx();
    
        $total_teams = 0;
        $new_games_arr = [];
        foreach ($request->games as $tckey => $tcvalue) {
            foreach ($tcvalue['team'] as $tk => $tv) {
                if(isset($tv['team_id'])){
                    $total_teams++;
                    $data = [
                        'game_id' => $tcvalue['game_id'],
                        'date' => Carbon::parse($tcvalue['date'])->format('Y-m-d H:m:s'),
                        'price' => $tcvalue['price'],
                        'team' => $tv,
                    ];
                    array_push($new_games_arr,$data);
                }
            }
        }
        if(!auth()->user()){
            $json['error'] = "User must be login!";
        }else if($total_teams != 6){
            $json['error'] = "Please select 6 teams";
        }else if($ticket_price >= $balance){
            $json['error'] = "Your wallet balance is not sufficient to buy ticket";
        }

        //print_r($new_games_arr);die;

        if(!$json){
            if($request->lottery_id){ 
                $ticket = Ticket::create([
                    'lottery_id'=>$request->lottery_id,
                    'user_id'=>$user_id,
                    'ticket_number'=>$trx,
                    'total_price'=>$ticket_price,
                    'status'=>1,
                ]);
               $ticket_id = $ticket->id;
            }
            if($ticket_id && $request->lottery_id){
                $lottery_r = Lottery::find($request->lottery_id);
                $revenue = (((float)$lottery_r->ticket_price*(int)$lottery_r->revenue_percentage)/100);
                $newPrice = (float)$lottery_r->price+$revenue;
                $lottery_r->update(['price'=>$newPrice]);    
            }

            foreach($new_games_arr as $new_game){
                $usergame = new UserGame();
                $usergame->user_id = auth()->user()->id;
                $usergame->game_id = $new_game['game_id'];
                $usergame->date = $new_game['date'];
                $usergame->price = $new_game['price'];
                $usergame->ticket_id = $ticket_id;
                $usergame->lottery_id = $request->lottery_id;
                $usergame->save();
                if(isset($new_game['team']) && $usergame->id){
                    $userteam = new UserTeam();
                    $userteam->user_id = auth()->user()->id;
                    $userteam->team_id = $new_game['team']['team_id'];
                    $userteam->mascot = $new_game['team']['mascot'];
                    $userteam->abbreviation = $new_game['team']['abbreviation'];
                    $userteam->user_game_id = $usergame->id;
                    $userteam->ticket_id = $ticket_id;
                    $userteam->lottery_id = $request->lottery_id;
                    $userteam->save();
                }
               /* foreach($new_game['team'] as $kk => $teamv) {
                }*/
            }

            

            /*sunny 10-12-2021*/
            $available_balance = $balance-$ticket_price;

            $user->balance = $available_balance;
            $user->save();

            $transaction = new Transaction();
            $transaction->user_id = auth()->user()->id;
            $transaction->amount = $ticket_price;
            $transaction->charge = 0;
            $transaction->post_balance = $available_balance;
            $transaction->trx_type = '-';
            $transaction->trx =  $trx;
            $transaction->details = "buy lottery ticket";
            $transaction->ticket_id = $ticket_id;
            $transaction->save();

            /*10-12-2021*/
            
            $json['message'] = "Your bet has been successfully placed. Good luck!<br/> <span style='color:#ffb400;'>View your confirmation on <a style='color:#ffb400;' href='".URL::to('/user/my-bets')."'>My Bets</a></span>";
            $json['success'] = true;
        }else{
            $json['success'] = false;
        }

        return response()->json($json);
    }

    public function lotterySingle($id)
    {
        $phase = Phase::findOrFail($id);
        $pageTitle = $phase->lottery->name." Details";
        if ($phase->end <= Carbon::now()) {
            $notify[] = ['error','Oops! Time Out'];
            return redirect()->route('home')->withNotify($notify);
        }
        if (($phase->start > Carbon::now())) {
            $notify[] = ['error','Oops! Thats not started'];
            return redirect()->route('home')->withNotify($notify);
        }
        return view($this->activeTemplate . 'lotterySingle', compact('pageTitle','phase'));
    }

    public function subscribe(Request $request){
        $validator = Validator::make($request->all(),[
            'email' => 'required|email|max:255|unique:subscribers',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }
        Subscriber::create([
            'email'=>$request->email
        ]);

        $notify[] = ['success','Subscribed Successfully'];
        return response()->json(['success'=>'Subscribe successfully']);
    }

    //Cron
    public function cron(){
        $phases = Phase::where('status',1)->with('tickets')->where('draw_status',0)->where('at_dr',1)->where('end','<=',Carbon::now())->get();
        $now = Carbon::now();
        $general = GeneralSetting::first();
        $general->last_cron = $now;
        $general->save();
        $trx = getTrx();
        foreach ($phases as $phase) {
            $phase->draw_status = 1;
            $phase->updated_at = Carbon::now();
            $phase->save();
            if ($phase->tickets->count() <= 0) {
                continue;
            }
            foreach ($phase->tickets as $ticket) {
                $numbers[] = $ticket->ticket_number;
            }

            $num = collect($numbers);
            $winBon = $phase->lottery->bonuses;
            if ($winBon->count() > $num->count()) {
                $nuGet = $num;
            }else{
                $nuGet = $num->random($winBon->count());
            }
            foreach ($nuGet as $key => $nums) {
                $ticket = Ticket::where('ticket_number',$nums)->first();
                $user = $ticket->user;
                $bonus = $winBon[$key]->amount;
                $winnerId = Winner::insertGetId([
                    'ticket_id'=>$ticket->id,
                    'user_id' => $user->id,
                    'phase_id'=>$phase->id,
                    'ticket_number'=>$nums,
                    'level'=>$winBon[$key]->level,
                    'win_bonus'=>$bonus,
                    'created_at'=>Carbon::now(),
                ]);
                $user->balance += $bonus;
                $user->save();
                Transaction::create([
                    'user_id' => $user->id,
                    'amount' => $bonus,
                    'charge' => 0,
                    'trx_type' => '+',
                    'details' => 'You are winner '.$winBon[$key]->level.' of '.@$ticket->lottery->name.' of phase '.@$ticket->phase->phase,
                    'trx' => $trx,
                    'remark' => 'win_bonus',
                    'post_balance' => $user->balance,
                ]);
                if ($general->wc == 1) {
                    levelCommision($user->id, $bonus, $commissionType = 'win');
                }
                notify($user, 'WIN_EMAIL', [
                    'lottery'=>$ticket->lottery->name,
                    'number'=>$nums,
                    'amount'=>getAmount($bonus),
                    'level'=>$winBon[$key]->level,
                    'currency'=>$general->cur_text
                ]);
            }
        }
    }

    public function golf_team_popup(Request $request, $id){
        $json = array();
        $cur_sym = GeneralSetting::first()->cur_sym;
        $lottery_id = $id;
        if(auth()->user()){
            $action = route('save_golf_player');

            $golflotteries = glofLotterie::where('id',$lottery_id)->first();

            $tournaments = GlofFixture::where('tournament_id', $golflotteries->tournament_id)->first();

            $start_date = Carbon::parse($tournaments->start_date)->format('F jS');
            $end_date = Carbon::parse($tournaments->end_date)->format('F jS');
            $end = Carbon::parse($tournaments->end_date)->toDateTimeString();
            if(Carbon::now() > $end){
                $lottery_status = "End";
            }else{  
                $lottery_status = "Live";
            }
            $total_tickets_bought = 0;

            $entry_lists = glofEntryList::where('lottery_id',$lottery_id)->get();

            $json['html'] = view($this->activeTemplate . 'golf_player',compact('action','entry_lists','golflotteries','lottery_status','end_date','total_tickets_bought','cur_sym'))->render();

            //echo "<pre>";print_r($json['html']);die;
            $json['ticket_price'] = $cur_sym.$golflotteries->ticket_price." Place Bet";
            $json['success'] = true;
            // echo "<pre>";
            // print_r($json);
            // die;
        }else{
            $json['url'] = URL::to('/login');
            $json['error'] = "User must be login!";
            $json['success'] = false;
        }
        return response()->json($json);
    }

    public function save_golf_player(Request $request){
            // echo "<pre>";
            // print_r($request->input());
            // die;
        $json = array();
        $lottery_id = $request->lottery_id;
        $user_id = auth()->user()->id;
        $user = User::find($user_id);
        $balance = (float)$user->balance;
        $ticket_price = (float)$request->ticket_price;
        $trx = getTrx();
    
        $total_teams = count($request->players);
       
        if(!auth()->user()){
            $json['error'] = "User must be login!";
        }else if($total_teams != 6){
            $json['error'] = "Please select 6 teams";
        }else if($ticket_price >= $balance){
            $json['error'] = "Your wallet balance is not sufficient to buy ticket";
        }

        //print_r($new_games_arr);die;

        if(!$json){
            if($lottery_id){ 
                $ticket = GlofLotterieTicket::create([
                    'lottery_id'=>$lottery_id,
                    'user_id'=>$user_id,
                    'ticket_number'=>$trx,
                    'total_price'=>$ticket_price,
                    'status'=>1,
                ]);
               $ticket_id = $ticket->id;
            }

            if($ticket_id){
                UserGolfPlayer::create([
                    'lottery_id'=>$lottery_id,
                    'user_id'=>$user_id,
                    'players'=> json_encode($request->players),
                    'ticket_id'=>$ticket_id,
                ]);
            }

            /*sunny 10-12-2021*/
            $available_balance = $balance-$ticket_price;

            $user->balance = $available_balance;
            $user->save();

            $transaction = new Transaction();
            $transaction->user_id = auth()->user()->id;
            $transaction->amount = $ticket_price;
            $transaction->charge = 0;
            $transaction->post_balance = $available_balance;
            $transaction->trx_type = '-';
            $transaction->trx =  $trx;
            $transaction->details = "buy lottery ticket";
            $transaction->ticket_id = $ticket_id;
            $transaction->save();

            /*10-12-2021*/
            
            $json['message'] = "Your bet has been successfully placed. Good luck!<br/> <span style='color:#ffb400;'>View your confirmation on <a style='color:#ffb400;' href='".URL::to('/user/my-bets')."'>My Bets</a></span>";
            $json['success'] = true;
        }else{
            $json['success'] = false;
        }

        return response()->json($json);
    }
}
