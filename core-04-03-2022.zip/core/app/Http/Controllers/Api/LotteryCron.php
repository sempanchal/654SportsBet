<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Lottery;
use App\Models\Game;
use App\Models\Team;
use App\Lib\RapidAPI;
use Carbon\Carbon;

class LotteryCron extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   $currnt_date_time = Carbon::now();
        $allLottery = Lottery::get();
        foreach($allLottery as $key => $value){
            $id = $value->id;
            $sport_id = $value->sport_id;
            $name = $value->name;
            $jackpot_name = $value->jackpot_name;
            $ticket_price = $value->ticket_price;
            $image = $value->image;
            $status = $value->status;
            $detail = $value->detail;
            $date = $value->date;
            $total_winners = $value->total_winners;
            $price = $value->price;
            $jackpot_type = $value->jackpot_type;
            $order_prediction = $value->order_prediction;
            $money_type = $value->money_type;
            $maximum_participants = $value->maximum_participants;
            $quick_select = $value->quick_select;
            $no_of_entries = $value->no_of_entries;
            $first_place = $value->first_place;
            $second_place = $value->second_place;
            $third_place = $value->third_place;
            $created_at = $value->created_at;
            $updated_at = $value->updated_at;

            if($status == 1){
                $score_data = RapidAPI::get_teams_result($sport_id,$date,"winner");
                $teams = Team::where('lottery_id',$id)->get();
                foreach($teams as $team_key => $team_value){
                    $id_team = $team_value->id;
                    $lottery_id_team = $team_value->lottery_id;
                    $game_id_team = $team_value->game_id;
                    $team_id_team = $team_value->team_id;
                    $name_team = $team_value->name;
                    $mascot_team = $team_value->mascot;
                    $abbreviation_team = $team_value->abbreviation;
                    $is_away_team = $team_value->is_away;
                    $is_home_team = $team_value->is_home;
                    $match_date_team = $team_value->match_date;
                    $score_team = $team_value->score;

                    if(array_key_exists($team_id_team, $score_data)){ 
                        $save_score = Team::find($id_team);
                        $save_score->score = $score_data[$team_id_team];
                        $save_score->save();
                        //echo "<pre>";
                        //info("update--".$score_data[$team_id_team]);
                        //echo "</pre>";
                    }
                }
            Lottery::where('id',$value->id)->update(['last_update_score' => $currnt_date_time]);
            }

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
