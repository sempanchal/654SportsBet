<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GlofLotterieTicket extends Model
{
    use HasFactory;

    protected $fillable = [
        'lottery_id',
        'user_id',
        'ticket_number',
        'ticket_price',
        'status',
        'send_mail',
        'transfer_winning_amount',
    ];
}
