$(document).ready(function() {
   
    // DataTable
    var table = $('#example').DataTable({
        "lengthChange": false,
        "bSort": false
    });

    $('#btn_cust_username').click( function() {
        var name = $("#cust_username").val();
        table.columns(1).search(name).draw();
    });
    $('#btn_ticket_number').click( function() {
        var name = $("#cust_ticket_number").val();
        table.columns(2).search(name).draw();
    } );

    //end

    $('.winner_team_popup').on('click', function(){
        $btn = $(this);
        $lotterie_id = $btn.attr('data-lotterie_id')
        $ticket_id = $btn.attr('data-ticket_id')
        $action = $btn.attr('data-id');
        $.ajax({
            url: $action,
            type: 'get',
            dataType: 'json',
            data:({lotterie_id:$lotterie_id,ticket_id:$ticket_id}),
            beforeSend: function(){
                $btn.prop('disabled', true);
            },
            success: function(json){
                if(json.success){
                    $('#ticket-teams .modal-body').html(json.html);
                    $('#ticket-teams').show();
                }else{
                    iziToast['error']({
                        message: json.error,
                        position: "topRight"
                    });
                }
            },
            complete: function(){
                $btn.prop('disabled', false);
            }
        });
    });

    $('.winner_send_mail_popup').on('click', function(){
        $btn = $(this);
        $ticket_id = $btn.attr('data-ticket_id');
        $lotterie_id = $btn.attr('data-lotterie_id');
        $user_id = $btn.attr('data-user_id');
        $position = $btn.attr('data-position');
        $nowisp = $btn.attr('data-nowisp');

        $action = $btn.attr('data-id');
        $.ajax({
            url: $action,
            type: 'get',
            dataType: 'json',
            data:({ticket_id:$ticket_id,lotterie_id:$lotterie_id,user_id:$user_id,position:$position,nowisp:$nowisp}),
            beforeSend: function(){
                //$btn.prop('disabled', true);
            },
            success: function(json){
                location.reload();
                if(json.success){
                     iziToast['success']({
                        message: json.add_balance_msg,
                        position: "topRight"
                    });
                }/*else{
                    iziToast['error']({
                        message: json.error,
                        position: "topRight"
                    });
                }*/
            },
            complete: function(){
                //$btn.prop('disabled', false);
            }
        });
    });

    // 07-02-2022
    $("#score_update").on('click', function(){
        $btn = $(this);
        $action = $btn.attr('data-action');
        $csrf = $btn.attr('data-csrf');
        $lotterie_id = $btn.attr('data-lotterie_id');
        $.ajax({
            url: $action,
            type: 'post',
            data:({"_token":$csrf,lotterie_id:$lotterie_id}),
            beforeSend: function(){
               $btn.attr("disabled","disabled");
            },
            success: function(json){
                //console.log(json);
                location.reload();
            },
            complete: function(){
            }
        });
     });

    $('#send_to_winner').on('click', function(){
        $btn = $(this);
        $action = $btn.attr('data-id');
        $win_data = $btn.attr('data-win_data');
        $csrf = $btn.attr('data-csrf');
        $lotterie_id = $btn.attr('data-lotterie_id');
        //alert($lotterie_id);
        /*$ticket_id = $btn.attr('data-ticket_id');
        $user_id = $btn.attr('data-user_id');
        $position = $btn.attr('data-position');
        $nowisp = $btn.attr('data-nowisp');*/

        $.ajax({
            url: $action,
            type: 'post',
            //dataType: 'json',
            data:({"_token":$csrf,win_data:$win_data,lotterie_id:$lotterie_id}),
            beforeSend: function(){
                //$btn.prop('disabled', true);
               $btn.attr("disabled","disabled");
            },
            success: function(json){
                console.log(json);
                location.reload();
                /*if(json.success){
                     iziToast['success']({
                        message: json.add_balance_msg,
                        position: "topRight"
                    });
                }*/
            },
            complete: function(){
                //$btn.prop('disabled', false);
            }
        });
    });

    
    $('#current_status').on('click', function(){
        $btn = $(this);
        $lotterie_id = $btn.attr('data-lotterie_id');
        $sportId = $btn.attr('data-sportId');
        $lotterie_date = $btn.attr('data-lotterie_date')
        $action = $btn.attr('data-id');

         $.ajax({
            url: $action,
            type: 'get',
            dataType: 'json',
            data:({lotterie_id:$lotterie_id,sportId:$sportId,lotterie_date:$lotterie_date}),
            beforeSend: function(){
                //$btn.prop('disabled', true);
            },
            success: function(json){
                console.log(json);
                if(json.success){
                    $('#lotteryCurrentStatusPopup .modal-body').html(json.html);
                    $('#lotteryCurrentStatusPopup').show();
                }else{
                    iziToast['error']({
                        message: "No Data Found",
                        position: "topRight"
                    });
                }
            },
            complete: function(){
                //$btn.prop('disabled', false);
            }
        });
    });

    // 09-02-2022
    $('#get-sport-team').on('click', function(){
        $btn = $(this);
        $action = $btn.attr('data-action');
        $sport_id = $('#sport_id').val();
        if($sport_id){
             $.ajax({
                url: $action,
                type: 'get',
                dataType: 'json',
                data:({id:$sport_id}),
                beforeSend: function(){
                    $btn.attr("disabled","disabled");
                },
                success: function(json){
                    console.log(json);
                    $('#ajax_teams').html(json.html);
                },
                complete: function(){
                    $btn.removeAttr("disabled");
                }
            });
        }
    });

    $(document).on('change', '.preview_img', function() {
        var curElement = $(this).parent().find('.logoteamimg');
        console.log(curElement);
        var reader = new FileReader();

        reader.onload = function (e) {
            // get loaded data and render thumbnail.
            curElement.attr('src', e.target.result);
        };

        // read the image file as a data URL.
        reader.readAsDataURL(this.files[0]);
    });
} );